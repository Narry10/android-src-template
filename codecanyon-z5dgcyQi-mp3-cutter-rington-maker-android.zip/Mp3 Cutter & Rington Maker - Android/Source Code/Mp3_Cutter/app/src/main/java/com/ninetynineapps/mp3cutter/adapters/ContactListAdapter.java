package com.ninetynineapps.mp3cutter.adapters;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.ninetynineapps.mp3cutter.interfaces.AdapterItemCallback;
import com.ninetynineapps.mp3cutter.pojo.ContactsClass;
import com.ninetynineapps.mp3cutter.R;
import com.ninetynineapps.mp3cutter.common.CommonUtilities;

import java.util.ArrayList;

public class ContactListAdapter extends RecyclerView.Adapter<ContactListAdapter.AdapterViewHolder> {

    private Context context;
    private ArrayList<ContactsClass> contactsClassArrayList;
    private AdapterItemCallback adapterItemCallback;

    public ContactListAdapter(Context context,  ArrayList<ContactsClass> contactsClassArrayList, AdapterItemCallback adapterItemCallback) {
        this.context = context;
        this.contactsClassArrayList = contactsClassArrayList;
        this.adapterItemCallback = adapterItemCallback;
    }

    public class AdapterViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private AppCompatImageView imgContact;
        private AppCompatTextView tvOneLetter;
        private AppCompatTextView tvContactName;

        AdapterViewHolder(View view) {
            super(view);
            imgContact = view.findViewById(R.id.imgContactClContactList);
            tvOneLetter = view.findViewById(R.id.tvOneLetterClContactList);
            tvContactName = view.findViewById(R.id.tvContactNameClContactList);
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            adapterItemCallback.onItemCallback(getAdapterPosition());
        }
    }

    @NonNull
    @Override
    public AdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new AdapterViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_contact_list, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterViewHolder holder, int position) {
        holder.tvContactName.setText(contactsClassArrayList.get(position).mName);
        try {
            Glide.with(context)
                    .applyDefaultRequestOptions(new RequestOptions().diskCacheStrategy(DiskCacheStrategy.RESOURCE).centerCrop())
                    .load(R.drawable.ic_user_default)
                    .into(holder.imgContact);

            String letter = String.valueOf(contactsClassArrayList.get(position).mName.charAt(0));
            holder.tvOneLetter.setText(letter);
            holder.tvOneLetter.setBackgroundColor(CommonUtilities.getMatColor(context.getApplicationContext()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return contactsClassArrayList.size();
    }

    public void updateData(ArrayList<ContactsClass> data) {
        this.contactsClassArrayList = data;
        notifyDataSetChanged();
    }
}