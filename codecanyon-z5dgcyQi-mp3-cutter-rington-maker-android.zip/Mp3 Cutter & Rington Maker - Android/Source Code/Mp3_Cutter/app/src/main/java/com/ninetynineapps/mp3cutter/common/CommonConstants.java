package com.ninetynineapps.mp3cutter.common;

public class CommonConstants {
    public static final String FILE_NAME = "FILE_NAME";
    public static String IS_RINGTONE = "IS_RINGTONE";
    public static String IS_ALARM = "IS_ALARM";
    public static String IS_NOTIFICATION = "IS_NOTIFICATION";
    public static String IS_MUSIC = "IS_MUSIC";

    public static final int RequestCodePermission = 111;
    public static final int RequestCodeRecordUpdated = 222;
    public static final String KeyIsRecordUpdated = "RecordUpdated";

    public static final String MsgAllowPermission = "Please allow all required permission to continue...";
    public static final String CapPermission = "Permission";
    public static final String CapOk = "Ok";
    public static final String CapCancel = "Cancel";
    public static final String CapContinue = "Continue";
    public static final String CapClose = "Close";
    public static final String CapSuccess = "Success";
    public static final String CapError = "Error";
    public static final String CapDelete = "Delete";
    public static final String CapMessage = "Message";
    public static final String CapInfo = "Info";

    public static final String CapFullDateTimeFormatDisplay = "dd/MM/yyyy hh:mm:ss a";
    public static final String CapYesPlease = "Yes, please!";
    public static final String CapYes = "Yes";
    public static final String CapRename = "Rename";
    public static final String CapNoThanks = "No, thanks.";
    public static final String CapNo = "No";

    public static final String MsgFileRenameSuccessfully = "File renamed Successfully...";
    public static final String MsgFileDeleteSuccessfully = "File deleted Successfully...";
    public static final String MsgSetRingtone = "Set Ringtone!";
    public static final String MsgRenameFile = "Rename file?";
    public static final String MsgEnterFileName = "Enter file name.";
    public static final String MsgSDCardReadOnly = "Sorry, the SD Card is mounted as read-only and app requires it to be writable.";
    public static final String MsgSDCardShared = "Sorry, app can\'t run while your handset is mounted as a USB device.";
    public static final String MsgNoSDCard = "Sorry, app can\\'t run unless you have an SD Card inserted.";
    public static final String MsgSetDefaultRing = "Saved! set this as your default notification tone?";
    public static final String MsgWantToExit = "Do you want to exit?";
    public static final String MsgDoubleBackToExit = "Click back again to Exit...";
    public static final String MsgSomethingWrong = "Something went wrong. Please try again!";

    public static final String MsgTooSmallError = "Can\'t save a file that small, try making it longer.";


    public static final String KeySavingDirName = "MyCuttings";
    public static final String KeyMediaClassObject = "MediaClassObject";
    public static final String KeyMediaClassArrayList = "MediaClassArrayList";
    public static final String KeyItemPos = "ItemPos";



    public static final String GOOGLE_ADMOB_APP_ID = "ca-app-pub-3940256099942544~3347511713";
    public static final String GOOGLE_BANNER_ID = "ca-app-pub-3940256099942544/6300978111";
    public static final String GOOGLE_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";


    public static final String FB_BANNER_ID = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
    public static final String FB_INTERSTITIAL_ID = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";


    public static final String AD_FACEBOOK = "facebook";
    public static final String AD_GOOGLE = "google";
    public static final String AD_TYPE_FACEBOOK_GOOGLE = AD_GOOGLE;


    public static final String ENABLE = "Enable";
    public static final String DISABLE = "Disable";
    public static final String ENABLE_DISABLE = ENABLE;




    public static final String AD_TYPE_FB_GOOGLE = "AD_TYPE_FB_GOOGLE";
    public static final String GOOGLE_BANNER = "GOOGLE_BANNER";
    public static final String GOOGLE_INTERSTITIAL = "GOOGLE_INTERSTITIAL";
    public static final String FB_BANNER = "FB_BANNER";
    public static final String FB_INTERSTITIAL = "FB_INTERSTITIAL";
    public static final String SPLASH_SCREEN_COUNT = "splash_screen_count";
    public static final String STATUS_ENABLE_DISABLE = "STATUS_ENABLE_DISABLE";

}