package com.ninetynineapps.mp3cutter.adapters;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.ninetynineapps.mp3cutter.common.CommonUtilities;
import com.ninetynineapps.mp3cutter.custom.BubbleTextGetter;
import com.ninetynineapps.mp3cutter.interfaces.AdapterItemViewTypeCallback;
import com.ninetynineapps.mp3cutter.pojo.MediaClass;
import com.ninetynineapps.mp3cutter.R;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;

public class MediaListAdapter extends RecyclerView.Adapter<MediaListAdapter.AdapterViewHolder> implements BubbleTextGetter {

    private Context context;
    private ArrayList<MediaClass> mediaClassArrayList;
    private AdapterItemViewTypeCallback adapterItemViewTypeCallback;
    private DisplayImageOptions builder;

    public MediaListAdapter(Context context, ArrayList<MediaClass> mediaClassArrayList, AdapterItemViewTypeCallback adapterItemViewTypeCallback) {
        this.context = context;
        this.mediaClassArrayList = mediaClassArrayList;
        this.adapterItemViewTypeCallback = adapterItemViewTypeCallback;

        builder = new DisplayImageOptions.Builder().cacheInMemory(true)
                .showImageOnFail(R.drawable.ic_music_default)
                .showImageOnLoading(R.drawable.ic_music_default)
                .resetViewBeforeLoading(true)
                .build();
    }

    public class AdapterViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private RelativeLayout rlMain;
        private AppCompatImageView mSongsImage;
        private AppCompatTextView mSongName;
        private AppCompatTextView mArtistName;
        private AppCompatTextView mDuration;
        private AppCompatImageView mPopUpMenu;

        AdapterViewHolder(View view) {
            super(view);
            rlMain = view.findViewById(R.id.rlMainClMediaList);
            mSongsImage = view.findViewById(R.id.album_art_image_view);
            mSongName = view.findViewById(R.id.song_name);
            mArtistName = view.findViewById(R.id.artist_name);
            mDuration = view.findViewById(R.id.song_duration);
            mPopUpMenu = view.findViewById(R.id.overflow);

            rlMain.setOnClickListener(this);
            mPopUpMenu.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.rlMainClMediaList:
                    adapterItemViewTypeCallback.onItemTypeCallback(view, 0, getAdapterPosition());
                    break;
                case R.id.overflow:
                    adapterItemViewTypeCallback.onItemTypeCallback(view, 1, getAdapterPosition());
                    break;
            }
        }
    }

    @Override
    public String getTextToShowInBubble(int pos) {
        try {
            return String.valueOf(mediaClassArrayList.get(pos).mSongsName.charAt(0));
        } catch (Exception e) {
            e.printStackTrace();
            return "-";
        }
    }

    @NonNull
    @Override
    public AdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new AdapterViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_media_list, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterViewHolder holder, int position) {

        try {
            holder.mDuration.setText(CommonUtilities.makeShortTimeString(context.getApplicationContext(), Integer.parseInt(mediaClassArrayList.get(position).mDuration) / 1000));
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            holder.mSongName.setText(mediaClassArrayList.get(position).mSongsName);
            holder.mArtistName.setText(mediaClassArrayList.get(position).mArtistName);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
//            ImageLoader.getInstance().displayImage(CommonUtilities.getAlbumArtUri(Long.parseLong(mediaClassArrayList.get(position).mAlbumId)).toString(),
            ImageLoader.getInstance().displayImage(CommonUtilities.getExtUri(mediaClassArrayList.get(position).mAlbumId).toString(),
                    holder.mSongsImage,
                    builder
            );
        } catch (Exception e) {
            e.printStackTrace();
        }

        holder.rlMain.setTag(position);
        holder.mPopUpMenu.setTag(position);
    }

    @Override
    public int getItemCount() {
        return mediaClassArrayList == null ? 0 : mediaClassArrayList.size();
    }

    public void updateData(ArrayList<MediaClass> data) {
        this.mediaClassArrayList = data;
        notifyDataSetChanged();
    }
}