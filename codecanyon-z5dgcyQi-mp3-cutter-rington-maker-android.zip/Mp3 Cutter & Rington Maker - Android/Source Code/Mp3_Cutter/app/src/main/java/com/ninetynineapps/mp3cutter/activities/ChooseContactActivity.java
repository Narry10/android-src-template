package com.ninetynineapps.mp3cutter.activities;

import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract.Contacts;
import androidx.core.view.MenuItemCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.ninetynineapps.mp3cutter.R;
import com.ninetynineapps.mp3cutter.adapters.ContactListAdapter;
import com.ninetynineapps.mp3cutter.common.CommonConstantAd;
import com.ninetynineapps.mp3cutter.common.CommonConstants;
import com.ninetynineapps.mp3cutter.common.CommonUtilities;
import com.ninetynineapps.mp3cutter.interfaces.AdapterItemCallback;
import com.ninetynineapps.mp3cutter.pojo.ContactsClass;

import java.util.ArrayList;

public class ChooseContactActivity extends AppCompatActivity implements SearchView.OnQueryTextListener, AdapterItemCallback {

    private Toolbar mToolbar;
    private SearchView mSearchView;

    private RecyclerView mRecyclerView;
    private ContactListAdapter mContactListAdapter;
    private ArrayList<ContactsClass> contactsClassArrayList;
    private Uri mRingtoneUri;
    RelativeLayout llAdView;
    LinearLayout llAdViewFacebook;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        if (intent != null) {
            if (intent.getExtras() != null) {
                mRingtoneUri = Uri.parse(intent.getExtras().getString(CommonConstants.FILE_NAME));
            }
        }

        setContentView(R.layout.activity_contact_list);
        contactsClassArrayList = new ArrayList<>();
        mToolbar = findViewById(R.id.toolbarActMediaSel);
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.hint_contacts);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }


        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        contactsClassArrayList = CommonUtilities.getContacts(this, "");
        mContactListAdapter = new ContactListAdapter(this, contactsClassArrayList,ChooseContactActivity.this);
        mRecyclerView.setAdapter(mContactListAdapter);


        llAdView = findViewById(R.id.llAdView);
        llAdViewFacebook = findViewById(R.id.llAdViewFacebook);

        if (CommonUtilities.getPref(this, CommonConstants.AD_TYPE_FB_GOOGLE, "").equals(CommonConstants.AD_GOOGLE) &&
                CommonUtilities.getPref(this, CommonConstants.STATUS_ENABLE_DISABLE, "").equals(CommonConstants.ENABLE)) {
            CommonConstantAd.loadBannerGoogleAd(this, llAdView);
            llAdViewFacebook.setVisibility(View.GONE);
            llAdView.setVisibility(View.VISIBLE);
        } else if (CommonUtilities.getPref(this, CommonConstants.AD_TYPE_FB_GOOGLE, "").equals(CommonConstants.AD_FACEBOOK)
                &&
                CommonUtilities.getPref(this, CommonConstants.STATUS_ENABLE_DISABLE, "").equals(CommonConstants.ENABLE)) {
            llAdViewFacebook.setVisibility(View.VISIBLE);
            llAdView.setVisibility(View.GONE);
            CommonConstantAd.loadFacebookBannerAd(this, llAdViewFacebook);
        } else {
            llAdView.setVisibility(View.GONE);
            llAdViewFacebook.setVisibility(View.GONE);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_search, menu);
        mSearchView = (SearchView) MenuItemCompat.getActionView(menu.findItem(R.id.menu_search));

        mSearchView.setOnQueryTextListener(this);
        mSearchView.setQueryHint(getString(R.string.hint_search));

        mSearchView.setIconifiedByDefault(false);
        mSearchView.setIconified(false);

        MenuItemCompat.setOnActionExpandListener(menu.findItem(R.id.menu_search), new MenuItemCompat.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {
                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                finish();
                return false;
            }
        });

        menu.findItem(R.id.menu_search).expandActionView();
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        contactsClassArrayList = CommonUtilities.getContacts(this, newText);
        mContactListAdapter.updateData(contactsClassArrayList);
        return false;
    }


    @Override
    public void onItemCallback(int mPos) {
        assignedToContact(mPos);
    }


    private void assignedToContact(int mPos) {
        ContactsClass contactsClass = contactsClassArrayList.get(mPos);

        Uri uri = Uri.withAppendedPath(Contacts.CONTENT_URI, contactsClass.mContactId);

        ContentValues values = new ContentValues();
        values.put(Contacts.CUSTOM_RINGTONE, mRingtoneUri.toString());
        getContentResolver().update(uri, values, null, null);

        String message = getResources().getText(R.string.success_contact_ringtone) + " " + contactsClass.mName;

        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        finish();
    }
}