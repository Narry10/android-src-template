package com.ninetynineapps.mp3cutter.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.MenuItemCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.Toast;


import com.ninetynineapps.mp3cutter.R;
import com.ninetynineapps.mp3cutter.adapters.MediaListAdapter;
import com.ninetynineapps.mp3cutter.common.CommonConstantAd;
import com.ninetynineapps.mp3cutter.common.CommonConstants;
import com.ninetynineapps.mp3cutter.common.CommonUtilities;
import com.ninetynineapps.mp3cutter.custom.FastScroller;
import com.ninetynineapps.mp3cutter.interfaces.AdapterItemViewTypeCallback;
import com.ninetynineapps.mp3cutter.pojo.MediaClass;

import java.util.ArrayList;

public class MediaSelectActivity extends AppCompatActivity implements
        SearchView.OnQueryTextListener, AdapterItemViewTypeCallback {

    private RecyclerView rvMediaList;
    private MediaListAdapter mMediaListAdapter;

    private FastScroller fastScroller;
    private SearchView searchView;

    private ArrayList<MediaClass> mediaClassArrayList;
    private boolean recordUpdated = false;
    RelativeLayout llAdView;
    LinearLayout llAdViewFacebook;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actvitiy_media_select);
        initViews();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM) {

            View statusBarBg = findViewById(R.id.statusBarBg);
            View mainContent = findViewById(R.id.mainContent);

            WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

            ViewCompat.setOnApplyWindowInsetsListener(mainContent, (v, insets) -> {
                Insets statusBarInsets = insets.getInsets(WindowInsetsCompat.Type.statusBars());

                // Set dynamic height to fill status bar space
                ViewGroup.LayoutParams layoutParams = statusBarBg.getLayoutParams();
                layoutParams.height = statusBarInsets.top;
                statusBarBg.setLayoutParams(layoutParams);

                return insets;
            });

            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.llAdView),
                    (view, windowInsets) -> {
                        Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.navigationBars());
                        view.setPadding(0, 0, 0, insets.bottom);
                        return windowInsets;
                    });

        }

        CommonUtilities.initImageLoader(this);
        loadMediaFileFromStorage();


        llAdView = findViewById(R.id.llAdView);
        llAdViewFacebook = findViewById(R.id.llAdViewFacebook);

        if (CommonUtilities.getPref(this, CommonConstants.AD_TYPE_FB_GOOGLE, "").equals(CommonConstants.AD_GOOGLE) &&
                CommonUtilities.getPref(this, CommonConstants.STATUS_ENABLE_DISABLE, "").equals(CommonConstants.ENABLE)) {
            CommonConstantAd.loadBannerGoogleAd(this, llAdView);
            llAdViewFacebook.setVisibility(View.GONE);
            llAdView.setVisibility(View.VISIBLE);
        } else if (CommonUtilities.getPref(this, CommonConstants.AD_TYPE_FB_GOOGLE, "").equals(CommonConstants.AD_FACEBOOK)
                &&
                CommonUtilities.getPref(this, CommonConstants.STATUS_ENABLE_DISABLE, "").equals(CommonConstants.ENABLE)) {
            llAdViewFacebook.setVisibility(View.VISIBLE);
            llAdView.setVisibility(View.GONE);
            CommonConstantAd.loadFacebookBannerAd(this, llAdViewFacebook);
        } else {
            llAdView.setVisibility(View.GONE);
            llAdViewFacebook.setVisibility(View.GONE);
        }
    }

    private void initViews() {
        mediaClassArrayList = new ArrayList<>();

        Toolbar mToolbar = findViewById(R.id.toolbarActMediaSel);
        setSupportActionBar(mToolbar);

        rvMediaList = findViewById(R.id.rvMediaListActMediaSel);

        fastScroller = findViewById(R.id.fastScrollerActMediaSel);
        fastScroller.setRecyclerView(rvMediaList);

        mMediaListAdapter = new MediaListAdapter(this, mediaClassArrayList, MediaSelectActivity.this);
        rvMediaList.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        rvMediaList.setAdapter(mMediaListAdapter);
    }

    private void loadMediaFileFromStorage() {
        mediaClassArrayList.clear();
        mediaClassArrayList.addAll(CommonUtilities.getSongList(getApplicationContext(), false, ""));
        mMediaListAdapter.updateData(mediaClassArrayList);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && data != null) {
            String key = CommonConstants.KeyIsRecordUpdated;
            if (data.hasExtra(key)) {
                if (data.getBooleanExtra(key, false)) {
                    recordUpdated = true;
                    onBackPressed();
                }
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.select_options, menu);
        searchView = (SearchView) MenuItemCompat.getActionView(menu.findItem(R.id.menu_search));
        menu.findItem(R.id.menu_search).setVisible(true);
        searchView.setIconifiedByDefault(false);
        searchView.setIconified(false);
        searchView.clearFocus();
        searchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        mediaClassArrayList.clear();
        mediaClassArrayList.addAll(CommonUtilities.getSongList(getApplicationContext(), false, newText));
        mMediaListAdapter.updateData(mediaClassArrayList);
        return false;
    }

    @Override
    public void onItemTypeCallback(View view, int mType, int mPos) {
        if (mType == 0) {
            if (Integer.parseInt(mediaClassArrayList.get(mPos).mDuration) > 10000) {
                CommonUtilities.startMediaEditActivity(MediaSelectActivity.this, MediaEditActivity.class, mediaClassArrayList.get(mPos));
            }else {
                Toast.makeText(this, "Song Duration is less then 10 second ", Toast.LENGTH_SHORT).show();
            }
            Log.e("TAG", "onItemTypeCallback::::::::: " + mediaClassArrayList.get(mPos).mDuration + "  " + mediaClassArrayList.get(mPos).mSongsName);
        } else if (mType == 1) {
            onPopUpMenuClickListener(view, mPos);
        }
    }

    public void onPopUpMenuClickListener(View view, final int position) {
        final PopupMenu menu = new PopupMenu(this, view);
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.popup_song_edit:
                        CommonUtilities.startMediaEditActivity(MediaSelectActivity.this, MediaEditActivity.class, mediaClassArrayList.get(position));
                        break;
                    case R.id.popup_song_set_default_ringtone:
                        CommonUtilities.setAsDefaultRingtoneOrNotification(MediaSelectActivity.this, mediaClassArrayList.get(position));
                        break;
                    case R.id.popup_song_assign_to_contact:
                        CommonUtilities.chooseContactForRingtone(MediaSelectActivity.this, ChooseContactActivity.class, mediaClassArrayList.get(position));
                        break;

                }
                return false;
            }
        });
        menu.inflate(R.menu.popup_media_list_item_click);
        menu.show();
    }

    @Override
    public void onBackPressed() {
        if (searchView != null && !searchView.isIconified()) {
            searchView.setIconified(true);
        }
        if (recordUpdated) {
            CommonUtilities.setResultAndFinish(MediaSelectActivity.this);
        } else {
            finish();
        }
    }
}