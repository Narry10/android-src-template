package com.ninetynineapps.mp3cutter.pojo;

public class ContactsClass {

    public String mName;
    public String mContactId;

    public ContactsClass(String name, String contactId) {
        mName = name;
        mContactId = contactId;
    }
}
