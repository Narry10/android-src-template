package com.ninetynineapps.mp3cutter.activities;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatSeekBar;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;


import com.ninetynineapps.mp3cutter.R;
import com.ninetynineapps.mp3cutter.common.CommonConstantAd;
import com.ninetynineapps.mp3cutter.common.CommonConstants;
import com.ninetynineapps.mp3cutter.common.CommonUtilities;
import com.ninetynineapps.mp3cutter.pojo.MediaClass;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;

public class PlayerActivity extends AppCompatActivity implements View.OnClickListener,
        SeekBar.OnSeekBarChangeListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnErrorListener, MediaPlayer.OnCompletionListener {

    private AppCompatImageView imgBack;
    private AppCompatImageView imgInfo;

    private AppCompatImageView imgMedia;
    private AppCompatTextView tvSongName;
    private AppCompatTextView tvArtist;
    private AppCompatImageView imgPre;
    private AppCompatImageView imgPlayPause;
    private AppCompatImageView imgNext;

    private AppCompatTextView tvStart;
    private AppCompatSeekBar seekBarVol;
    private AppCompatTextView tvEnd;

    private MediaPlayer mp = null;
    //private AudioManager audioManager;
    private DisplayImageOptions builder;

    private ArrayList<MediaClass> mediaClassArrayList;
    private int itemPos = 0;
    private int colorGrey = 0;
    private int colorLightGrey = 0;
    RelativeLayout llAdView;
    LinearLayout llAdViewFacebook;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        initViews();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM) {

            View statusBarBg = findViewById(R.id.statusBarBg);
            View mainContent = findViewById(R.id.mainContent);

            WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

            ViewCompat.setOnApplyWindowInsetsListener(mainContent, (v, insets) -> {
                Insets statusBarInsets = insets.getInsets(WindowInsetsCompat.Type.statusBars());

                // Set dynamic height to fill status bar space
                ViewGroup.LayoutParams layoutParams = statusBarBg.getLayoutParams();
                layoutParams.height = statusBarInsets.top;
                statusBarBg.setLayoutParams(layoutParams);

                return insets;
            });

            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.llAdView),
                    (view, windowInsets) -> {
                        Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.navigationBars());
                        view.setPadding(0, 0, 0, insets.bottom);
                        return windowInsets;
                    });

        }

        loadDefaults();
        loadDataFromIntent();

    }

    private void initViews() {
        colorGrey = ContextCompat.getColor(this, R.color.colorGrey);
        colorLightGrey = ContextCompat.getColor(this, R.color.colorLightGrey);

        mediaClassArrayList = new ArrayList<>();

        imgBack = findViewById(R.id.imgBack);
        imgInfo = findViewById(R.id.imgInfo);

        imgMedia = findViewById(R.id.imgMedia);

        tvSongName = findViewById(R.id.tvSongName);
        tvArtist = findViewById(R.id.tvArtist);

        imgPre = findViewById(R.id.imgPre);
        imgPlayPause = findViewById(R.id.imgPlayPause);
        imgNext = findViewById(R.id.imgNext);

        tvStart = findViewById(R.id.tvStart);
        seekBarVol = findViewById(R.id.seekBarVol);
        tvEnd = findViewById(R.id.tvEnd);

        imgBack.setOnClickListener(this);
        imgInfo.setOnClickListener(this);
        imgPre.setOnClickListener(this);
        imgPlayPause.setOnClickListener(this);
        imgNext.setOnClickListener(this);

        llAdView = findViewById(R.id.llAdView);
        llAdViewFacebook = findViewById(R.id.llAdViewFacebook);

        if (CommonUtilities.getPref(this, CommonConstants.AD_TYPE_FB_GOOGLE, "").equals(CommonConstants.AD_GOOGLE) &&
                CommonUtilities.getPref(this, CommonConstants.STATUS_ENABLE_DISABLE, "").equals(CommonConstants.ENABLE)) {
            CommonConstantAd.loadBannerGoogleAd(this, llAdView);
            llAdViewFacebook.setVisibility(View.GONE);
            llAdView.setVisibility(View.VISIBLE);
        } else if (CommonUtilities.getPref(this, CommonConstants.AD_TYPE_FB_GOOGLE, "").equals(CommonConstants.AD_FACEBOOK)
                &&
                CommonUtilities.getPref(this, CommonConstants.STATUS_ENABLE_DISABLE, "").equals(CommonConstants.ENABLE)) {
            llAdViewFacebook.setVisibility(View.VISIBLE);
            llAdView.setVisibility(View.GONE);
            CommonConstantAd.loadFacebookBannerAd(this, llAdViewFacebook);
        } else {
            llAdView.setVisibility(View.GONE);
            llAdViewFacebook.setVisibility(View.GONE);
        }
    }

    private void loadDefaults() {
        try {
            builder = new DisplayImageOptions.Builder().cacheInMemory(true)
                    .showImageOnFail(R.drawable.ic_music_default)
                    .showImageOnLoading(R.drawable.ic_music_default)
                    .resetViewBeforeLoading(true)
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
        }

//For Volume Control
//            try {
//                audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
//                if (audioManager != null) {
//                    int currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
//                    int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
//                    seekBarVol.setMax(maxVolume);
//                    seekBarVol.setProgress(currentVolume);
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
        seekBarVol.setOnSeekBarChangeListener(this);
    }

    private void loadDataFromIntent() {
        try {
            Intent intent = getIntent();
            if (intent != null && intent.hasExtra(CommonConstants.KeyMediaClassArrayList)) {
                mediaClassArrayList = (ArrayList<MediaClass>) intent.getSerializableExtra(CommonConstants.KeyMediaClassArrayList);
                itemPos = intent.getIntExtra(CommonConstants.KeyItemPos, 0);
                if (itemPos == 0) {
                    imgPre.setColorFilter(colorLightGrey);
                }
                if (itemPos == (mediaClassArrayList.size() - 1)) {
                    imgNext.setColorFilter(colorLightGrey);
                }
                loadAndPlayMedia(mediaClassArrayList.get(itemPos));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//For Volume Control
//    @Override
//    public boolean onKeyDown(int keyCode, KeyEvent event) {
//        try {
//            switch (keyCode) {
//                case KeyEvent.KEYCODE_VOLUME_UP: {
//                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
//                    seekBarVol.setProgress(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) + AudioManager.ADJUST_RAISE);
//                    return true;
//                }
//                case KeyEvent.KEYCODE_VOLUME_DOWN: {
//                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
//                    seekBarVol.setProgress(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) + AudioManager.ADJUST_LOWER);
//                    return true;
//                }
//                case KeyEvent.KEYCODE_BACK: {
//                    finish();
//                    return true;
//                }
//                default: {
//                    return false;
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return false;
//    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.imgBack) {
            onBackPressed();
        } else if (id == R.id.imgInfo) {
            if (mediaClassArrayList.size() != 0) {
                openInfoDialog(this, mediaClassArrayList.get(itemPos));
            }
        } else if (id == R.id.imgPre) {
            try {
                if (itemPos != 0) {
                    if (itemPos < mediaClassArrayList.size()) {
                        imgPlayPause.setImageResource(R.drawable.ic_play);
                        itemPos = itemPos - 1;
                        loadAndPlayMedia(mediaClassArrayList.get(itemPos));

                        imgNext.setColorFilter(colorGrey);
                        if (itemPos == 0) {
                            imgPre.setColorFilter(colorLightGrey);
                        } else {
                            imgPre.setColorFilter(colorGrey);
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (id == R.id.imgPlayPause) {
            try {
                if (mp.isPlaying()) {
                    mp.pause();
                    mSeekbarUpdateHandler.removeCallbacks(mUpdateSeekbar);
                    imgPlayPause.setImageResource(R.drawable.ic_play);
                } else {
                    mp.start();
                    mSeekbarUpdateHandler.postDelayed(mUpdateSeekbar, 0);
                    imgPlayPause.setImageResource(R.drawable.ic_pause);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (id == R.id.imgNext) {
            try {
                if (itemPos != (mediaClassArrayList.size() - 1)) {
                    imgPlayPause.setImageResource(R.drawable.ic_play);
                    itemPos = itemPos + 1;
                    loadAndPlayMedia(mediaClassArrayList.get(itemPos));

                    imgPre.setColorFilter(colorGrey);
                    if (itemPos == (mediaClassArrayList.size() - 1)) {
                        imgNext.setColorFilter(colorLightGrey);
                    } else {
                        imgNext.setColorFilter(colorGrey);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        try {
            if (mp != null && mp.isPlaying()) {
                if (fromUser) {
                    mp.seekTo(progress);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            tvStart.setText(CommonUtilities.makeShortTimeString(PlayerActivity.this, progress / 1000));
        } catch (Exception e) {
            e.printStackTrace();
        }
        //For Volume Control
//        try {
//            if (audioManager != null) {
//                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
//                seekBarVol.setProgress(progress);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        try {
            imgPlayPause.setImageResource(R.drawable.ic_pause);
            mp.start();

            seekBarVol.setMax(mp.getDuration());
            seekBarVol.setProgress(0);

            mSeekbarUpdateHandler.postDelayed(mUpdateSeekbar, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        return false;
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        try {
            imgPlayPause.setImageResource(R.drawable.ic_play);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Handler mSeekbarUpdateHandler = new Handler();
    private Runnable mUpdateSeekbar = new Runnable() {
        @Override
        public void run() {
            try {
                if (mp != null) {
                    seekBarVol.setProgress(mp.getCurrentPosition());
                    mSeekbarUpdateHandler.postDelayed(this, 1000);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private void loadAndPlayMedia(MediaClass aClass) {
        try {
//            ImageLoader.getInstance().displayImage(CommonUtilities.getAlbumArtUri(Long.parseLong(aClass.mAlbumId)).toString(),
            ImageLoader.getInstance().displayImage(CommonUtilities.getExtUri(aClass.mAlbumId).toString(),
                    imgMedia,
                    builder);
        } catch (Exception e) {
            e.printStackTrace();
        }

        tvEnd.setText(CommonUtilities.makeShortTimeString(this, Integer.parseInt(aClass.mDuration) / 1000));

        tvSongName.setText(aClass.mSongsName);
        tvArtist.setText(aClass.mArtistName);

        imgPlayPause.setImageResource(R.drawable.ic_play);

        try {
            if (mp == null) {
                mp = new MediaPlayer();
            } else {
                mp.stop();
                mp.reset();
                mp.release();
                mp = null;
                mp = new MediaPlayer();
            }
            mp.setDataSource(aClass.mPath);

            mp.setOnPreparedListener(this);
            mp.setOnErrorListener(this);
            mp.setOnCompletionListener(this);

            mp.prepare();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private AlertDialog infoDialog = null;

    private void openInfoDialog(Context context, MediaClass aClass) {
        try {
            if (infoDialog == null) {
                int margin = (int) getResources().getDimension(R.dimen.twenty_dp);
                LinearLayout llInfo = (LinearLayout) LayoutInflater.from(this).inflate(R.layout.dialog_media_info, null);

                AppCompatTextView tvMediaName = llInfo.findViewById(R.id.tvMediaName);
                AppCompatTextView tvArtistName = llInfo.findViewById(R.id.tvArtistName);
                AppCompatTextView tvDuration = llInfo.findViewById(R.id.tvDuration);
                AppCompatTextView tvPath = llInfo.findViewById(R.id.tvPath);
                AppCompatTextView tvDate = llInfo.findViewById(R.id.tvDate);

                tvMediaName.setText(aClass.mSongsName);
                tvArtistName.setText(aClass.mArtistName);
                tvDuration.setText(CommonUtilities.makeShortTimeString(context.getApplicationContext(), Integer.parseInt(aClass.mDuration) / 1000));
                tvPath.setText(aClass.mPath);
                tvDate.setText(CommonUtilities.getFullDateTimeInDisplayFormatFromMillis(aClass.mDateAdded));

                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setMessage(CommonConstants.CapInfo);
                builder.setCancelable(false);
                LinearLayout llMain = new LinearLayout(context);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                layoutParams.setMargins(margin, 0, margin, 0);

                llInfo.setLayoutParams(layoutParams);
                llMain.addView(llInfo);
                builder.setView(llMain);
                builder.setNegativeButton(CommonConstants.CapClose, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                infoDialog = builder.create();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            if (!infoDialog.isShowing()) {
                infoDialog.show();
                infoDialog = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        releaseMediaPlayer();
        super.onDestroy();
    }

    private void releaseMediaPlayer() {
        try {
            if (mp != null) {
                if (mp.isPlaying()) {
                    mp.stop();
                }
                mp.reset();
                mp.release();
            }
            mSeekbarUpdateHandler.removeCallbacks(mUpdateSeekbar);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}