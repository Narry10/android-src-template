package com.ninetynineapps.mp3cutter.pushnotification;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.StrictMode;
import android.text.format.DateUtils;
import android.util.Log;
import android.widget.RemoteViews;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.google.gson.Gson;
import com.ninetynineapps.mp3cutter.R;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class FirebaseService extends FirebaseMessagingService {

    @Override
    public void onNewToken(@NonNull String s) {
        super.onNewToken(s);
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        generateNotification(remoteMessage);
    }

    private void generateNotification(RemoteMessage remoteMessage) {
        try {
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            Intent mIntent = null;
            String channelId = "11111";


            try {
                String channelName = getResources().getString(R.string.app_name);
                String channelDescription = "Application_name Alert";
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    Integer importance = NotificationManager.IMPORTANCE_HIGH;
                    NotificationChannel notificationChannel = new NotificationChannel(channelId,channelName,importance);
                    notificationChannel.setDescription(channelDescription);
                    notificationChannel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),notificationChannel.getAudioAttributes());
                    notificationManager.createNotificationChannel(notificationChannel);
                }
            } catch (Resources.NotFoundException e) {
                e.printStackTrace();
            }

            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId);
            RemoteViews expandedView = new RemoteViews(getPackageName(), R.layout.item_notification_expand);
            RemoteViews collapsedView = new RemoteViews(getPackageName(), R.layout.item_notification_coll);


            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                builder.setSmallIcon(R.drawable.notification_icon);
                builder.setColor( ContextCompat.getColor(this, R.color.colorBlack));
                expandedView.setImageViewResource(R.id.big_icon, R.mipmap.ic_launcher);
                expandedView.setTextViewText(
                        R.id.timestamp,
                        DateUtils.formatDateTime(
                                this,
                                System.currentTimeMillis(),
                                DateUtils.FORMAT_SHOW_TIME
                        )
                );

                collapsedView.setImageViewResource(R.id.big_icon, R.mipmap.ic_launcher);
                collapsedView.setTextViewText(
                        R.id.timestamp,
                        DateUtils.formatDateTime(
                                this,
                                System.currentTimeMillis(),
                                DateUtils.FORMAT_SHOW_TIME
                        )
                );
            }
            else {
                builder.setSmallIcon(R.drawable.notification_icon);

                expandedView.setImageViewResource(R.id.big_icon, R.mipmap.ic_launcher);
                expandedView.setTextViewText(
                        R.id.timestamp,
                        DateUtils.formatDateTime(
                                this,
                                System.currentTimeMillis(),
                                DateUtils.FORMAT_SHOW_TIME
                        )
                );

                collapsedView.setImageViewResource(R.id.big_icon, R.mipmap.ic_launcher);
                collapsedView.setTextViewText(
                        R.id.timestamp,
                        DateUtils.formatDateTime(
                                this,
                                System.currentTimeMillis(),
                                DateUtils.FORMAT_SHOW_TIME
                        )
                );

            }


            String title = getResources().getString(R.string.app_name);
            RemoteMessage.Notification data = remoteMessage.getNotification();
            if (data != null){
                mIntent.putExtra("notificationData", new Gson().toJson(remoteMessage.getData()));
                Log.e("TAG", "generateNotification:::INTENT:::::  ${Gson().toJson(p0.data)}  ");
                mIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                try {
                    expandedView.setTextViewText(R.id.title_text, data.getTitle());

                    expandedView.setTextViewText(R.id.notification_message, data.getBody());

                    collapsedView.setTextViewText(R.id.content_text, data.getBody());

                    collapsedView.setTextViewText(R.id.title_text, data.getTitle());
                    StrictMode.ThreadPolicy  policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);

                    URL image1Url = new URL(data.getImageUrl().toString());
                    Bitmap bmp1 = BitmapFactory.decodeStream(image1Url.openConnection().getInputStream());

                    if (bmp1 != null) {
                        builder.setStyle(
                                new NotificationCompat.BigPictureStyle().bigPicture(bmp1)
                                        .setSummaryText(data.getBody())
                        );
                        expandedView.setBitmap(R.id.notification_img, "setImageBitmap", bmp1);
                    }


                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }else {
                mIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                builder.setContentText(title);
            }

            builder.setCustomContentView(collapsedView);
            builder.setCustomBigContentView(expandedView);
            builder.setShowWhen(false);
            builder.setStyle(new NotificationCompat.DecoratedCustomViewStyle());
            builder.setPriority( NotificationCompat.PRIORITY_HIGH);
            builder.setAutoCancel(true);
            builder.setVisibility(NotificationCompat.VISIBILITY_SECRET);
            long l = System.currentTimeMillis();
            PendingIntent pendingIntent = PendingIntent.getActivity(
                    this,
                    (int) l,
                    mIntent,
                    PendingIntent.FLAG_MUTABLE
                    );

            builder.setContentIntent(pendingIntent);

            builder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
            notificationManager.notify((int) l, builder.build());
        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
        }
    }
}
