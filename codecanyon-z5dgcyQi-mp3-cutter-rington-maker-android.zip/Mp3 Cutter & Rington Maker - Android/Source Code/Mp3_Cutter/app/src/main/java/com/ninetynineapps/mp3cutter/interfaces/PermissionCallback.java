package com.ninetynineapps.mp3cutter.interfaces;

import android.view.View;

public interface PermissionCallback {
    void PermissionGrant(View view,int pos);
}
