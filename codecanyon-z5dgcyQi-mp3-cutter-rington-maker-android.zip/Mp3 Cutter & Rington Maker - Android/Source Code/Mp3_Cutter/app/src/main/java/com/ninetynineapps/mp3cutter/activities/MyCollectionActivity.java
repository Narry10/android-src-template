package com.ninetynineapps.mp3cutter.activities;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;
import com.ninetynineapps.mp3cutter.R;
import com.ninetynineapps.mp3cutter.adapters.MediaListAdapter;
import com.ninetynineapps.mp3cutter.common.CommonConstantAd;
import com.ninetynineapps.mp3cutter.common.CommonConstants;
import com.ninetynineapps.mp3cutter.common.CommonUtilities;
import com.ninetynineapps.mp3cutter.interfaces.AdapterItemViewTypeCallback;
import com.ninetynineapps.mp3cutter.interfaces.CallbackListener;
import com.ninetynineapps.mp3cutter.interfaces.PermissionCallback;
import com.ninetynineapps.mp3cutter.pojo.MediaClass;

import java.io.File;
import java.util.ArrayList;

public class MyCollectionActivity extends AppCompatActivity implements View.OnClickListener, AdapterItemViewTypeCallback, PermissionCallback, CallbackListener {

    private AppCompatImageView imgAdd;
    private AppCompatImageView imgOption;

    private LinearLayout llPermission;
    private AppCompatTextView tvAllow;

    private RecyclerView rvMediaList;
    private MediaListAdapter mMediaListAdapter;
    private LinearLayout llNoData;

    private ArrayList<MediaClass> mediaClassArrayList;
    private ArrayList<MediaClass> mediaClassArrayList_audio;

    private boolean startNextActivity = true;

    RelativeLayout llAdView;
    LinearLayout llAdViewFacebook;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_collection);
        initViews();
        successCall();

        try {
            //subScribeToFirebaseTopic();
        } catch (Exception e) {
            e.printStackTrace();
        }

        llAdView = findViewById(R.id.llAdView);
        llAdViewFacebook = findViewById(R.id.llAdViewFacebook);

        if (CommonUtilities.getPref(this, CommonConstants.AD_TYPE_FB_GOOGLE, "").equals(CommonConstants.AD_GOOGLE) &&
                CommonUtilities.getPref(this, CommonConstants.STATUS_ENABLE_DISABLE, "").equals(CommonConstants.ENABLE)) {
            CommonConstantAd.loadBannerGoogleAd(this, llAdView);
            llAdViewFacebook.setVisibility(View.GONE);
            llAdView.setVisibility(View.VISIBLE);
        } else if (CommonUtilities.getPref(this, CommonConstants.AD_TYPE_FB_GOOGLE, "").equals(CommonConstants.AD_FACEBOOK)
                &&
                CommonUtilities.getPref(this, CommonConstants.STATUS_ENABLE_DISABLE, "").equals(CommonConstants.ENABLE)) {
            llAdViewFacebook.setVisibility(View.VISIBLE);
            llAdView.setVisibility(View.GONE);
            CommonConstantAd.loadFacebookBannerAd(this, llAdViewFacebook);
        } else {
            llAdView.setVisibility(View.GONE);
            llAdViewFacebook.setVisibility(View.GONE);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            checkPermission();
        }
    }
    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    private void checkPermission() {
        if (ContextCompat.checkSelfPermission(MyCollectionActivity.this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MyCollectionActivity.this, new String[]{Manifest.permission.POST_NOTIFICATIONS},101);
        }

    }

    private void subScribeToFirebaseTopic() {
        try {
            FirebaseMessaging.getInstance().subscribeToTopic("mp3_cutter_topic")
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (!task.isSuccessful()) {
                                Log.e("subScribeFirebaseTopic", ": Fail");
                            } else {
                                Log.e("subScribeFirebaseTopic", ": Success");
                            }
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void successCall() {
        if (CommonUtilities.isNetworkConnected(this)) {
            if (CommonConstants.ENABLE_DISABLE.equals(CommonConstants.ENABLE)) {

                CommonUtilities.setPref(MyCollectionActivity.this, CommonConstants.AD_TYPE_FB_GOOGLE, CommonConstants.AD_TYPE_FACEBOOK_GOOGLE);
                CommonUtilities.setPref(MyCollectionActivity.this, CommonConstants.FB_BANNER, CommonConstants.FB_BANNER_ID);
                CommonUtilities.setPref(MyCollectionActivity.this, CommonConstants.FB_INTERSTITIAL, CommonConstants.FB_INTERSTITIAL_ID);
                CommonUtilities.setPref(MyCollectionActivity.this, CommonConstants.GOOGLE_BANNER, CommonConstants.GOOGLE_BANNER_ID);
                CommonUtilities.setPref(MyCollectionActivity.this, CommonConstants.GOOGLE_INTERSTITIAL, CommonConstants.GOOGLE_INTERSTITIAL_ID);
                CommonUtilities.setPref(MyCollectionActivity.this, CommonConstants.STATUS_ENABLE_DISABLE, CommonConstants.ENABLE_DISABLE);

                setAppAdId(CommonConstants.GOOGLE_ADMOB_APP_ID);
            } else {
                CommonUtilities.setPref(MyCollectionActivity.this, CommonConstants.STATUS_ENABLE_DISABLE, CommonConstants.ENABLE_DISABLE);
            }
        } else {
            CommonUtilities.openInternetDialog(this, this, true);
        }
    }


    public void setAppAdId(String id) {
        try {
            ApplicationInfo applicationInfo = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = applicationInfo.metaData;
            String beforeChangeId = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");
            Log.e("TAG", "setAppAdId:BeforeChange:::::  " + beforeChangeId);
            applicationInfo.metaData.putString("com.google.android.gms.ads.APPLICATION_ID", id);
            String AfterChangeId = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");
            Log.e("TAG", "setAppAdId:AfterChange::::  " + AfterChangeId);
        } catch (PackageManager.NameNotFoundException | NullPointerException e) {
            e.printStackTrace();
        }

    }

    private void initViews() {
        try {
            mediaClassArrayList = new ArrayList<>();
            mediaClassArrayList_audio = new ArrayList<>();

            String status = Environment.getExternalStorageState();
            if (status.equals(Environment.MEDIA_MOUNTED_READ_ONLY)) {
                CommonUtilities.showAlertFinishOnClick(this, true, CommonConstants.CapError, CommonConstants.MsgSDCardReadOnly, true, CommonConstants.CapOk, false, "");
                return;
            }
            if (status.equals(Environment.MEDIA_SHARED)) {
                CommonUtilities.showAlertFinishOnClick(this, true, CommonConstants.CapError, CommonConstants.MsgSDCardShared, true, CommonConstants.CapOk, false, "");
                return;
            }
            if (!status.equals(Environment.MEDIA_MOUNTED)) {
                CommonUtilities.showAlertFinishOnClick(this, true, CommonConstants.CapError, CommonConstants.MsgNoSDCard, true, CommonConstants.CapOk, false, "");
                return;
            }

            imgAdd = findViewById(R.id.imgAdd);
            imgOption = findViewById(R.id.imgOption);

            llPermission = findViewById(R.id.llPermission);
            tvAllow = findViewById(R.id.tvAllow);

            rvMediaList = findViewById(R.id.rvMediaList);

            mMediaListAdapter = new MediaListAdapter(this, mediaClassArrayList, MyCollectionActivity.this);
            rvMediaList.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            rvMediaList.setAdapter(mMediaListAdapter);

            llNoData = findViewById(R.id.llNoData);

            CommonUtilities.initImageLoader(this);

            imgAdd.setOnClickListener(this);
            imgOption.setOnClickListener(this);

            tvAllow.setOnClickListener(this);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM) {

                View statusBarBg = findViewById(R.id.statusBarBg);
                View mainContent = findViewById(R.id.mainContent);

                WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

                ViewCompat.setOnApplyWindowInsetsListener(mainContent, (v, insets) -> {
                    Insets statusBarInsets = insets.getInsets(WindowInsetsCompat.Type.statusBars());

                    // Set dynamic height to fill status bar space
                    ViewGroup.LayoutParams layoutParams = statusBarBg.getLayoutParams();
                    layoutParams.height = statusBarInsets.top;
                    statusBarBg.setLayoutParams(layoutParams);

                    return insets;
                });

                ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.llAdView),
                        (view, windowInsets) -> {
                            Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.navigationBars());
                            view.setPadding(0, 0, 0, insets.bottom);
                            return windowInsets;
                        });

            }

            if (CommonUtilities.checkRequiredPermission(this)) {
                loadMediaFileFromStorage();
            } else {
                llPermission.setVisibility(View.VISIBLE);
                rvMediaList.setVisibility(View.GONE);
                llNoData.setVisibility(View.GONE);
                imgAdd.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Log.e("TAG", "initViews:::::Paths:::  " + getFilesDir() + "/" + Environment.DIRECTORY_DOWNLOADS + "   " + getExternalFilesDir(Environment.DIRECTORY_MUSIC));
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.imgAdd) {
            if (CommonUtilities.checkRequiredPermission(this)) {
                startActivityForResult(new Intent(this, MediaSelectActivity.class), CommonConstants.RequestCodeRecordUpdated);
            } else {
                startNextActivity = true;
                CommonUtilities.requestRequiredPermission(MyCollectionActivity.this);
            }
        } else if (id == R.id.imgOption) {
            openMorePopUp(view);
        } else if (id == R.id.tvAllow) {
            if (CommonUtilities.checkRequiredPermission(this)) {
                loadMediaFileFromStorage();
            } else {
                startNextActivity = false;
                CommonUtilities.requestRequiredPermission(MyCollectionActivity.this);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case CommonConstants.RequestCodePermission: {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                    if (grantResults.length > 0 &&
                            grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                            grantResults[1] == PackageManager.PERMISSION_GRANTED &&
                            grantResults[2] == PackageManager.PERMISSION_GRANTED) {
                        if (startNextActivity) {
                            startActivity(new Intent(this, MediaSelectActivity.class));
                        } else {
                            loadMediaFileFromStorage();
                        }
                    }
                } else {
                    if (grantResults.length > 0 &&
                            grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                            grantResults[1] == PackageManager.PERMISSION_GRANTED &&
                            grantResults[2] == PackageManager.PERMISSION_GRANTED &&
                            grantResults[3] == PackageManager.PERMISSION_GRANTED) {
                        if (startNextActivity) {
                            startActivity(new Intent(this, MediaSelectActivity.class));
                        } else {
                            loadMediaFileFromStorage();
                        }
                    }
                }
                break;
            }
        }
    }

    private void loadMediaFileFromStorage() {

        llPermission.setVisibility(View.GONE);
        imgAdd.setVisibility(View.VISIBLE);

        mediaClassArrayList = new ArrayList<>();
        mediaClassArrayList.addAll(CommonUtilities.getSongList(getApplicationContext(), true, ""));

        Log.e("TAG", "loadMediaFileFromStorage:MESIA:::::::  " + mediaClassArrayList_audio.size());
        if (mediaClassArrayList.size() > 0) {
            mMediaListAdapter.updateData(mediaClassArrayList);
            llNoData.setVisibility(View.GONE);
            rvMediaList.setVisibility(View.VISIBLE);
        } else {
            llNoData.setVisibility(View.VISIBLE);
            rvMediaList.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && data != null) {
            String key = CommonConstants.KeyIsRecordUpdated;
            if (data.hasExtra(key)) {
                if (data.getBooleanExtra(key, false)) {
                    loadMediaFileFromStorage();
                }
            }
        }
    }

    @Override
    public void onItemTypeCallback(View view, int mType, int mPos) {
        if (mType == 0) {
            CommonUtilities.startPlayerActivity(MyCollectionActivity.this, PlayerActivity.class, mediaClassArrayList, mPos);
        } else if (mType == 1) {
            onPopUpMenuClickListener(this, view, mPos);
            /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    onPopUpMenuClickListener(this, view, mPos);
                } else {
                    CommonUtilities.showSettingsDialog(true, getString(R.string.allow_title), getString(R.string.you_need_to),
                            MyCollectionActivity.this);
                }
            } else {
                CommonUtilities.checkPermission(MyCollectionActivity.this,MyCollectionActivity.this,view,mPos);

            }*/

        }
    }

    @Override
    public void PermissionGrant(View view, int pos) {
        onPopUpMenuClickListener(this, view, pos);
    }

    //Todo ------------------------------ Item Click Menu ------------------------------
    public void onPopUpMenuClickListener(final Context context, View view, final int position) {
        try {
            final PopupMenu menu = new PopupMenu(this, view);
            menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.my_col_edit:
                            CommonUtilities.startMediaEditActivity(MyCollectionActivity.this,
                                    MediaEditActivity.class, mediaClassArrayList.get(position));
                            break;
                        case R.id.my_col_rename:
                            openRenameCatNameDialog(context, mediaClassArrayList.get(position));
                            break;
                        case R.id.my_col_delete:
                            confirmDelete(context, mediaClassArrayList.get(position));


                            break;
                        case R.id.my_col_share:
                            shareMediaFile(mediaClassArrayList.get(position).mPath);
                            break;
                        case R.id.my_col_set_default_ringtone:
                            CommonUtilities.setAsDefaultRingtoneOrNotification(MyCollectionActivity.this, mediaClassArrayList.get(position));
                            break;
                        case R.id.my_col_assign_to_contact:
                            CommonUtilities.chooseContactForRingtone(MyCollectionActivity.this, ChooseContactActivity.class, mediaClassArrayList.get(position));
                            break;
                    }
                    return false;
                }
            });
            menu.inflate(R.menu.popup_my_collection_item_click);
            menu.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void confirmDelete(final Context context, final MediaClass aClass) {
        CharSequence message;
        message = getResources().getText(R.string.hint_confirm_delete);

        CharSequence title;
        if (aClass.mFileType.equalsIgnoreCase(CommonConstants.IS_RINGTONE)) {
            title = getResources().getText(R.string.delete_ringtone);
        } else if (aClass.mFileType.equalsIgnoreCase(CommonConstants.IS_ALARM)) {
            title = getResources().getText(R.string.delete_alarm);
        } else if (aClass.mFileType.equalsIgnoreCase(CommonConstants.IS_NOTIFICATION)) {
            title = getResources().getText(R.string.delete_notification);
        } else if (aClass.mFileType.equalsIgnoreCase(CommonConstants.IS_MUSIC)) {
            title = getResources().getText(R.string.delete_music);
        } else {
            title = getResources().getText(R.string.delete_audio);
        }

        new AlertDialog.Builder(context)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(CommonConstants.CapDelete, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        if (CommonUtilities.deleteFileFromStorage(context, aClass.mPath)) {
                            try {
                                if (CommonUtilities.deleteFileWithCursor(context, aClass._ID)) {
                                    Log.e("<><>", "Delete successful");
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            Log.e("<><>", "Delete successful");
                            Toast.makeText(context, CommonConstants.MsgFileDeleteSuccessfully, Toast.LENGTH_SHORT).show();
                        } else {
                            Log.e("<><>", "Delete failed");
                            Toast.makeText(context, CommonConstants.MsgSomethingWrong, Toast.LENGTH_SHORT).show();
                        }
                        dialog.dismiss();
                        loadMediaFileFromStorage();
                    }
                })
                .setNegativeButton(CommonConstants.CapCancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();
                    }
                })
                .setCancelable(true)
                .show();
    }

    private void shareMediaFile(String path) {
        try {
            Uri shareUri;
            File file = new File(path);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Uri uri1 = Uri.fromFile(file);
                shareUri = Uri.parse(CommonUtilities.getFilePath(this, uri1));
            } else {
                shareUri = Uri.fromFile(file);
            }

            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_SEND);
            intent.setType("audio/*");
            intent.putExtra(Intent.EXTRA_STREAM, shareUri);
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void openRenameCatNameDialog(final Context context, final MediaClass aClass) {
        int margin = (int) getResources().getDimension(R.dimen.twenty_dp);

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        alertDialog.setTitle(CommonConstants.CapMessage);
        alertDialog.setMessage(CommonConstants.MsgRenameFile);

        LinearLayout linearLayout = new LinearLayout(context);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.setMargins(margin, 0, margin, 0);

        final AppCompatEditText etCatName = new AppCompatEditText(context);
        etCatName.setText(aClass.mSongsName);
        etCatName.setLayoutParams(layoutParams);
        linearLayout.addView(etCatName);

        alertDialog.setView(linearLayout);
        alertDialog.setPositiveButton(CommonConstants.CapRename, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                try {
                    if (etCatName.getText() != null) {
                        String newCategoryName = etCatName.getText().toString();
                        if (newCategoryName.isEmpty()) {
                            Toast.makeText(context, CommonConstants.MsgEnterFileName, Toast.LENGTH_SHORT).show();
                        } else {


                            if (CommonUtilities.renameFileName(context, aClass.mSongsName, newCategoryName, Long.parseLong(aClass._ID), aClass)) {
                                Log.e("<><>", "Rename successful");
                                mMediaListAdapter.notifyDataSetChanged();
                                Toast.makeText(context, CommonConstants.MsgFileRenameSuccessfully, Toast.LENGTH_SHORT).show();
                            } else {
                                Log.e("<><>", "Rename failed");
                                Toast.makeText(context, CommonConstants.MsgSomethingWrong, Toast.LENGTH_SHORT).show();
                            }
                            dialog.dismiss();
                            loadMediaFileFromStorage();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        alertDialog.setNegativeButton(CommonConstants.CapCancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.show();
    }


    //Todo ------------------------------ Item Click Menu ------------------------------


    //Todo ------------------------------ Common Menu ------------------------------
    private void openMorePopUp(View view) {
        final PopupMenu menu = new PopupMenu(this, view);
        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.menu_rate_sub:
                        rateUs();
                        break;
                    case R.id.menu_contact_sub:
                        contactUs();
                        break;
                    case R.id.menu_share_sub:
                        shareAppLink();
                        break;
                    /*case R.id.menu_more_sub:
                        moreApp();
                        break;*/
                }
                return false;
            }
        });
        menu.inflate(R.menu.more_menu);
        menu.show();
    }

    public void shareAppLink() {
        Intent shareIntent = new Intent();
        shareIntent.setAction(Intent.ACTION_SEND);
        String link = "https://play.google.com/store/apps/details?id=" + getPackageName();
        shareIntent.putExtra(Intent.EXTRA_TEXT, link);
        shareIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name) + " - Android");
        shareIntent.setType("text/plain");
        startActivity(Intent.createChooser(shareIntent, getResources().getString(R.string.app_name) + " - Android"));
    }

    public void contactUs() {
        try {
            Intent sendIntentGmail = new Intent(Intent.ACTION_SEND);
            sendIntentGmail.setType("plain/text");
            sendIntentGmail.setPackage("com.google.android.gm");
            sendIntentGmail.putExtra(Intent.EXTRA_EMAIL, new String[]{"Enter your email"});
            sendIntentGmail.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name) + " - Android");
            startActivity(sendIntentGmail);
        } catch (Exception e) {
            Intent sendIntentIfGmailFail = new Intent(Intent.ACTION_SEND);
            sendIntentIfGmailFail.setType("*/*");
            sendIntentIfGmailFail.putExtra(Intent.EXTRA_EMAIL, new String[]{"Enter your email"});
            sendIntentIfGmailFail.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name) + " - Android");
            if (sendIntentIfGmailFail.resolveActivity(getPackageManager()) != null) {
                startActivity(sendIntentIfGmailFail);
            }
        }
    }

    public void rateUs() {
        String appPackageName = getPackageName();
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
        } catch (android.content.ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
        }
    }

    public void moreApp() {
        Uri uri = Uri.parse("https://play.google.com/store/apps/developer?id=Ninety+Nine+Apps");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }
    //Todo ------------------------------ Common Menu ------------------------------

    boolean doublePressToExit = false;

    @Override
    public void onBackPressed() {
        if (doublePressToExit) {
            super.onBackPressed();
            return;
        }
        doublePressToExit = true;
        Toast.makeText(this, CommonConstants.MsgDoubleBackToExit, Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                doublePressToExit = false;
            }
        }, 2000);
    }


    @Override
    public void onSuccess() {

    }

    @Override
    public void onCancel() {

    }

    @Override
    public void onRetry() {

    }
}