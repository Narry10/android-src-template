package com.ninetynineapps.mp3cutter.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.ninetynineapps.mp3cutter.R;
import com.ninetynineapps.mp3cutter.common.CommonConstantAd;
import com.ninetynineapps.mp3cutter.common.CommonConstants;
import com.ninetynineapps.mp3cutter.common.CommonUtilities;
import com.ninetynineapps.mp3cutter.interfaces.AdsCallback;
import com.ninetynineapps.mp3cutter.interfaces.CallbackListener;

public class SplashActivity extends AppCompatActivity implements CallbackListener , AdsCallback {

    private AppCompatImageView mBellImageView;
    private Boolean isLoaded = false;
    private Handler handler = new Handler();
    private Runnable myRunnable = new Runnable() {
        @Override
        public void run() {
            if (CommonUtilities.isNetworkConnected(SplashActivity.this)) {
                if (!isLoaded) {
                    startNextActivity(0);
                }
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        mBellImageView = findViewById(R.id.imgSplashActSplash);

        Glide.with(this)
                .applyDefaultRequestOptions(new RequestOptions().diskCacheStrategy(DiskCacheStrategy.RESOURCE).centerCrop())
                .load(R.drawable.splash)
                .into(mBellImageView);


        callApi();
    }

    public void startNextActivity(Integer time) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                mBellImageView.clearAnimation();
                startActivity(new Intent(SplashActivity.this, MyCollectionActivity.class));
                finish();
            }
        }, time);

    }

    public void callApi() {
        if (CommonUtilities.isNetworkConnected(this)) {
            successCall();
        } else {
            CommonUtilities.openInternetDialog(this,this, true);
        }

        handler.postDelayed(myRunnable, 10000);
    }



    private void successCall() {
        if (CommonUtilities.getPref(this, CommonConstants.SPLASH_SCREEN_COUNT, 1) == 1) {
            Log.e("TAG", "successCall::::IFFFFF " + CommonUtilities.getPref(this, CommonConstants.SPLASH_SCREEN_COUNT, 1));
            CommonUtilities.setPref(this, CommonConstants.SPLASH_SCREEN_COUNT, 2);

            startNextActivity(1000);
        } else {
            Log.e("TAG", "successCall::::ELSEEE " + CommonUtilities.getPref(this, CommonConstants.SPLASH_SCREEN_COUNT, 1));
            checkAd();
        }
    }

    private void checkAd() {
        if (CommonUtilities.getPref(this, CommonConstants.STATUS_ENABLE_DISABLE, "").equals(CommonConstants.ENABLE)) {
            if (CommonUtilities.getPref(this, CommonConstants.AD_TYPE_FB_GOOGLE, "").equals(CommonConstants.AD_GOOGLE)) {
                CommonConstantAd.googlebeforloadAd(this);
                Log.e("TAG", "checkAd:Google::::  ");
            } else if (CommonUtilities.getPref(this, CommonConstants.AD_TYPE_FB_GOOGLE, "").equals(CommonConstants.AD_FACEBOOK)) {
                CommonConstantAd.facebookbeforeloadFullAd(this);
                Log.e("TAG", "checkAd:Facebook:::: ");
            }
            if (CommonUtilities.getPref(this, CommonConstants.STATUS_ENABLE_DISABLE, "").equals(CommonConstants.ENABLE)) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (CommonUtilities.getPref(SplashActivity.this, CommonConstants.AD_TYPE_FB_GOOGLE, "").equals(CommonConstants.AD_GOOGLE)) {
                            CommonConstantAd.showInterstitialAdsGoogle(SplashActivity.this,SplashActivity.this);
                        } else if (CommonUtilities.getPref(SplashActivity.this, CommonConstants.AD_TYPE_FB_GOOGLE, "").equals(CommonConstants.AD_FACEBOOK)) {
                            CommonConstantAd.showInterstitialAdsFacebook(SplashActivity.this);
                        } else {
                            startNextActivity(0);
                        }
                    }

                }, 3000);
                CommonUtilities.setPref(this, CommonConstants.SPLASH_SCREEN_COUNT, 1);

            } else {
                startNextActivity(0);
            }
        } else {
            CommonUtilities.setPref(this, CommonConstants.SPLASH_SCREEN_COUNT, 1);
            Log.e("TAG", "checkAd:ELSE:::: " + CommonUtilities.getPref(this, CommonConstants.STATUS_ENABLE_DISABLE, ""));
            startNextActivity(1000);
        }
    }



    @Override
    public void onSuccess() {

    }

    @Override
    public void onCancel() {

    }

    @Override
    public void onRetry() {
        callApi();
    }



    @Override
    public void adLoadingFailed() {
        startNextActivity(0);
    }

    @Override
    public void adClose() {
        startNextActivity(0);
    }

    @Override
    public void startNextScreen() {
        startNextActivity(0);
    }

    @Override
    public void onLoaded() {
        isLoaded = true;
    }


    @Override
    protected void onStop() {
        super.onStop();
        handler.removeCallbacks(myRunnable);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(myRunnable);
    }
}