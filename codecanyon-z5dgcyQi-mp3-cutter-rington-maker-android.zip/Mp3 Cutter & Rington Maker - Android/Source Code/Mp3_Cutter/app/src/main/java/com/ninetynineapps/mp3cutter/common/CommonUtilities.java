package com.ninetynineapps.mp3cutter.common;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.ninetynineapps.mp3cutter.R;
import com.ninetynineapps.mp3cutter.custom.FileSaveDialog;
import com.ninetynineapps.mp3cutter.interfaces.CallbackListener;
import com.ninetynineapps.mp3cutter.interfaces.PermissionCallback;
import com.ninetynineapps.mp3cutter.pojo.ContactsClass;
import com.ninetynineapps.mp3cutter.pojo.MediaClass;
import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CommonUtilities {

    private static final String[] COLUMNS = new String[]{
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.IS_RINGTONE,
            MediaStore.Audio.Media.IS_ALARM,
            MediaStore.Audio.Media.IS_NOTIFICATION,
            MediaStore.Audio.Media.IS_MUSIC,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATE_ADDED
    };

    private static final Uri CONTENT_URI = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
    private static final String SORT_ORDER = MediaStore.Audio.Media.DEFAULT_SORT_ORDER;


    public static void getAllSongs(Activity activity) {

        Uri allsongsuri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";

        String[] STAR = null;
        Cursor cursor = activity.managedQuery(allsongsuri, null, selection, null, null);
        //or
        //Cursor cursor = getActivity().getContentResolver().query(allsongsuri, null, null, null, selection);


        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    @SuppressLint("Range") String song_name = cursor
                            .getString(cursor
                                    .getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME));
                    @SuppressLint("Range") int song_id = cursor.getInt(cursor
                            .getColumnIndex(MediaStore.Audio.Media._ID));

                    @SuppressLint("Range") String fullpath = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA));
                    @SuppressLint("Range") String Duration = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION));

                    Log.e("TAG", "Song Name ::" + song_name + " Song Id :" + song_id + " fullpath ::" + fullpath + " Duration ::" + Duration);

                } while (cursor.moveToNext());

            }
            cursor.close();

        }
    }


    /*public static ArrayList<MediaClass> getAllAudioFromDevice(final Context context) {
        final ArrayList<MediaClass> mediaClassArrayList = new ArrayList<>();

        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor cursor = context.getContentResolver().query(uri, COLUMNS, MediaStore.Audio.Media.DATA + " like ? ", new String[]{"%"+CommonConstants.KeySavingDirName+"%"}, null);

        if (cursor != null) {
            *//*while (c.moveToNext()) {
                MediaClass audioModel = new MediaClass();
                String path = c.getString(0);
                String name = c.getString(1);
                String album = c.getString(2);
                String artist = c.getString(3);

                audioModel.setaName(name);
                audioModel.setaAlbum(album);
                audioModel.setaArtist(artist);
                audioModel.setaPath(path);

                Log.e("Name :" + name, " Album :" + album);
                Log.e("Path :" + path, " Artist :" + artist);

                tempAudioList.add(audioModel);
            }
            c.close();*//*

            if (cursor.moveToFirst()) {
                try {
                    do {
                        String fileType;
                        try {
                            if (cursor.getString(6).equalsIgnoreCase("1")) {
                                fileType = CommonConstants.IS_RINGTONE;
                            } else if (cursor.getString(7).equalsIgnoreCase("1")) {
                                fileType = CommonConstants.IS_ALARM;
                            } else if (cursor.getString(8).equalsIgnoreCase("1")) {
                                fileType = CommonConstants.IS_NOTIFICATION;
                            } else {
                                fileType = CommonConstants.IS_MUSIC;
                            }
                        } catch (Exception e) {
                            fileType = CommonConstants.IS_RINGTONE;
                        }

                        String duration = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION));
                        if (duration != null && (Integer.valueOf(duration)) > 1000) {
                            MediaClass aClass = new MediaClass();
                            aClass._ID = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));
                            aClass.mSongsName = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE));
                            aClass.mArtistName = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST));
                            aClass.mDuration = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION));
                            aClass.mPath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA));
                            aClass.mAlbum = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM));
                            aClass.mAlbumId = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID));
                            aClass.mDateAdded = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED));
                            aClass.mFileType = fileType;
                            Log.e("TAG", "getSongList:GSON::::::  " + new Gson().toJson(aClass));
                            mediaClassArrayList.add(aClass);
                        }
                    } while (cursor.moveToNext());
                } catch (Exception e) {
                    Log.e("TAG", "getSongList:EEEEEEEEE  " + e.toString());
                    e.printStackTrace();
                }
            }
            if (cursor != null) {
                Log.e("TAG", "getSongList:CLOSE::::  ");
                cursor.close();
            }

        }

        return mediaClassArrayList;
    }*/

    public static ArrayList<MediaClass> getSongList(Context context, boolean isFromMyCol, String searchString) {
        ArrayList<MediaClass> mediaClassArrayList = new ArrayList<>();

        ContextWrapper contextWrapper = new ContextWrapper(context);
        Uri extUri = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL);
        String selection;
        String[] selectionArgs;
        if (isFromMyCol) {
            selection = MediaStore.Audio.Media.DATA + " LIKE ? And " + MediaStore.Audio.Media.TITLE + " LIKE ? ";
            selectionArgs = new String[]{"%" + CommonConstants.KeySavingDirName + "%", "%" + searchString + "%"};
//            selectionArgs = new String[]{"%" +"storage/emulated/0"+"/"+Environment.DIRECTORY_MUSIC+"/"+CommonConstants.KeySavingDirName+"" + "%", "%" + searchString + "%"};
        } else {
            selection = MediaStore.Audio.Media.TITLE + " LIKE ? ";
            selectionArgs = new String[]{"%" + searchString + "%"};
        }

        Log.e("TAG", "getSongList::::::::SELECTION  " + selection + "  " + CONTENT_URI + "  " + extUri+"  "+selectionArgs);
        Cursor cursor = context.getContentResolver().query(CONTENT_URI, COLUMNS, selection, selectionArgs, SORT_ORDER);
        if (cursor != null && cursor.moveToFirst()) {
            try {
                do {
                    String fileType;
                    try {
                        if (cursor.getString(6).equalsIgnoreCase("1")) {
                            fileType = CommonConstants.IS_RINGTONE;
                        } else if (cursor.getString(7).equalsIgnoreCase("1")) {
                            fileType = CommonConstants.IS_ALARM;
                        } else if (cursor.getString(8).equalsIgnoreCase("1")) {
                            fileType = CommonConstants.IS_NOTIFICATION;
                        } else {
                            fileType = CommonConstants.IS_MUSIC;
                        }
                    } catch (Exception e) {
                        fileType = CommonConstants.IS_RINGTONE;
                    }

                    String duration = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION));
                    if (duration != null && (Integer.valueOf(duration)) > 1000) {
                        MediaClass aClass = new MediaClass();
                        aClass._ID = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));
                        aClass.mSongsName = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE));
                        aClass.mArtistName = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST));
                        aClass.mDuration = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION));
                        aClass.mPath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA));
                        aClass.mAlbum = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM));
                        aClass.mAlbumId = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID));
                        aClass.mDateAdded = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED));
                        aClass.mFileType = fileType;
                        Log.e("TAG", "getSongList:GSON::::::  " + new Gson().toJson(aClass));
                        mediaClassArrayList.add(aClass);
                    }
                } while (cursor.moveToNext());
            } catch (Exception e) {
                Log.e("TAG", "getSongList:EEEEEEEEE  " + e.toString());
                e.printStackTrace();
            }
        }
        if (cursor != null) {
            Log.e("TAG", "getSongList:CLOSE::::  ");
            cursor.close();
        }
        return mediaClassArrayList;
    }


    /*public static List<MediaClass> getAllAudioFromDevice(final Context context) {

        final List<MediaClass> tempAudioList = new ArrayList<>();

        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Audio.AudioColumns.DATA, MediaStore.Audio.AudioColumns.ALBUM, MediaStore.Audio.ArtistColumns.ARTIST,};
        Cursor c = context.getContentResolver().query(uri, projection, MediaStore.Audio.Media.DATA + " like ? ",
                new String[]{"%"+CommonConstants.KeySavingDirName+"%"}, null);

        if (c != null) {
            while (c.moveToNext()) {

                String fileType;
                try {
                    if (c.getString(6).equalsIgnoreCase("1")) {
                        fileType = CommonConstants.IS_RINGTONE;
                    } else if (c.getString(7).equalsIgnoreCase("1")) {
                        fileType = CommonConstants.IS_ALARM;
                    } else if (c.getString(8).equalsIgnoreCase("1")) {
                        fileType = CommonConstants.IS_NOTIFICATION;
                    } else {
                        fileType = CommonConstants.IS_MUSIC;
                    }
                } catch (Exception e) {
                    fileType = CommonConstants.IS_RINGTONE;
                }

                MediaClass aClass = new MediaClass();
                aClass._ID = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));
                aClass.mSongsName = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE));
                aClass.mArtistName = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST));
                aClass.mDuration = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION));
                aClass.mPath = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA));
                aClass.mAlbum = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM));
                aClass.mAlbumId = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID));
                aClass.mDateAdded = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED));
                aClass.mFileType = fileType;
//                String path = c.getString(0);
//                String album = c.getString(1);
//                String artist = c.getString(2);

//                String name = path.substring(path.lastIndexOf("/") + 1);

//                audioModel.setaName(name);
//                audioModel.setaAlbum(album);
//                audioModel.setaArtist(artist);
//                audioModel.setaPath(path);


                tempAudioList.add(aClass);
                Log.e("Name :::::::::::" , " Album :::::::::::::" + new Gson().toJson(aClass) +" " +tempAudioList.size());
            }
            c.close();
        }

        return tempAudioList;
    }*/


    public static boolean renameFileName(Context context, String oldName, String newName, long id, final MediaClass aClass) {


        boolean isSuccess = false;
        try {
            String selection = MediaStore.Audio.Media.TITLE + "=?";
            String[] selectionArgs = new String[]{"" + oldName + ""};
//            String[] selectionArgs = new String[]{directoryName()+""+oldName+".mp3"};
            Uri extUri = ContentUris.withAppendedId(MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL), id);
            String outPath = makeRingtoneFilename(newName, ".mp3", context);
//            String outPath = directoryName()+""+newName+".mp3";
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Audio.Media.DATA, outPath);
            cv.put(MediaStore.MediaColumns.DATA, outPath);

            cv.put(MediaStore.Audio.Media.TITLE, newName);
            cv.put(MediaStore.MediaColumns.TITLE, newName);

            cv.put(MediaStore.Audio.Media.DISPLAY_NAME, newName);
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);


            int mCount = context.getContentResolver().update(extUri, cv, selection, selectionArgs);
            if (mCount > 0 || mCount != -1) {
                isSuccess = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isSuccess;
    }


    static Long getIdFromDisplayName(String displayName, Context context) {
        String[] projection;
        projection = new String[]{MediaStore.Files.FileColumns._ID};

        // TODO This will break if we have no matching item in the MediaStore.
        Cursor cursor = context.getContentResolver().query(MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL), projection,
                MediaStore.Files.FileColumns.DISPLAY_NAME + " LIKE ?", new String[]{displayName}, null);
        assert cursor != null;
        cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            int columnIndex = cursor.getColumnIndex(projection[0]);
            long fileId = cursor.getLong(columnIndex);

            cursor.close();
            return fileId;
        }
        return null;
    }


    public static boolean deleteFileWithCursor(Context context, String id) {
        boolean isSuccess = false;
        try {
            String selection = MediaStore.Audio.Media._ID + "=?";
            String[] selectionArgs = new String[]{"" + id + ""};
            Uri extUri = ContentUris.withAppendedId(MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL), Long.parseLong(id));
            int mCount = context.getContentResolver().delete(extUri, selection, selectionArgs);
            if (mCount > 0 || mCount != -1) {
                isSuccess = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isSuccess;
    }

    public static boolean deleteFileFromStorage(Context context, String filePath) {
        boolean isDeleted = false;
        try {
            File file = new File(filePath);
            if (file.delete()) {
                isDeleted = true;
                Log.e("<><>", " file deleted");
            }
            if (file.exists()) {
                try {
                    if (file.getCanonicalFile().delete()) {
                        isDeleted = true;
                        Log.e("<><>", " file deleted");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (file.exists()) {
                    try {
                        if (context.deleteFile(file.getName())) {
                            isDeleted = true;
                            Log.e("<><>", " file deleted");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isDeleted;
    }

    public static Uri getAlbumArtUri(long paramInt) {
        return ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), paramInt);
    }

//    public static Uri getInternalUri(String _ID) {
//        return ContentUris.withAppendedId(MediaStore.Audio.Media.INTERNAL_CONTENT_URI, Long.parseLong(_ID));
//    }

    public static Uri getExtUri(String _ID) {
        return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, Long.parseLong(_ID));
    }

    public static String directoryName() {
        String externalRootDir = Environment.getExternalStorageDirectory().getPath();
        if (!externalRootDir.endsWith("/")) {
            externalRootDir += "/";
        }
        return externalRootDir + "" + CommonConstants.KeySavingDirName + "/";
    }

    public static String makeRingtoneFilename(CharSequence title, String extension, Context context) {
        String subDir;
        String externalRootDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath();
        if (!externalRootDir.endsWith("/")) {
            externalRootDir += "/";
        }
//        ContextWrapper cw = new ContextWrapper(context);

        String parentdir = externalRootDir +""+ CommonConstants.KeySavingDirName + "/";
//        String parentdir = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC).getAbsolutePath() + File.separator + CommonConstants.KeySavingDirName+"/";
//        String parentdir = "/storage/emulated/0"+"/"+Environment.DIRECTORY_DOWNLOADS+"/"+CommonConstants.KeySavingDirName+"/";
        Log.e("TAG", "makeRingtoneFilename::::Parent Dir:::===  " + parentdir);
        // Create the parent directory
        File parentDirFile = new File(parentdir);
        parentDirFile.mkdirs();
        /*if (!parentDirFile.exists()) {
        }*/


        // If we can't write to that special path, try just writing
        // directly to the sdcard
        if (!parentDirFile.isDirectory()) {
            parentdir = externalRootDir;
        }

        // Turn the title into a filename
        String filename = "";
        for (int i = 0; i < title.length(); i++) {
            if (Character.isLetterOrDigit(title.charAt(i))) {
                filename += title.charAt(i);
            }
        }

        // Try to make the filename unique
        String path = null;
        for (int i = 0; i < 100; i++) {
            String testPath;
            if (i > 0)
                testPath = parentdir + filename + i + extension;
            else
                testPath = parentdir + filename + extension;

            try {
                RandomAccessFile f = new RandomAccessFile(new File(testPath), "r");
                f.close();
            } catch (Exception e) {
                // Good, the file didn't exist
                path = testPath;
                break;
            }
        }
        Log.e("TAG", "makeRingtoneFilename::::Parent Dir:::===  :Main Final Path::::: "+path );
        return path;
    }

    public static String getMIMEType(String url) {
        String mType = null;
        String mExtension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (mExtension != null) {
            mType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(mExtension);
        }
        return mType;
    }


    public static void startMediaEditActivity(AppCompatActivity appCompatActivity, Class<?> cls, MediaClass aClass) {
        Intent intent = new Intent(appCompatActivity, cls);
        intent.putExtra(CommonConstants.KeyMediaClassObject, aClass);
        appCompatActivity.startActivityForResult(intent, CommonConstants.RequestCodeRecordUpdated);
    }

    public static void startPlayerActivity(AppCompatActivity appCompatActivity, Class<?> cls, ArrayList<MediaClass> mediaClassArrayList, int mPos) {
        Intent intent = new Intent(appCompatActivity, cls);
        intent.putExtra(CommonConstants.KeyMediaClassArrayList, mediaClassArrayList);
        intent.putExtra(CommonConstants.KeyItemPos, mPos);
        appCompatActivity.startActivityForResult(intent, CommonConstants.RequestCodeRecordUpdated);
    }

    public static void chooseContactForRingtone(AppCompatActivity appCompatActivity, Class<?> cls, MediaClass aClass) {
        try {
            Intent intent = new Intent(appCompatActivity, cls);
            intent.putExtra(CommonConstants.FILE_NAME, String.valueOf(CommonUtilities.getExtUri(aClass._ID)));
//            if (aClass.mFileType.equalsIgnoreCase(CommonConstants.IS_RINGTONE)) {
//                intent.putExtra(CommonConstants.FILE_NAME, String.valueOf(CommonUtilities.getInternalUri(aClass._ID)));
//            } else if (aClass.mFileType.equalsIgnoreCase(CommonConstants.IS_MUSIC)) {
//                intent.putExtra(CommonConstants.FILE_NAME, String.valueOf(CommonUtilities.getExtUri(aClass._ID)));
//            } else {
//                intent.putExtra(CommonConstants.FILE_NAME, String.valueOf(CommonUtilities.getInternalUri(aClass._ID)));
//            }
            appCompatActivity.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void setAsDefaultRingtoneOrNotification(AppCompatActivity appCompatActivity, MediaClass aClass) {
        try {
            if (!CommonUtilities.checkSystemWritePermission(appCompatActivity)) return;
            if (aClass.mFileType.equalsIgnoreCase(CommonConstants.IS_RINGTONE)) {
                RingtoneManager.setActualDefaultRingtoneUri(appCompatActivity, RingtoneManager.TYPE_RINGTONE, CommonUtilities.getExtUri(aClass._ID));
                Toast.makeText(appCompatActivity, R.string.default_ringtone_success_message, Toast.LENGTH_SHORT).show();
            } else if (aClass.mFileType.equalsIgnoreCase(CommonConstants.IS_MUSIC)) {
                RingtoneManager.setActualDefaultRingtoneUri(appCompatActivity, RingtoneManager.TYPE_RINGTONE, CommonUtilities.getExtUri(aClass._ID));
                Toast.makeText(appCompatActivity, R.string.default_ringtone_success_message, Toast.LENGTH_SHORT).show();
            } else {
                RingtoneManager.setActualDefaultRingtoneUri(appCompatActivity, RingtoneManager.TYPE_NOTIFICATION, CommonUtilities.getExtUri(aClass._ID));
                Toast.makeText(appCompatActivity, R.string.default_notification_success_message, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getFullDateTimeInDisplayFormatFromMillis(String timeInMillis) {
        return new SimpleDateFormat(CommonConstants.CapFullDateTimeFormatDisplay, Locale.getDefault()).format(new Date(Long.parseLong(timeInMillis) * 1000));
    }

    @SuppressLint("NewApi")
    public static String getFilePath(Context context, Uri uri) {
        String selection = null;
        String[] selectionArgs = null;
        if (Build.VERSION.SDK_INT >= 19 && DocumentsContract.isDocumentUri(context.getApplicationContext(), uri)) {
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                return Environment.getExternalStorageDirectory() + "/" + split[1];
            } else if (isDownloadsDocument(uri)) {
                final String id = DocumentsContract.getDocumentId(uri);
                uri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));
            } else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];
                if ("image".equals(type)) {
                    uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }
                selection = "_id=?";
                selectionArgs = new String[]{split[1]};
            }
        }
        if ("content".equalsIgnoreCase(uri.getScheme())) {
            String[] projection = {
                    MediaStore.Images.Media.DATA
            };
            Cursor cursor = null;
            try {
                if (context.getContentResolver() != null) {
                    cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs, null);
                    if (cursor != null) {
                        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                        if (cursor.moveToFirst()) {
                            return cursor.getString(column_index);
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (cursor != null && !cursor.isClosed()) {
                    cursor.close();
                }
            }
        } else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }
        return null;
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }


    public static void setResultAndFinish(AppCompatActivity appCompatActivity) {
        try {
            Intent intent = new Intent();
            intent.putExtra(CommonConstants.KeyIsRecordUpdated, true);
            appCompatActivity.setResult(Activity.RESULT_OK, intent);
            appCompatActivity.finish();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static final String makeShortTimeString(final Context context, long secs) {
        long hours, mins;

        hours = secs / 3600;
        secs %= 3600;
        mins = secs / 60;
        secs %= 60;

        final String durationFormat = context.getResources().getString(hours == 0 ? R.string.durationformatshort : R.string.durationformatlong);
        return String.format(durationFormat, hours, mins, secs);
    }

    public static void initImageLoader(Context context) {
        try {
            DisplayImageOptions options = new DisplayImageOptions.Builder()
                    .showImageOnLoading(R.drawable.ic_music_default)
                    .showImageForEmptyUri(R.drawable.ic_music_default)
                    .showImageOnFail(R.drawable.ic_music_default)
                    .imageScaleType(ImageScaleType.IN_SAMPLE_INT)
                    .bitmapConfig(Bitmap.Config.ARGB_8888)
                    .displayer(new FadeInBitmapDisplayer(500))
                    .handler(new Handler()).build();
            ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(context)
                    .memoryCache(new WeakMemoryCache()).defaultDisplayImageOptions(options).memoryCacheSizePercentage(13).build();
            ImageLoader.getInstance().init(config);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean checkSystemWritePermission(final AppCompatActivity context) {
        boolean retVal = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            retVal = Settings.System.canWrite(context);
            if (retVal) {
            } else {
                new AlertDialog.Builder(context)
                        .setTitle(CommonConstants.MsgSetRingtone)
                        .setMessage(context.getString(R.string.write_setting_text))
                        .setPositiveButton(CommonConstants.CapContinue, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                                intent.setData(Uri.parse("package:" + context.getPackageName()));
                                context.startActivity(intent);
                                dialog.dismiss();
                            }
                        })
                        .setNegativeButton(CommonConstants.CapCancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .setCancelable(false)
                        .show();
            }
        }
        return retVal;
    }

    public static ArrayList<ContactsClass> getContacts(Context context, String searchQuery) {

        String selection = "(DISPLAY_NAME LIKE \"%" + searchQuery + "%\")";

        ArrayList<ContactsClass> contactsClasses = new ArrayList<>();

        Cursor cursor = context.getContentResolver().query(
                ContactsContract.Contacts.CONTENT_URI,
                new String[]{
                        ContactsContract.Contacts._ID,
                        ContactsContract.Contacts.CUSTOM_RINGTONE,
                        ContactsContract.Contacts.DISPLAY_NAME,
                        ContactsContract.Contacts.LAST_TIME_CONTACTED,
                        ContactsContract.Contacts.STARRED,
                        ContactsContract.Contacts.TIMES_CONTACTED},
                selection,
                null,
                "STARRED DESC, " +
                        "TIMES_CONTACTED DESC, " +
                        "LAST_TIME_CONTACTED DESC, " +
                        "DISPLAY_NAME ASC");


        if (cursor != null && cursor.moveToFirst()) {
            do {
                ContactsClass contactsClass = new ContactsClass(cursor.getString(2),
                        cursor.getString(0));
                contactsClasses.add(contactsClass);
            } while (cursor.moveToNext());
        }
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
        return contactsClasses;
    }

    public static int getMatColor(Context context) {
        int returnColor;
        {
            TypedArray colors = context.getResources().obtainTypedArray(R.array.mdcolor_500);
            int index = (int) (Math.random() * colors.length());
            returnColor = colors.getColor(index, Color.BLACK);
            colors.recycle();
        }
        return returnColor;
    }

    public static boolean checkRequiredPermission(Context context) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            int result1 = ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS);
            int result2 = ContextCompat.checkSelfPermission(context, android.Manifest.permission.WRITE_CONTACTS);
            int result3 = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_AUDIO);
            return result1 == PackageManager.PERMISSION_GRANTED && result2 == PackageManager.PERMISSION_GRANTED
                    && result3 == PackageManager.PERMISSION_GRANTED;
        } else {
            int result1 = ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS);
            int result2 = ContextCompat.checkSelfPermission(context, android.Manifest.permission.WRITE_CONTACTS);
            int result3 = ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_EXTERNAL_STORAGE);
            int result4 = ContextCompat.checkSelfPermission(context, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
            return result1 == PackageManager.PERMISSION_GRANTED && result2 == PackageManager.PERMISSION_GRANTED
                    && result3 == PackageManager.PERMISSION_GRANTED && result4 == PackageManager.PERMISSION_GRANTED;
        }
    }

    public static void requestRequiredPermission(AppCompatActivity appCompatActivity) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(appCompatActivity, new String[]{
                    android.Manifest.permission.READ_CONTACTS,
                    android.Manifest.permission.WRITE_CONTACTS,
                    Manifest.permission.READ_MEDIA_AUDIO
            }, CommonConstants.RequestCodePermission);
        } else {
            ActivityCompat.requestPermissions(appCompatActivity,
                    new String[]{
                            android.Manifest.permission.READ_CONTACTS,
                            android.Manifest.permission.WRITE_CONTACTS,
                            android.Manifest.permission.READ_EXTERNAL_STORAGE,
                            android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    }, CommonConstants.RequestCodePermission);
        }
    }

    public static void showPermissionConfirmDialog(final AppCompatActivity appCompatActivity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(appCompatActivity);
        builder.setTitle(CommonConstants.CapPermission);
        builder.setMessage(CommonConstants.MsgAllowPermission);
        builder.setPositiveButton(CommonConstants.CapContinue, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                requestRequiredPermission(appCompatActivity);
            }
        });
        builder.setNegativeButton(CommonConstants.CapCancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }


    public static Boolean isOnline(Context context) {
        boolean connected = false;
        final ConnectivityManager cm = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        final NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            connected = true;
        } else if (netInfo != null && netInfo.isConnected()
                && cm.getActiveNetworkInfo().isAvailable()) {
            connected = true;
        } else if (netInfo != null && netInfo.isConnected()) {
            try {
                URL url = new URL("http://www.google.com");
                HttpURLConnection urlc = (HttpURLConnection) url
                        .openConnection();
                urlc.setConnectTimeout(3000);
                urlc.connect();
                if (urlc.getResponseCode() == 200) {
                    connected = true;
                }
            } catch (MalformedURLException e1) {
                e1.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (cm != null) {
            final NetworkInfo[] netInfoAll = cm.getAllNetworkInfo();
            for (NetworkInfo ni : netInfoAll) {
                System.out.println("get network type :::" + ni.getTypeName());
                if ((ni.getTypeName().equalsIgnoreCase("WIFI") || ni
                        .getTypeName().equalsIgnoreCase("MOBILE"))
                        && ni.isConnected() && ni.isAvailable()) {
                    connected = true;
                    if (connected) {
                        break;
                    }
                }
            }
        }
        return connected;
    }

    public static void showAlertFinishOnClick(final Context context, final boolean finishAct,
                                              String title, String msg,
                                              boolean posBtnVis, String posBtnTitle,
                                              boolean negBtnVis, String negBtnTitle) {
//    CommonUtilities.showAlertFinishOnClick(this, CommonConstants.CapMessage, CommonConstants.MsgWantToExit,
//            true, CommonConstants.CapYes, true, CommonConstants.CapCancel);

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        alertDialog.setTitle(title);
        alertDialog.setMessage(msg);
        if (posBtnVis) {
            alertDialog.setPositiveButton(posBtnTitle, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    if (finishAct) {
                        ((AppCompatActivity) context).finish();
                    } else {
                        dialog.cancel();
                    }
                }
            });
        }
        if (negBtnVis) {
            alertDialog.setNegativeButton(negBtnTitle, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    dialog.cancel();
                }
            });
        }
        alertDialog.setCancelable(false);
        alertDialog.show();
    }


    public static void checkPermission(final Context context, final PermissionCallback permissionCallback, final View view, final int pos) {
        Dexter.withActivity(((Activity) context))
                .withPermissions(android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        android.Manifest.permission.READ_EXTERNAL_STORAGE).withListener(new MultiplePermissionsListener() {
            @Override
            public void onPermissionsChecked(MultiplePermissionsReport report) {
                if (report.areAllPermissionsGranted()) {
                    permissionCallback.PermissionGrant(view, pos);
                } else if (report.isAnyPermissionPermanentlyDenied()) {
                    showSettingsDialog(false, context.getString(R.string.need_permission), context.getString(R.string.permision_message), context);
                }
            }

            @Override
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                token.continuePermissionRequest();
            }
        }).check();
    }

    public static void showSettingsDialog(final boolean isAllFile, String title, String message, final Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton("Go to setting", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (isAllFile) {
                    Intent permissionIntent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    context.startActivity(permissionIntent);
                } else {
                    openSettings(context);
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }


    private static void openSettings(Context context) {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", context.getPackageName(), null);
        intent.setData(uri);
        ((Activity) context).startActivityForResult(intent, 101);
    }


    public static void setPref(Context context, String key, String value) {
        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(context).edit().putString(key, value);
        editor.apply();
    }
    public static String getPref(Context context, String key, String value) {
        return PreferenceManager.getDefaultSharedPreferences(context).getString(key, value);
    }


    public static void setPref(Context context, String key, Integer value) {
        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(context).edit().putInt(key, value);
        editor.apply();
    }

    public static Integer getPref(Context context, String key, Integer value) {
        return PreferenceManager.getDefaultSharedPreferences(context).getInt(key, value);
    }


    public static boolean isNetworkConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }


    public static void openInternetDialog(final Context context, final CallbackListener callbackListener, final Boolean isSplash) {
        if (!isNetworkConnected(context)) {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
            builder.setTitle("No internet Connection");
            builder.setCancelable(false);
            builder.setMessage("Please turn on internet connection to continue");
            builder.setNegativeButton("Retry", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (!isSplash) {
                        openInternetDialog(context,callbackListener, false);
                    }
                    dialog.dismiss();
                    callbackListener.onRetry();
                }
            });

            builder.setPositiveButton("Close", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    Intent homeIntent = new Intent(Intent.ACTION_MAIN);
                    homeIntent.addCategory(Intent.CATEGORY_HOME);
                    homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    context.startActivity(homeIntent);
                    ((Activity)context).finishAffinity();
                }
            });
            android.app.AlertDialog alertDialog = builder.create();
            alertDialog.show();

        }
    }
}
