package com.ninetynineapps.mp3cutter.pojo;

import java.io.Serializable;

public class MediaClass implements Serializable {

    public String _ID;
    public String mSongsName;
    public String mArtistName;
    public String mDuration;
    public String mPath;
    public String mAlbum;
    public String mAlbumId;
    public String mDateAdded;
    public String mFileType;

//    public MediaClass(String _ID,
//                      String songsName,
//                      String artistName,
//                      String duration,
//                      String album,
//                      String path,
//                      String albumId,
//                      String fileType) {
//        this._ID = _ID;
//        mSongsName = songsName;
//        mArtistName = artistName;
//        mDuration = duration;
//        mPath = path;
//        mAlbum = album;
//        mAlbumId = albumId;
//        mFileType = fileType;
//    }
}