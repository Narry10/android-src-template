package com.ninetynineapps.mp3cutter.interfaces;

import android.view.View;

public interface AdapterItemViewTypeCallback {
    void onItemTypeCallback(View view,int mType, int mPos);
}