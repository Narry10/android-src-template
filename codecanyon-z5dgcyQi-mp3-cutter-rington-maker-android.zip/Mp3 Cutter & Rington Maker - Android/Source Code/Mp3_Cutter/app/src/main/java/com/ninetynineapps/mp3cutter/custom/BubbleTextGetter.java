package com.ninetynineapps.mp3cutter.custom;

public interface BubbleTextGetter {
    String getTextToShowInBubble(int pos);
}