package com.ninetynineapps.mp3cutter.interfaces;

public interface CallbackListener {

    void onSuccess();
    void onCancel();
    void onRetry();

}
