package com.yourbrand.translatelanguage.voicetranslate.translator_utils;

//import com.google.android.gms.ads.AdRequest;
//import com.google.android.gms.ads.InterstitialAd;
import com.yourbrand.translatelanguage.voicetranslate.R;


public class AdsUtility {





//






}
