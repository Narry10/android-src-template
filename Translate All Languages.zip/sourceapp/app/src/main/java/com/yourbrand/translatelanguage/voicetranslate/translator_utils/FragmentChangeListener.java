package com.yourbrand.translatelanguage.voicetranslate.translator_utils;

import androidx.fragment.app.Fragment;


public interface FragmentChangeListener {
    void replaceFragment(Fragment fragment);
}
