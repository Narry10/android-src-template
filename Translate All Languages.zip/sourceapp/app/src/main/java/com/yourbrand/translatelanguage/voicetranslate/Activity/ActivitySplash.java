package com.yourbrand.translatelanguage.voicetranslate.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;


import com.google.firebase.analytics.FirebaseAnalytics;
import com.yourbrand.translatelanguage.voicetranslate.R;

import yourbrandad.ads.AdsHandler;
import yourbrandad.ads.GetSmartAdmob;


public class ActivitySplash extends AppCompatActivity {

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
       
        setContentView(R.layout.activity_splash);


        FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundleFirebase = new Bundle();
        bundleFirebase.putString(FirebaseAnalytics.Param.ITEM_NAME, "ActivitySplash");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundleFirebase);

        String[] adsUrls = new String[]{
                getString(yourbrandad.ads.R.string.bnr_admob)
                , getString(yourbrandad.ads.R.string.native_admob)
                , getString(yourbrandad.ads.R.string.int_admob)
                , getString(yourbrandad.ads.R.string.app_open_admob)
                , getString(yourbrandad.ads.R.string.video_admob)
        };

        new GetSmartAdmob(this, adsUrls, (success) -> {
           
        }).execute();

        AdsHandler.setAdsOn(true);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivitySplash.this.startActivity(new Intent(ActivitySplash.this, GetStart.class));
                ActivitySplash.this.finish();
            }
        }, 1500);
 

    }
}
