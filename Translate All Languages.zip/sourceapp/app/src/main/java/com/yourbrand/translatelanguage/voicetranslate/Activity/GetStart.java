package com.yourbrand.translatelanguage.voicetranslate.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.yourbrand.translatelanguage.voicetranslate.R;

import yourbrandad.ads.CustomAdsListener;
import yourbrandad.ads.ExitScreen;
import yourbrandad.ads.GoogleAds;

public class GetStart extends AppCompatActivity {
    LinearLayout getstart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_start);
        getstart = findViewById(R.id.getstart);

        FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundleFirebase = new Bundle();
        bundleFirebase.putString(FirebaseAnalytics.Param.ITEM_NAME, "GetStart");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundleFirebase);

        GoogleAds.getInstance().addNativeView(this, (LinearLayout) findViewById(R.id.nativeLay));
        getstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GoogleAds.getInstance().showCounterInterstitialAd(GetStart.this, new CustomAdsListener() {
                    @Override
                    public void onFinish() {
                        startActivity(new Intent(GetStart.this, GetStart2.class));
                    }
                });
            }
        });
    }

    @Override
    public void onBackPressed() {
                startActivity(new Intent(GetStart.this, ExitScreen.class));
    }
}