package com.yourbrand.translatelanguage.voicetranslate.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.yourbrand.translatelanguage.voicetranslate.R;

import yourbrandad.ads.AppUtil;
import yourbrandad.ads.GoogleAds;

public class GetStart2 extends AppCompatActivity {
    LinearLayout start;
    LinearLayout share_app, privacy_policy, rateapp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_start2);
        GoogleAds.getInstance().admobBanner(this, (LinearLayout) findViewById(R.id.nativeLay));



        FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundleFirebase = new Bundle();
        bundleFirebase.putString(FirebaseAnalytics.Param.ITEM_NAME, "GetStart2");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundleFirebase);

        start = findViewById(R.id.start);
        share_app = findViewById(R.id.share_app);
        privacy_policy = findViewById(R.id.privacy_policy);
        rateapp = findViewById(R.id.rateapp);


        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(GetStart2.this, HomeActivity.class));

            }
        });
        share_app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AppUtil.shareApp(GetStart2.this);

            }
        });
        privacy_policy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AppUtil.privacyPolicy(GetStart2.this, getString(R.string.privacyPolicy));

            }
        });
        rateapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AppUtil.rateApp(GetStart2.this);

            }
        });
    }

    @Override
    public void onBackPressed() {

        finish();

    }
}