package com.yourbrand.translatelanguage.voicetranslate.Activity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.yourbrand.translatelanguage.voicetranslate.translator_db.HelperDB;
import com.yourbrand.translatelanguage.voicetranslate.translator_utils.TranslatorConstants;
import com.yourbrand.translatelanguage.voicetranslate.R;

public class DetailsHistory extends AppCompatActivity {
    ImageView back;
    FloatingActionButton copy;
    FloatingActionButton del;
    HelperDB mydb;
    FloatingActionButton share;
    TextView source_label;
    TextView source_txt;
    TextView target_label;
    TextView target_txt;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_history_details);

        FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundleFirebase = new Bundle();
        bundleFirebase.putString(FirebaseAnalytics.Param.ITEM_NAME, "DetailsHistory");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundleFirebase);

        this.mydb = new HelperDB(getApplicationContext());
        this.source_label = (TextView) findViewById(R.id.source_detale_label);
        this.target_label = (TextView) findViewById(R.id.target_detale_label);
        this.source_txt = (TextView) findViewById(R.id.source_detaile_text);
        this.target_txt = (TextView) findViewById(R.id.target_dtaile_text);
        this.copy = (FloatingActionButton) findViewById(R.id.copy);
        this.source_label.setText(TranslatorConstants.source_l);
        this.target_label.setText(TranslatorConstants.target_l);
        this.source_txt.setText(TranslatorConstants.source_t);
        this.target_txt.setText(TranslatorConstants.target_t);
        this.back = (ImageView) findViewById(R.id.goback);
        this.del = (FloatingActionButton) findViewById(R.id.del);
        this.share = (FloatingActionButton) findViewById(R.id.share);
        this.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DetailsHistory.this.finish();
            }
        });
        this.del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (DetailsHistory.this.mydb.delTrans(String.valueOf(TranslatorConstants.position)).intValue() == 1) {
                    Toast.makeText(DetailsHistory.this.getApplicationContext(), "Translation item successfully deleted.", Toast.LENGTH_LONG).show();
                    DetailsHistory.this.finish();
                }
            }
        });
        this.share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType("text/plain");
                    intent.putExtra("android.intent.extra.SUBJECT", R.string.app_name);
                    intent.putExtra("android.intent.extra.TEXT", (("Translation result\n" + TranslatorConstants.source_t + "\n\n") + TranslatorConstants.target_t + "\n\n-----------\n") + "Download now Camera Translator" + DetailsHistory.this.getPackageName());
                    DetailsHistory.this.startActivity(Intent.createChooser(intent, "Choose One"));
                } catch (Exception unused) {
                    Toast.makeText(DetailsHistory.this.getApplicationContext(), "Sorry, Something Went Wrong", Toast.LENGTH_LONG).show();
                }
            }
        });
        this.copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (DetailsHistory.this.target_txt.getText().toString().length() != 0) {
                    if (Build.VERSION.SDK_INT < 11) {
                        ((ClipboardManager) DetailsHistory.this.getSystemService(Context.CLIPBOARD_SERVICE)).setText(DetailsHistory.this.target_txt.getText().toString());
                    } else {
                        ((ClipboardManager) DetailsHistory.this.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Copy", DetailsHistory.this.target_txt.getText().toString()));
                    }
                    Toast.makeText(DetailsHistory.this.getApplicationContext(), "Translated Text Copied to clipboard", Toast.LENGTH_LONG).show();
                    return;
                }
                Toast.makeText(DetailsHistory.this.getBaseContext(), "Nothing to Copy", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
