package yourbrandad.ads;

public interface OnEventListener {
    void onEvent(boolean purchased);
}
