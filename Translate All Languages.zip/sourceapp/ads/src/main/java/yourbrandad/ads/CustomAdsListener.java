package yourbrandad.ads;

public interface CustomAdsListener {
    void onFinish();
}
