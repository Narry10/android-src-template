package com.example.wallpaperoffline.menu.features;

public interface FavoriteListener {

    void onClick(int position, String path);

}
