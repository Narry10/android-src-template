package com.example.wallpaperoffline;

import android.os.Bundle;

import androidx.multidex.MultiDex;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.google.firebase.analytics.FirebaseAnalytics;

import vocsy.ads.AdsApplication;


public class WallpaperApp extends AdsApplication {

    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    public void onCreate() {
        super.onCreate();
        MultiDex.install(this);
        Fresco.initialize(this);

        // Initialize Firebase Analytics
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
// Log an event with specific values
        logAnalyticsEvent("App Open", "WallpaperApp");
    }
    // Method to log an analytics event
    public void logAnalyticsEvent(String eventName, String itemId) {
        Bundle params = createBundle(itemId);
        mFirebaseAnalytics.logEvent(eventName, params);
    }

    // Private method to create a Bundle for event parameters
    private Bundle createBundle(String itemId) {
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_ID, itemId);
        return bundle;
    }
}
