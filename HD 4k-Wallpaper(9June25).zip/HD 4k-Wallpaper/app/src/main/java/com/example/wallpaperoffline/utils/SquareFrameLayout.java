package com.example.wallpaperoffline.utils;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

public class SquareFrameLayout extends FrameLayout {
    public SquareFrameLayout(Context context) {
        super(context);
    }

    public SquareFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public SquareFrameLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }






    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        int size = orientation(width, height);
        setMeasuredDimension(size, size);
    }

    public static int orientation(int width, int height) {
        if (width == height && height == width) {
            
            return width;
        } else if (height > width) {
            
            return width;
        } else if (width > height) {
            
            return height;
        } else {
            
            return 1;
        }
    }
}
