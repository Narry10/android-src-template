package com.example.wallpaperoffline.common.views;

import android.Manifest;
import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.example.wallpaperoffline.BuildConfig;
import com.example.wallpaperoffline.GetStartedActivity;
import com.example.wallpaperoffline.R;
import com.example.wallpaperoffline._AdAdmob;
import com.example.wallpaperoffline.menu.features.Wallpaper.styled.StyledViewActivity;
import com.github.clans.fab.FloatingActionButton;
import com.github.clans.fab.FloatingActionMenu;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.nabinbhandari.android.permissions.PermissionHandler;
import com.nabinbhandari.android.permissions.Permissions;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import vocsy.ads.CustomAdsListener;
import vocsy.ads.GoogleAds;


public class ImageOverlayView extends RelativeLayout {
Activity activity;
    private TextView tvDescription;
    private String sharingText;
    private Button buttonDownload;
    private Context mContext;
    private FloatingActionMenu mainFab;
    private FloatingActionButton favoriteFab, setWallpaperFab, downloadFab, shareFab;
    private ArrayList<String> arrayList;
    ImageView back;

    public ImageOverlayView(Context context) {
        super(context);
        this.mContext = context;
        init();
    }

    public ImageOverlayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        init();
    }

    public ImageOverlayView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.mContext = context;
        init();
    }

    public void setDescription(String description) {
        tvDescription.setText(description);
    }

    public void setShareText(String text) {
        this.sharingText = text;
    }


    private void sendShareIntent() {
        File file = storeImage(sharingText);
        if (file != null) {
            Uri uri = FileProvider.getUriForFile(getContext(), BuildConfig.APPLICATION_ID + ".provider", file);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.setType("image/*");
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getContext().startActivity(Intent.createChooser(share, "Share image File"));
        } else {
            Toast.makeText(getContext(), "Couldn't save image Try Again!", Toast.LENGTH_SHORT).show();
        }
    }

    private void init() {
        View view = inflate(getContext(), R.layout.view_image_overlay, this);
        tvDescription = (TextView) view.findViewById(R.id.tvDescription);
        buttonDownload = (Button) view.findViewById(R.id.btndownload);
        mainFab = (FloatingActionMenu) view.findViewById(R.id.menu_green);
        favoriteFab = (FloatingActionButton) view.findViewById(R.id.Favourite);
        setWallpaperFab = (FloatingActionButton) view.findViewById(R.id.setwallpaper);
        downloadFab = (FloatingActionButton) view.findViewById(R.id.Download);
        shareFab = (FloatingActionButton) view.findViewById(R.id.Share);
//        GoogleAds.getInstance().admobBanner(mContext, (LinearLayout) findViewById(R.id.nativeLay));
//        _AdAdmob.FullscreenAd(StyledViewActivity.this);

        arrayList = new ArrayList<>();
        arrayList = getArrayLIst(mContext);

        if (arrayList != null && arrayList.size() > 0) {
            for (int i = 0; i < arrayList.size(); i++) {
                if (arrayList.get(i).equals(sharingText)) {
                    favoriteFab.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.add));
                } else {
                    favoriteFab.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.remove));
                }
            }
        }


        favoriteFab.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<String> tempList = new ArrayList<>();
                Log.e("else ", "");
                tempList = getArrayLIst(mContext);

                String str = sharingText;


                if (arrayList == null) {
                    tempList = new ArrayList<>();
                    tempList.add(str);
                    setArrayList(mContext, tempList);

                    favoriteFab.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.add));
                } else if (arrayList.size() == 0) {
                    Log.e("else if1", "" + arrayList.size());
                    tempList = new ArrayList<>();
                    tempList.add(str);

                    favoriteFab.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.add));
                    setArrayList(mContext, tempList);
                } else {
                    Log.e("else1", "" + arrayList.size());
                    int aaa = 0;
                    for (int i = 0; i < tempList.size(); i++) {
                        if (tempList.get(i).equals(str)) {
                            tempList.remove(i);

                            favoriteFab.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.remove));
                            aaa = 1;
                            setArrayList(mContext, tempList);
                        }
                    }
                    if (aaa == 0) {
                        tempList.add(str);

                        favoriteFab.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.add));
                        setArrayList(mContext, tempList);
                    }
                }
            }
        });

        setWallpaperFab.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                    String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.SET_WALLPAPER};
                    String rationale = "Please provide  permission so that you can ...";
                    Permissions.Options options = new Permissions.Options().setRationaleDialogTitle("Info").setSettingsDialogTitle("Warning");

                    Permissions.check(getContext(), permissions, rationale, options, new PermissionHandler() {
                        @Override
                        public void onGranted() {
                            File file = storeImage(sharingText);
                            if (file != null) {

                                MediaScannerConnection.scanFile(getContext(), new String[]{file.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                                    @Override
                                    public void onScanCompleted(String path, Uri uri) {
                                    }
                                });
                                Uri uri = FileProvider.getUriForFile(getContext(), BuildConfig.APPLICATION_ID + ".provider", file);
                                setAsWallpaper(uri);

                            } else {
                                Toast.makeText(getContext(), "Couldn't save image Try Again!", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onDenied(Context context, ArrayList<String> deniedPermissions) {

                        }
                    });
                } else {



                        File file = storeImage(sharingText);
                        if (file != null) {

                            MediaScannerConnection.scanFile(getContext(), new String[]{file.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                                @Override
                                public void onScanCompleted(String path, Uri uri) {
                                }
                            });
                            Uri uri = FileProvider.getUriForFile(getContext(), BuildConfig.APPLICATION_ID + ".provider", file);
                            setAsWallpaper(uri);

                        } else {
                            Toast.makeText(getContext(), "Couldn't save image Try Again!", Toast.LENGTH_SHORT).show();
                        }


                }

            }
        });


        downloadFab.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {




                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {

                    String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                    String rationale = "Please provide Storage permission so that you can ...";
                    Permissions.Options options = new Permissions.Options().setRationaleDialogTitle("Info").setSettingsDialogTitle("Warning");

                    Permissions.check(getContext(), permissions, rationale, options, new PermissionHandler() {
                        @Override
                        public void onGranted() {
                            downloadImage();
                        }

                        @Override
                        public void onDenied(Context context, ArrayList<String> deniedPermissions) {

                        }
                    });
                } else {

                            downloadImage();



                }


            }
        });


        shareFab.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                    String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                    String rationale = "Please provide Storage permission so that you can ...";
                    Permissions.Options options = new Permissions.Options().setRationaleDialogTitle("Info").setSettingsDialogTitle("Warning");

                    Permissions.check(getContext(), permissions, rationale, options, new PermissionHandler() {
                        @Override
                        public void onGranted() {
                            sendShareIntent();
                        }

                        @Override
                        public void onDenied(Context context, ArrayList<String> deniedPermissions) {

                        }
                    });
                } else {
                    sendShareIntent();
                }


            }
        });


        view.findViewById(R.id.btnShare).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {

                    String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                    String rationale = "Please provide Storage permission so that you can ...";
                    Permissions.Options options = new Permissions.Options().setRationaleDialogTitle("Info").setSettingsDialogTitle("Warning");

                    Permissions.check(getContext(), permissions, rationale, options, new PermissionHandler() {
                        @Override
                        public void onGranted() {
                            sendShareIntent();
                        }

                        @Override
                        public void onDenied(Context context, ArrayList<String> deniedPermissions) {

                        }
                    });
                } else {
                    sendShareIntent();
                }


            }
        });

        buttonDownload.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                    String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                    String rationale = "Please provide Storage permission so that you can ...";
                    Permissions.Options options = new Permissions.Options().setRationaleDialogTitle("Info").setSettingsDialogTitle("Warning");

                    Permissions.check(getContext(), permissions, rationale, options, new PermissionHandler() {
                        @Override
                        public void onGranted() {
                            downloadImage();
                        }

                        @Override
                        public void onDenied(Context context, ArrayList<String> deniedPermissions) {

                        }
                    });
                } else {
                    downloadImage();
                }


            }
        });


    }

    private void downloadImage() {

        File file = storeImage(sharingText);
        if (file != null) {

            MediaScannerConnection.scanFile(getContext(), new String[]{file.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                @Override
                public void onScanCompleted(String path, Uri uri) {

                }
            });
            Toast.makeText(getContext(), "Image Saved Successfully!!!", Toast.LENGTH_SHORT).show();
        } else {

            Toast.makeText(getContext(), "Couldn't save image Try Again!", Toast.LENGTH_SHORT).show();

        }
    }


    private File storeImage(String url) {
        String fileName = url.substring(url.lastIndexOf('/') + 1, url.length());
        Log.e("filename", "==" + fileName);
        File pictureFile = getOutputMediaFile(fileName);
        AssetManager assetManager = getContext().getAssets();
        if (pictureFile == null) {
            Log.e("save", "Error creating media file, check storage permissions: ");
            return null;
        }


        try {
            InputStream is = assetManager.open("wallpaper/" + url.substring(url.lastIndexOf('/') + 1, url.length()));
            FileOutputStream fos = new FileOutputStream(pictureFile);
            copyFile(is, fos);
            is.close();
            is = null;
            fos.flush();
            fos.close();
            fos = null;
        } catch (FileNotFoundException e) {
            Log.e("save1", "File not found: " + e.getMessage());
        } catch (IOException e) {
            Log.e("save2", "Error accessing file: " + e.getMessage());
        }
        return pictureFile;
    }

    private File getOutputMediaFile(String filename) {

        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), getContext().getResources().getString(R.string.app_name));

        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                return null;
            }
        }

        String timeStamp = new SimpleDateFormat("ddMMyyyy_HHmm").format(new Date());
        File mediaFile;
        String mImageName = "img_" + timeStamp + ".jpg";
        mediaFile = new File(mediaStorageDir.getPath() + File.separator + mImageName);
        return mediaFile;
    }


    private void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
    }


    void setArrayList(Context mContext, ArrayList<String> arrayList) {

        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(mContext);
        SharedPreferences.Editor editor = sharedPrefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(arrayList);
        editor.putString("list", json);
        editor.commit();

    }

    ArrayList<String> getArrayLIst(Context mContext) {
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(mContext);
        Gson gson = new Gson();
        String json = sharedPrefs.getString("list", null);
        Type type = new TypeToken<ArrayList<String>>() {
        }.getType();
        ArrayList<String> arrayList = gson.fromJson(json, type);
        return arrayList;
    }

    public void setAsWallpaper(Uri uri) {
        WallpaperManager wallpaperManager = WallpaperManager.getInstance(mContext);
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(mContext.getContentResolver(), uri);
            wallpaperManager.setBitmap(bitmap);
            Toast.makeText(getContext(), "Wallpaper set success!", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Log.e("TAG", "setAsWallpaper: " + e.getMessage());
            e.printStackTrace();
        }
    }


}
