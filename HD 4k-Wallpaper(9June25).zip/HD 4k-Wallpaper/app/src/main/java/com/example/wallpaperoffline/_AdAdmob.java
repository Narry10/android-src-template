package com.example.wallpaperoffline;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;


public class _AdAdmob {
    static ProgressDialog ProgressDialog;

    public _AdAdmob(Activity activity) {


        MobileAds.initialize(activity, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus
                                                         initializationStatus) {
            }
        });


    }




    public static void FullscreenAd(final Activity activity) {


        Ad_Popup(activity);

        AdRequest adRequest = new AdRequest.Builder().build();

        InterstitialAd.load(activity, activity.getString(R.string.int_admob), adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {

                        interstitialAd.show(activity);
                        ProgressDialog.dismiss();

                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                        ProgressDialog.dismiss();
                    }
                });


    }


    private static void Ad_Popup(Context mContext) {
        ProgressDialog = ProgressDialog.show(mContext, "", "Ad Loading . . .", true);
        ProgressDialog.setCancelable(true);
        ProgressDialog.show();

    }

}