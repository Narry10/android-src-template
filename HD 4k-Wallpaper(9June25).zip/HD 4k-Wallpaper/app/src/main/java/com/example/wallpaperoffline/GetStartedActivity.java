package com.example.wallpaperoffline;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.example.wallpaperoffline.menu.features.Wallpaper.styled.StyledViewActivity;

import vocsy.ads.AppUtil;
import vocsy.ads.CustomAdsListener;
import vocsy.ads.ExitScreen;
import vocsy.ads.GoogleAds;


public class GetStartedActivity extends AppCompatActivity {
    private ImageView start, share, privacy, rate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SystemConfiguration.setTransparentStatusBar(this, SystemConfiguration.IconColor.ICON_LIGHT);
        setContentView(R.layout.activity_get_start);

        ((WallpaperApp) getApplication()).logAnalyticsEvent("IN App", "GetStartedActivity");


        rate = findViewById(R.id.rate);
        share = findViewById(R.id.share);
        privacy = findViewById(R.id.privacy);
        start = findViewById(R.id.start);

        GoogleAds.getInstance().admobBanner(this, (LinearLayout) findViewById(R.id.nativeLay));



        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                GoogleAds.getInstance().showCounterInterstitialAd(GetStartedActivity.this, new CustomAdsListener() {
//                    @Override
//                    public void onFinish() {
                        startActivity(new Intent(GetStartedActivity.this, StyledViewActivity.class));

//                    }
//                });

            }
        });

        rate.setOnClickListener(view -> AppUtil.rateApp(GetStartedActivity.this));
        share.setOnClickListener(view -> AppUtil.shareApp(GetStartedActivity.this));
        privacy.setOnClickListener(view -> AppUtil.privacyPolicy(GetStartedActivity.this, getString(R.string.privacy_policy)));
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        startActivity(new Intent(GetStartedActivity.this, ExitScreen.class));
    }
}