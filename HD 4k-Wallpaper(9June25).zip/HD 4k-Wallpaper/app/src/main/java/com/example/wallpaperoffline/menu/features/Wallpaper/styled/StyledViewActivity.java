package com.example.wallpaperoffline.menu.features.Wallpaper.styled;


import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;

import com.example.wallpaperoffline.R;
import com.example.wallpaperoffline.SystemConfiguration;
import com.example.wallpaperoffline._AdAdmob;
import com.example.wallpaperoffline.common.views.ImageOverlayView;
import com.example.wallpaperoffline.menu.features.Wallpaper.WallpaperActivity;
import com.example.wallpaperoffline.utils.StylingOptions;
import com.facebook.drawee.generic.GenericDraweeHierarchyBuilder;
import com.facebook.drawee.generic.RoundingParams;
import com.stfalcon.frescoimageviewer.ImageViewer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import jp.wasabeef.fresco.processors.GrayscalePostprocessor;
import vocsy.ads.GoogleAds;


public class StyledViewActivity extends WallpaperActivity {

    private ImageOverlayView overlayView;
    private StylingOptions options;
    private String[] listItem;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SystemConfiguration.setStatusBarColor(this, R.color.black, SystemConfiguration.IconColor.ICON_LIGHT);
        _AdAdmob.FullscreenAd(StyledViewActivity.this);
        GoogleAds.getInstance().admobBanner(this, (LinearLayout) findViewById(R.id.nativeLay));

        options = new StylingOptions();

    }

    @Override
    protected void showPicker(int startPosition) {

        try {
            ImageViewer.Builder builder = new ImageViewer.Builder<>(this, loadCharacters())
                    .setStartPosition(startPosition)
                    .setOnDismissListener(getDismissListener());

            builder.hideStatusBar(options.get(StylingOptions.Property.HIDE_STATUS_BAR));

            if (options.get(StylingOptions.Property.IMAGE_MARGIN)) {
                builder.setImageMargin(this, R.dimen.image_margin);
            }

            if (options.get(StylingOptions.Property.CONTAINER_PADDING)) {
                builder.setContainerPadding(this, R.dimen.image_margin);
            }

            if (options.get(StylingOptions.Property.IMAGES_ROUNDING)) {
                builder.setCustomDraweeHierarchyBuilder(getRoundedHierarchyBuilder());
            }

            builder.allowSwipeToDismiss(options.get(StylingOptions.Property.SWIPE_TO_DISMISS));

            builder.allowZooming(options.get(StylingOptions.Property.ZOOMING));

            if (options.get(StylingOptions.Property.SHOW_OVERLAY)) {
                overlayView = new ImageOverlayView(this);
                builder.setOverlayView(overlayView);
                builder.setImageChangeListener(getImageChangeListener());
            }

            if (options.get(StylingOptions.Property.RANDOM_BACKGROUND)) {
                builder.setBackgroundColor(getRandomColor());
            }

            if (options.get(StylingOptions.Property.POST_PROCESSING)) {
                builder.setCustomImageRequestBuilder(
                        ImageViewer.createImageRequestBuilder()
                                .setPostprocessor(new GrayscalePostprocessor()));
            }

            builder.show();
        } catch (Exception e) {
            Log.e("TAG", "showPicker: " + e.getMessage());
        }


    }

    private ImageViewer.OnImageChangeListener getImageChangeListener() {
        return new ImageViewer.OnImageChangeListener() {
            @Override
            public void onImageChange(int position) {
                String url = loadCharacters()[position];
                overlayView.setShareText(url);

            }
        };
    }

    private ImageViewer.OnDismissListener getDismissListener() {
        return new ImageViewer.OnDismissListener() {
            @Override
            public void onDismiss() {
               /* AppUtils.showInfoSnackbar(findViewById(R.id.coordinator),
                        R.string.message_on_dismiss, false);*/
            }
        };
    }

    private GenericDraweeHierarchyBuilder getRoundedHierarchyBuilder() {
        RoundingParams roundingParams = new RoundingParams();
        roundingParams.setRoundAsCircle(true);

        return GenericDraweeHierarchyBuilder.newInstance(getResources())
                .setRoundingParams(roundingParams);
    }

    private int getRandomColor() {
        Random random = new Random();
        return Color.argb(255, random.nextInt(156), random.nextInt(156), random.nextInt(156));
    }

    private String[] loadCharacters() {
        try {
            listItem = getAssets().list("wallpaper");
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (listItem != null) {
            List<String> tmplist = new ArrayList();
            for (String aListItem : listItem) {

                tmplist.add("asset:///wallpaper/" + aListItem);

            }
            listItem = (String[]) tmplist.toArray(new String[tmplist.size()]);

            return listItem;

        }
        return new String[0];
    }


}
