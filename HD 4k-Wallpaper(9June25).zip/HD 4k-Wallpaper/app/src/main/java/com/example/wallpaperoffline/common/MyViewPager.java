package com.example.wallpaperoffline.common;


public class MyViewPager {
}
