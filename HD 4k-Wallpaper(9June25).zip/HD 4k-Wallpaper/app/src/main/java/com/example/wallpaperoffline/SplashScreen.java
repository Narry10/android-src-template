package com.example.wallpaperoffline;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import vocsy.ads.AdsHandler;
import vocsy.ads.GetSmartAdmob;

public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        SystemConfiguration.setTransparentStatusBar(this, SystemConfiguration.IconColor.ICON_LIGHT);
        String[] adsUrls = new String[]{
                getString(vocsy.ads.R.string.bnr_admob)
                , getString(vocsy.ads.R.string.native_admob)
                , getString(vocsy.ads.R.string.int_admob)
                , getString(vocsy.ads.R.string.app_open_admob)
                , getString(vocsy.ads.R.string.video_admob)
        };

        new GetSmartAdmob(this, adsUrls, (success) -> {
           start();;
        }).execute();

        AdsHandler.setAdsOn(true);

        ((WallpaperApp) getApplication()).logAnalyticsEvent("Open App", "SplashScreen");
    }

    private void start() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(SplashScreen.this, GetStartedActivity.class));
            }
        },2000);
    }
}