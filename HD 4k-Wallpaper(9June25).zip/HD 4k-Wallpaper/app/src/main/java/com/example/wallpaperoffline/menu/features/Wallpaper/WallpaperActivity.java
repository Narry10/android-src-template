package com.example.wallpaperoffline.menu.features.Wallpaper;


import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.ColorInt;
import androidx.annotation.ColorRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.wallpaperoffline.FavouriteActivity;
import com.example.wallpaperoffline.R;

import com.example.wallpaperoffline.SystemConfiguration;
import com.example.wallpaperoffline.menu.features.ImageAdapter;
import com.stfalcon.frescoimageviewer.ImageViewer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import vocsy.ads.GoogleAds;


public abstract class WallpaperActivity extends AppCompatActivity {

    private GridView gridView;
    private String[] listItem;
    private ImageView fav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SystemConfiguration.setStatusBarColor(this, R.color.black, SystemConfiguration.IconColor.ICON_LIGHT);
        setContentView(R.layout.wallpaper);
        GoogleAds.getInstance().admobBanner(this, (LinearLayout) findViewById(R.id.nativeLay));

        gridView = (GridView) findViewById(R.id.grid_view);
        fav = findViewById(R.id.fav);

        fav.setOnClickListener(view -> startActivity(new Intent(WallpaperActivity.this, FavouriteActivity.class)));

        gridView.setAdapter(new ImageAdapter(WallpaperActivity.this, loadCharacters()));
        gridView.setOnItemClickListener((parent, view, position, id) -> {
            showPicker(position);
        });

    }

    protected void showPicker(int startPosition) {
        new ImageViewer.Builder<>(WallpaperActivity.this, listItem)
                .setStartPosition(startPosition)
                .show();
    }


    private String[] loadCharacters() {
        try {
            this.listItem = getAssets().list("wallpaper");
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (this.listItem != null) {
            List<String> tmplist = new ArrayList();
            for (String aListItem : this.listItem) {
                tmplist.add("wallpaper/" + aListItem);
            }
            this.listItem = (String[]) tmplist.toArray(new String[tmplist.size()]);
            return listItem;

        }
        return new String[0];
    }

    private String[] loadScreenTitles() {
        return getResources().getStringArray(R.array.ld_activityScreenTitles);
    }

    private Drawable[] loadScreenIcons() {
        TypedArray ta = getResources().obtainTypedArray(R.array.ld_activityScreenIcons);
        Drawable[] icons = new Drawable[ta.length()];
        for (int i = 0; i < ta.length(); i++) {
            int id = ta.getResourceId(i, 0);
            if (id != 0) {
                icons[i] = ContextCompat.getDrawable(this, id);
            }
        }
        ta.recycle();
        return icons;
    }

    @ColorInt
    private int color(@ColorRes int res) {
        return ContextCompat.getColor(this, res);
    }


}
