package com.example.wallpaperoffline.menu.features;


import static vocsy.ads.GoogleNativeAdAdapter.mContext;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.example.wallpaperoffline.R;
import com.facebook.drawee.view.SimpleDraweeView;

import java.io.IOException;
import java.io.InputStream;

import vocsy.ads.CustomAdsListener;
import vocsy.ads.GoogleAds;


public class ImageAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;
    private String[] listItem;


    public ImageAdapter(Context activity, String[] strings) {

        this.listItem = strings;
        this.context = activity;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return listItem.length;
    }

    @Override
    public Object getItem(int position) {
        return listItem[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public class Holder {
        SimpleDraweeView os_img;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final Holder holder = new Holder();
        convertView = inflater.inflate(R.layout.wallpaper_item, parent, false);
        holder.os_img = convertView.findViewById(R.id.imageitem);

        holder.os_img.setImageDrawable(getImage(listItem[position].replace("asset:///", "")));


        return convertView;
    }

    public Drawable getImage(String fileName) {
        try {

            InputStream ims = context.getAssets().open(fileName);

            Drawable d = Drawable.createFromStream(ims, null);
            ims.close();
            return d;
        } catch (IOException ex) {
            Log.e("TAG", "getImage: Exception: " + ex.getMessage());
            return null;
        }
    }


}
