package vocsy.ads;

public interface CustomAdsListener {
    void onFinish();
}
