package com.demo.aivoicetranslator.adapter;

import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.activity.PhrasesListActivity;
import com.demo.aivoicetranslator.extra.MySp;
import com.demo.aivoicetranslator.model.PhrasesList;
import com.mannan.translateapi.Language;
import java.util.ArrayList;

public class AdapterPhrasesList extends RecyclerView.Adapter<AdapterPhrasesList.ViewHolder> {
    ArrayList<PhrasesList> list;
    setOnClickListner mListner;
    MySp mySp;

    public interface setOnClickListner {
        void onItemClick(int i);
    }

    public AdapterPhrasesList(ArrayList<PhrasesList> arrayList, setOnClickListner setonclicklistner) {
        this.list = arrayList;
        this.mListner = setonclicklistner;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.phrases_list_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
        PhrasesList phrasesList = this.list.get(i);
        Glide.with(viewHolder.itemView.getContext()).load(Integer.valueOf(PhrasesListActivity.flag[i])).into(viewHolder.imgPhrases);
        MySp mySp2 = new MySp(viewHolder.itemView.getContext());
        this.mySp = mySp2;
        String firstLanCodePhr = mySp2.getFirstLanCodePhr();
        firstLanCodePhr.hashCode();
        char c = 65535;
        switch (firstLanCodePhr.hashCode()) {
            case 3201:
                if (firstLanCodePhr.equals(Language.GERMAN)) {
                    c = 0;
                    break;
                }
                break;
            case 3355:
                if (firstLanCodePhr.equals("id")) {
                    c = 1;
                    break;
                }
                break;
            case 3371:
                if (firstLanCodePhr.equals(Language.ITALIAN)) {
                    c = 2;
                    break;
                }
                break;
            case 3383:
                if (firstLanCodePhr.equals(Language.JAPANESE)) {
                    c = 3;
                    break;
                }
                break;
            case 3518:
                if (firstLanCodePhr.equals(Language.DUTCH)) {
                    c = 4;
                    break;
                }
                break;
            case 3580:
                if (firstLanCodePhr.equals(Language.POLISH)) {
                    c = 5;
                    break;
                }
                break;
            case 3645:
                if (firstLanCodePhr.equals(Language.ROMANIAN)) {
                    c = 6;
                    break;
                }
                break;
            case 3651:
                if (firstLanCodePhr.equals(Language.RUSSIAN)) {
                    c = 7;
                    break;
                }
                break;
            case 3683:
                if (firstLanCodePhr.equals(Language.SWEDISH)) {
                    c = 8;
                    break;
                }
                break;
            case 3700:
                if (firstLanCodePhr.equals(Language.THAI)) {
                    c = 9;
                    break;
                }
                break;
            case 3710:
                if (firstLanCodePhr.equals(Language.TURKISH)) {
                    c = 10;
                    break;
                }
                break;
            case 93071090:
                if (firstLanCodePhr.equals("ar_AE")) {
                    c = 11;
                    break;
                }
                break;
            case 93071216:
                if (firstLanCodePhr.equals("ar_EG")) {
                    c = 12;
                    break;
                }
                break;
            case 93071644:
                if (firstLanCodePhr.equals("ar_SA")) {
                    c = 13;
                    break;
                }
                break;
            case 96646026:
                if (firstLanCodePhr.equals("en_AU")) {
                    c = 14;
                    break;
                }
                break;
            case 96646636:
                if (firstLanCodePhr.equals("en_UK")) {
                    c = 15;
                    break;
                }
                break;
            case 96646644:
                if (firstLanCodePhr.equals("en_US")) {
                    c = 16;
                    break;
                }
                break;
            case 96795103:
                if (firstLanCodePhr.equals("es_ES")) {
                    c = 17;
                    break;
                }
                break;
            case 96795356:
                if (firstLanCodePhr.equals("es_MX")) {
                    c = 18;
                    break;
                }
                break;
            case 96795599:
                if (firstLanCodePhr.equals("es_US")) {
                    c = 19;
                    break;
                }
                break;
            case 97688753:
                if (firstLanCodePhr.equals("fr_CA")) {
                    c = 20;
                    break;
                }
                break;
            case 97688863:
                if (firstLanCodePhr.equals("fr_FR")) {
                    c = 21;
                    break;
                }
                break;
            case 106983531:
                if (firstLanCodePhr.equals("pt_BR")) {
                    c = 22;
                    break;
                }
                break;
            case 106983967:
                if (firstLanCodePhr.equals("pt_PT")) {
                    c = 23;
                    break;
                }
                break;
            case 115861276:
                if (firstLanCodePhr.equals("zh_CN")) {
                    c = 24;
                    break;
                }
                break;
            case 115861812:
                if (firstLanCodePhr.equals("zh_TW")) {
                    c = 25;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                viewHolder.textPhrases.setText(phrasesList.de);
                break;
            case 1:
                viewHolder.textPhrases.setText(phrasesList.id);
                break;
            case 2:
                viewHolder.textPhrases.setText(phrasesList.it);
                break;
            case 3:
                viewHolder.textPhrases.setText(phrasesList.ja);
                break;
            case 4:
                viewHolder.textPhrases.setText(phrasesList.nl);
                break;
            case 5:
                viewHolder.textPhrases.setText(phrasesList.pl);
                break;
            case 6:
                viewHolder.textPhrases.setText(phrasesList.ro);
                break;
            case 7:
                viewHolder.textPhrases.setText(phrasesList.ru);
                break;
            case 8:
                viewHolder.textPhrases.setText(phrasesList.sv);
                break;
            case 9:
                viewHolder.textPhrases.setText(phrasesList.th);
                break;
            case 10:
                viewHolder.textPhrases.setText(phrasesList.tr);
                break;
            case 11:
                viewHolder.textPhrases.setText(phrasesList.ar_AE);
                break;
            case 12:
                viewHolder.textPhrases.setText(phrasesList.ar_EG);
                break;
            case 13:
                viewHolder.textPhrases.setText(phrasesList.ar_SA);
                break;
            case 14:
                viewHolder.textPhrases.setText(phrasesList.en_AU);
                break;
            case 15:
                viewHolder.textPhrases.setText(phrasesList.en_UK);
                break;
            case 16:
                viewHolder.textPhrases.setText(phrasesList.en_US);
                break;
            case 17:
                viewHolder.textPhrases.setText(phrasesList.es_ES);
                break;
            case 18:
                viewHolder.textPhrases.setText(phrasesList.es_MX);
                break;
            case 19:
                viewHolder.textPhrases.setText(phrasesList.es_US);
                break;
            case 20:
                viewHolder.textPhrases.setText(phrasesList.fr_CA);
                break;
            case 21:
                viewHolder.textPhrases.setText(phrasesList.fr_FR);
                break;
            case 22:
                viewHolder.textPhrases.setText(phrasesList.pt_BR);
                break;
            case 23:
                viewHolder.textPhrases.setText(phrasesList.pt_PT);
                break;
            case 24:
                viewHolder.textPhrases.setText(phrasesList.zh_CN);
                break;
            case 25:
                viewHolder.textPhrases.setText(phrasesList.zh_TW);
                break;
            default:
                viewHolder.textPhrases.setText(phrasesList.en_US);
                break;
        }
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewHolder.itemView.setAlpha(0.5f);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        viewHolder.itemView.setAlpha(1.0f);
                    }
                }, 100);
                AdapterPhrasesList.this.mListner.onItemClick(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgPhrases;
        TextView textPhrases;

        public ViewHolder(View view) {
            super(view);
            this.imgPhrases = (ImageView) view.findViewById(R.id.img_phrases);
            this.textPhrases = (TextView) view.findViewById(R.id.text_phrases);
        }
    }
}
