package com.demo.aivoicetranslator.activity;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.constraintlayout.helper.widget.MotionEffect;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewpager.widget.ViewPager;
import com.bumptech.glide.load.Key;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.demo.aivoicetranslator.adapter.AdapterSection;
import com.demo.aivoicetranslator.adapter.PageAdapter;
import com.demo.aivoicetranslator.databinding.ActivityPhrasesBinding;
import com.demo.aivoicetranslator.model.Sections;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;

public class PhrasesActivity extends BaseActivity {
    public static ArrayList<Sections> mList = new ArrayList<>();
    public static int phrases_Activity_Flag = 0;
    public static String phrases_Activity_Online_Flag = "1";
    public static Sections sections;
    public static int select = 0;
    ActivityPhrasesBinding binding;
    Context context;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityPhrasesBinding inflate = ActivityPhrasesBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        this.context = this;
        this.binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PhrasesActivity.this.onBackPressed();
            }
        });
        int intExtra = getIntent().getIntExtra("id", 0);
        Log.d(MotionEffect.TAG, "onCreate: " + intExtra);
        try {
            String isToString = isToString(getAssets().open("sections.json"));
            mList.clear();
            Iterator it = ((ArrayList) new Gson().fromJson(isToString, new TypeToken<ArrayList<Sections>>() {
            }.getType())).iterator();
            while (it.hasNext()) {
                Sections sections2 = (Sections) it.next();
                if (sections2.category_id == intExtra) {
                    mList.add(sections2);
                }
            }
            sections = mList.get(0);
            this.binding.recyclerViewSection.setAdapter(new AdapterSection(mList, new AdapterSection.setOnClickListner() {
                @Override
                public void onItemClick(int i) {
                    Log.d(MotionEffect.TAG, "onItemClick: " + PhrasesActivity.mList.get(i).section_id);
                    PhrasesActivity.this.binding.viewPager.setCurrentItem(i);
                    PhrasesActivity.sections = PhrasesActivity.mList.get(i);
                    PhrasesActivity.this.setTeb(i);
                }
            }));
            this.binding.recyclerViewSection.setLayoutManager(new LinearLayoutManager(this.context, 0, false));
            this.binding.viewPager.setAdapter(new PageAdapter(this.context, getSupportFragmentManager(), 0, mList.size()));
            this.binding.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrollStateChanged(int i) {
                }

                @Override
                public void onPageScrolled(int i, float f, int i2) {
                }

                @Override
                public void onPageSelected(int i) {
                    PhrasesActivity.this.binding.recyclerViewSection.scrollToPosition(i);
                    PhrasesActivity.sections = PhrasesActivity.mList.get(i);
                    PhrasesActivity.this.setTeb(i);
                    Log.d(MotionEffect.TAG, "onPageSelected: " + i);
                }
            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    
    public void setTeb(int i) {
        select = i;
        this.binding.recyclerViewSection.getAdapter().notifyDataSetChanged();
    }

    public String isToString(InputStream inputStream) {
        char[] cArr = new char[1024];
        StringBuilder sb = new StringBuilder();
        try {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Key.STRING_CHARSET_NAME);
            while (true) {
                try {
                    int read = inputStreamReader.read(cArr, 0, 1024);
                    if (read < 0) {
                        return sb.toString();
                    }
                    sb.append(cArr, 0, read);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (UnsupportedEncodingException e2) {
            throw new RuntimeException(e2);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}
