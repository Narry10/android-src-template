package com.demo.aivoicetranslator.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.databinding.ActivityOcractivityBinding;

public class OCRActivity extends BaseActivity {
    ActivityOcractivityBinding binding;
    Context context;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityOcractivityBinding inflate = ActivityOcractivityBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        this.context = this;
        this.binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OCRActivity.this.onBackPressed();
            }
        });
        //Bitmap bitmap = CropActivity.crop;
        Bitmap bitmap = CameraActivity.myBitmap;
        getTextRec(bitmap);
        ((RequestBuilder) Glide.with(this.context).load(bitmap).centerCrop()).into(this.binding.imgCrop);
        this.binding.imgCrop.setImageBitmap(bitmap);
        this.binding.imgVoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.isSelected()) {
                    OCRActivity.this.binding.edtInput.setEnabled(false);
                    view.setSelected(false);
                    return;
                }
                OCRActivity.this.binding.edtInput.setEnabled(true);
                view.setSelected(true);
            }
        });
        this.binding.next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (OCRActivity.this.binding.edtInput.getText().toString().isEmpty()) {
                    Toast.makeText(OCRActivity.this.context, OCRActivity.this.getString(R.string.please_enter_word), 0).show();
                } else {
                    OCRActivity.this.startActivity(new Intent(OCRActivity.this.context, TextActivity.class).putExtra("text", OCRActivity.this.binding.edtInput.getText().toString()));
                }
            }
        });
    }

    private void getTextRec(Bitmap bitmap) {
        TextRecognizer build = new TextRecognizer.Builder(this.context).build();
        if (!build.isOperational()) {
            Toast.makeText(this, "Error!", 0).show();
            return;
        }
        SparseArray<TextBlock> detect = build.detect(new Frame.Builder().setBitmap(bitmap).build());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < detect.size(); i++) {
            sb.append(detect.valueAt(i).getValue());
            sb.append("\n");
        }
        Log.d("TAG", "onActivityResult: " + sb.toString());
        this.binding.edtInput.setText(sb.toString());
    }
}
