package com.demo.aivoicetranslator.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PointF;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.demo.aivoicetranslator.databinding.ActivityCameraBinding;
import com.otaliastudios.cameraview.BitmapCallback;
import com.otaliastudios.cameraview.CameraException;
import com.otaliastudios.cameraview.CameraListener;
import com.otaliastudios.cameraview.PictureResult;
import com.otaliastudios.cameraview.controls.Flash;
import com.otaliastudios.cameraview.controls.Mode;
import com.otaliastudios.cameraview.markers.AutoFocusMarker;
import com.otaliastudios.cameraview.markers.AutoFocusTrigger;
import com.otaliastudios.cameraview.size.SizeSelectors;

public class CameraActivity extends BaseActivity {

    public static Bitmap myBitmap;
    public static Bitmap finalBitmap;
    ActivityCameraBinding binding;
    Context context;
    boolean isFlashSupported;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityCameraBinding inflate = ActivityCameraBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        this.context = this;
        this.binding.cameraView.setLifecycleOwner(this);
        setFlash(false);
        this.binding.flash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.isSelected()) {
                    CameraActivity.this.setFlash(false);
                } else {
                    CameraActivity.this.setFlash(true);
                }
            }
        });
        this.binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CameraActivity.this.onBackPressed();
            }
        });
        final AutoFocusMarker r3 = new AutoFocusMarker() {
            @Override
            public View onAttach(Context context, ViewGroup viewGroup) {
                return null;
            }

            @Override
            public void onAutoFocusStart(AutoFocusTrigger autoFocusTrigger, PointF pointF) {
                Log.d("TAG", "onAutoFocusStart: ok");
            }

            @Override
            public void onAutoFocusEnd(AutoFocusTrigger autoFocusTrigger, boolean z, PointF pointF) {
                Log.d("TAG", "onAutoFocusEnd: " + z);
                if (z) {
                    CameraActivity.this.binding.cameraView.setMode(Mode.PICTURE);
                    CameraActivity.this.binding.cameraView.setPictureSize(SizeSelectors.smallest());
                    CameraActivity.this.binding.cameraView.takePicture();
                    CameraActivity.this.binding.cameraView.takePictureSnapshot();
                }
            }
        };
        this.binding.click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CameraActivity.this.binding.cameraView.setAutoFocusResetDelay(1);
                CameraActivity.this.binding.cameraView.startAutoFocus((float) (CameraActivity.this.binding.cameraView.getWidth() / 2), (float) (CameraActivity.this.binding.cameraView.getHeight() / 2));
                CameraActivity.this.binding.cameraView.setAutoFocusMarker(r3);
            }
        });
        final BitmapCallback r32 = new BitmapCallback() {
            @Override
            public void onBitmapReady(Bitmap bitmap) {
                if (bitmap != null) {
                    CropActivity.myBit = bitmap;
                    myBitmap = bitmap;
                    //CameraActivity.this.startActivity(new Intent(CameraActivity.this.context, CropActivity.class));
                    CameraActivity.this.startActivity(new Intent(CameraActivity.this.context, OCRActivity.class));
                    CameraActivity.this.finish();
                }
            }
        };
        this.binding.cameraView.addCameraListener(new CameraListener() {
            @Override
            public void onCameraError(CameraException cameraException) {
                super.onCameraError(cameraException);
            }

            @Override
            public void onPictureTaken(PictureResult pictureResult) {
                super.onPictureTaken(pictureResult);
                pictureResult.toBitmap(r32);
            }

            @Override
            public void onPictureShutter() {
                super.onPictureShutter();
            }
        });
        this.binding.gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CameraActivity.this.startActivity(new Intent(CameraActivity.this.context, GalleryActivity.class));
            }
        });
    }

    
    public void setFlash(boolean z) {
        try {
            boolean booleanValue = ((Boolean) ((CameraManager) getSystemService("camera")).getCameraCharacteristics("0").get(CameraCharacteristics.FLASH_INFO_AVAILABLE)).booleanValue();
            this.isFlashSupported = booleanValue;
            if (!booleanValue) {
                return;
            }
            if (z) {
                this.binding.cameraView.setFlash(Flash.TORCH);
                this.binding.flash.setSelected(true);
                return;
            }
            this.binding.cameraView.setFlash(Flash.OFF);
            this.binding.flash.setSelected(false);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }
}
