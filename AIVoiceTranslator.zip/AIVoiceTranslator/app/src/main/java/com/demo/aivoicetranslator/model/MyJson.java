package com.demo.aivoicetranslator.model;

import java.util.ArrayList;

public class MyJson {
    ArrayList<PhrasesList> list;
}
