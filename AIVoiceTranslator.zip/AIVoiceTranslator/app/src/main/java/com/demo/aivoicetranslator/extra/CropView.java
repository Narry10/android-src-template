package com.demo.aivoicetranslator.extra;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import androidx.appcompat.widget.AppCompatImageView;
import java.io.ByteArrayOutputStream;

public class CropView extends AppCompatImageView {
    private static final int BOTTOM = 4;
    private static final int DRAG = 0;
    private static final int LEFT = 1;
    private static final int RIGHT = 3;
    private static final int TOP = 2;
    private static Point center;
    private static Point leftTop;
    private static Point previous;
    private static Point rightBottom;
    private int imageScaledHeight;
    private int imageScaledWidth;
    private int initial_size = 300;
    Paint paint = new Paint();

    public CropView(Context context) {
        super(context);
        initCropView();
    }

    public CropView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        initCropView();
    }

    public CropView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        initCropView();
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (leftTop.equals(0, 0)) {
            resetPoints();
        }
        canvas.drawRect((float) leftTop.x, (float) leftTop.y, (float) rightBottom.x, (float) rightBottom.y, this.paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action == 0) {
            previous.set((int) motionEvent.getX(), (int) motionEvent.getY());
        } else if (action == 1) {
            previous = new Point();
        } else if (action == 2 && isActionInsideRectangle(motionEvent.getX(), motionEvent.getY())) {
            adjustRectangle((int) motionEvent.getX(), (int) motionEvent.getY());
            invalidate();
            previous.set((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        return true;
    }

    private void initCropView() {
        this.paint.setColor(-1);
        this.paint.setStyle(Paint.Style.STROKE);
        this.paint.setStrokeWidth(5.0f);
        leftTop = new Point();
        rightBottom = new Point();
        center = new Point();
        previous = new Point();
    }

    public void resetPoints() {
        center.set(getWidth() / 2, getHeight() / 2);
        leftTop.set((getWidth() - this.initial_size) / 2, (getHeight() - this.initial_size) / 2);
        rightBottom.set(leftTop.x + this.initial_size, leftTop.y + this.initial_size);
    }

    private static boolean isActionInsideRectangle(float f, float f2) {
        return f >= ((float) (leftTop.x + -10)) && f <= ((float) (rightBottom.x + 10)) && f2 >= ((float) (leftTop.y + -10)) && f2 <= ((float) (rightBottom.y + 10));
    }

    private boolean isInImageRange(PointF pointF) {
        float[] fArr = new float[9];
        getImageMatrix().getValues(fArr);
        this.imageScaledWidth = Math.round(((float) getDrawable().getIntrinsicWidth()) * fArr[0]);
        this.imageScaledHeight = Math.round(((float) getDrawable().getIntrinsicHeight()) * fArr[4]);
        if (pointF.x < ((float) (center.x - (this.imageScaledWidth / 2))) || pointF.x > ((float) (center.x + (this.imageScaledWidth / 2))) || pointF.y < ((float) (center.y - (this.imageScaledHeight / 2))) || pointF.y > ((float) (center.y + (this.imageScaledHeight / 2)))) {
            return false;
        }
        return true;
    }

    private void adjustRectangle(int i, int i2) {
        int affectedSide = getAffectedSide((float) i, (float) i2);
        if (affectedSide == 0) {
            int i3 = i - previous.x;
            int i4 = i2 - previous.y;
            if (isInImageRange(new PointF((float) (leftTop.x + i3), (float) (leftTop.y + i4))) && isInImageRange(new PointF((float) (rightBottom.x + i3), (float) (rightBottom.y + i4)))) {
                Point point = leftTop;
                point.set(point.x + i3, leftTop.y + i4);
                Point point2 = rightBottom;
                point2.set(point2.x + i3, rightBottom.y + i4);
            }
        } else if (affectedSide == 1) {
            int i5 = i - leftTop.x;
            if (isInImageRange(new PointF((float) (leftTop.x + i5), (float) (leftTop.y + i5)))) {
                Point point3 = leftTop;
                point3.set(point3.x + i5, leftTop.y + i5);
            }
        } else if (affectedSide == 2) {
            int i6 = i2 - leftTop.y;
            if (isInImageRange(new PointF((float) (leftTop.x + i6), (float) (leftTop.y + i6)))) {
                Point point4 = leftTop;
                point4.set(point4.x + i6, leftTop.y + i6);
            }
        } else if (affectedSide == 3) {
            int i7 = i - rightBottom.x;
            if (isInImageRange(new PointF((float) (rightBottom.x + i7), (float) (rightBottom.y + i7)))) {
                Point point5 = rightBottom;
                point5.set(point5.x + i7, rightBottom.y + i7);
            }
        } else if (affectedSide == 4) {
            int i8 = i2 - rightBottom.y;
            if (isInImageRange(new PointF((float) (rightBottom.x + i8), (float) (rightBottom.y + i8)))) {
                Point point6 = rightBottom;
                point6.set(point6.x + i8, rightBottom.y + i8);
            }
        }
    }

    private static int getAffectedSide(float f, float f2) {
        if (f >= ((float) (leftTop.x - 10)) && f <= ((float) (leftTop.x + 10))) {
            return 1;
        }
        if (f2 >= ((float) (leftTop.y - 10)) && f2 <= ((float) (leftTop.y + 10))) {
            return 2;
        }
        if (f < ((float) (rightBottom.x - 10)) || f > ((float) (rightBottom.x + 10))) {
            return (f2 < ((float) (rightBottom.y + -10)) || f2 > ((float) (rightBottom.y + 10))) ? 0 : 4;
        }
        return 3;
    }

    public byte[] getCroppedImage() {
        BitmapDrawable bitmapDrawable = (BitmapDrawable) getDrawable();
        Bitmap createBitmap = Bitmap.createBitmap(bitmapDrawable.getBitmap(), (int) ((float) ((leftTop.x - center.x) + (bitmapDrawable.getBitmap().getWidth() / 2))), (int) ((float) ((leftTop.y - center.y) + (bitmapDrawable.getBitmap().getHeight() / 2))), rightBottom.x - leftTop.x, rightBottom.y - leftTop.y);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        createBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }
}
