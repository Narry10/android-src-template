package com.demo.aivoicetranslator.model;

public class ModelVoiceConvesation {
    public int id;
    public int imgFirst;
    public int imgSecond;
    public boolean isMy;
    public String lan;
    public String textFirst;
    public String textSecond;

    public ModelVoiceConvesation(int i, int i2, int i3, String str, String str2, String str3, boolean z) {
        this.id = i;
        this.imgFirst = i2;
        this.imgSecond = i3;
        this.textFirst = str;
        this.textSecond = str2;
        this.lan = str3;
        this.isMy = z;
    }
}
