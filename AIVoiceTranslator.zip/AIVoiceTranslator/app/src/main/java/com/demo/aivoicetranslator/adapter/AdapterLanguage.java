package com.demo.aivoicetranslator.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.model.ModelLanguage;
import java.util.ArrayList;

public class AdapterLanguage extends RecyclerView.Adapter<AdapterLanguage.ViewHolder> {
    ArrayList<ModelLanguage> list;
    setOnClickListner mListner;

    public interface setOnClickListner {
        void onClick(int i);
    }

    public AdapterLanguage(ArrayList<ModelLanguage> arrayList, setOnClickListner setonclicklistner) {
        this.list = arrayList;
        this.mListner = setonclicklistner;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.language_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        ModelLanguage modelLanguage = this.list.get(i);
        Glide.with(viewHolder.itemView.getContext()).load(Integer.valueOf(modelLanguage.image)).into(viewHolder.imgFlag);
        viewHolder.textLanguage.setText(modelLanguage.name);
        if (modelLanguage.isSelect) {
            viewHolder.itemView.setSelected(true);
        } else {
            viewHolder.itemView.setSelected(false);
        }
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (int i = 0; i < AdapterLanguage.this.list.size(); i++) {
                    AdapterLanguage.this.list.get(i).isSelect = false;
                }
                AdapterLanguage.this.list.get(i).isSelect = true;
                AdapterLanguage.this.mListner.onClick(i);
                AdapterLanguage.this.notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView checkBox;
        ImageView imgFlag;
        TextView textLanguage;

        public ViewHolder(View view) {
            super(view);
            this.imgFlag = (ImageView) view.findViewById(R.id.img_lan);
            this.textLanguage = (TextView) view.findViewById(R.id.text_language);
            this.checkBox = (ImageView) view.findViewById(R.id.check);
        }
    }
}
