package com.demo.aivoicetranslator.adapter;

import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.helper.widget.MotionEffect;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.load.Key;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.model.Phrases;
import com.demo.aivoicetranslator.model.Sections;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;

public class AdapterViewPager extends RecyclerView.Adapter<AdapterViewPager.ViewHolder> {
    ArrayList<Sections> list;
    public TextToSpeech tts;

    public AdapterViewPager(ArrayList<Sections> arrayList) {
        this.list = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.phrases_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        Sections sections = this.list.get(i);
        Log.d(MotionEffect.TAG, "onBindViewHolder: viewPager" + sections.en_US);
        try {
            String isToString = isToString(viewHolder.itemView.getContext().getAssets().open("phrases.json"));
            ArrayList arrayList = new ArrayList();
            Iterator it = ((ArrayList) new Gson().fromJson(isToString, new TypeToken<ArrayList<Phrases>>() {
            }.getType())).iterator();
            while (it.hasNext()) {
                Phrases phrases = (Phrases) it.next();
                if (phrases.section_id == sections.section_id) {
                    Log.d(MotionEffect.TAG, "setViewPage: " + phrases.en_US);
                    arrayList.add(phrases);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RecyclerView recyclerView;

        public ViewHolder(View view) {
            super(view);
            this.recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view_phrases);
        }
    }

    public String isToString(InputStream inputStream) {
        char[] cArr = new char[1024];
        StringBuilder sb = new StringBuilder();
        try {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Key.STRING_CHARSET_NAME);
            while (true) {
                try {
                    int read = inputStreamReader.read(cArr, 0, 1024);
                    if (read < 0) {
                        return sb.toString();
                    }
                    sb.append(cArr, 0, read);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (UnsupportedEncodingException e2) {
            throw new RuntimeException(e2);
        }
    }
}
