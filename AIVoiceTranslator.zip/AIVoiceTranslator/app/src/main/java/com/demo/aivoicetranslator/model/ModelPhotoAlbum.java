package com.demo.aivoicetranslator.model;

public class ModelPhotoAlbum {
    public String folderName;
    public String imagePath;

    public ModelPhotoAlbum(String str, String str2) {
        this.folderName = str;
        this.imagePath = str2;
    }
}
