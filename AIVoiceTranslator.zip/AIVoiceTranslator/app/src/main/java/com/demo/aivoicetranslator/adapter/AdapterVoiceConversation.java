package com.demo.aivoicetranslator.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.model.ModelVoiceConvesation;
import java.util.ArrayList;

public class AdapterVoiceConversation extends RecyclerView.Adapter<AdapterVoiceConversation.ViewHolder> {
    ArrayList<ModelVoiceConvesation> list;
    setOnClickLisner mListner;

    public interface setOnClickLisner {
        void onCopy(int i);

        void onSpeak(int i);
    }

    public AdapterVoiceConversation(ArrayList<ModelVoiceConvesation> arrayList, setOnClickLisner setonclicklisner) {
        this.list = arrayList;
        this.mListner = setonclicklisner;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.conversation_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        ModelVoiceConvesation modelVoiceConvesation = this.list.get(i);
        viewHolder.textFirstLEF.setText(modelVoiceConvesation.textFirst);
        viewHolder.textFirstRIG.setText(modelVoiceConvesation.textFirst);
        viewHolder.textSecondLEF.setText(modelVoiceConvesation.textSecond);
        viewHolder.textSecondRIG.setText(modelVoiceConvesation.textSecond);
        viewHolder.textFirstLan.setText(modelVoiceConvesation.lan);
        viewHolder.textSecondLan.setText(modelVoiceConvesation.lan);
        if (modelVoiceConvesation.isMy) {
            Glide.with(viewHolder.itemView.getContext()).load(Integer.valueOf(modelVoiceConvesation.imgFirst)).into(viewHolder.imgFistLan);
            Glide.with(viewHolder.itemView.getContext()).load(Integer.valueOf(modelVoiceConvesation.imgSecond)).into(viewHolder.imgSecondLan);
            viewHolder.constLEF.setVisibility(8);
            viewHolder.imgFistLan.setVisibility(View.GONE);
            viewHolder.textFirstLan.setVisibility(8);
            viewHolder.constRIG.setVisibility(0);
            viewHolder.imgSecondLan.setVisibility(View.GONE);
            viewHolder.textSecondLan.setVisibility(0);
        } else {
            viewHolder.constRIG.setVisibility(8);
            viewHolder.imgSecondLan.setVisibility(View.GONE);
            viewHolder.textSecondLan.setVisibility(8);
            viewHolder.constLEF.setVisibility(0);
            viewHolder.imgFistLan.setVisibility(View.GONE);
            viewHolder.textFirstLan.setVisibility(0);
        }
        viewHolder.imgCopyLEF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterVoiceConversation.this.mListner.onCopy(i);
            }
        });
        viewHolder.imgCopyRIG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterVoiceConversation.this.mListner.onCopy(i);
            }
        });
        viewHolder.imgSpekLEF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterVoiceConversation.this.mListner.onSpeak(i);
            }
        });
        viewHolder.imgSpekRIG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterVoiceConversation.this.mListner.onSpeak(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout constLEF;
        ConstraintLayout constRIG;
        ImageView imgCopyLEF;
        ImageView imgCopyRIG;
        ImageView imgFistLan;
        ImageView imgSecondLan;
        ImageView imgSpekLEF;
        ImageView imgSpekRIG;
        TextView textFirstLEF;
        TextView textFirstLan;
        TextView textFirstRIG;
        TextView textSecondLEF;
        TextView textSecondLan;
        TextView textSecondRIG;

        public ViewHolder(View view) {
            super(view);
            this.imgFistLan = (ImageView) view.findViewById(R.id.img_first_lang);
            this.imgSecondLan = (ImageView) view.findViewById(R.id.img_second_lang);
            this.textFirstLEF = (TextView) view.findViewById(R.id.text_first_left);
            this.textSecondLEF = (TextView) view.findViewById(R.id.text_second_left);
            this.textFirstRIG = (TextView) view.findViewById(R.id.text_first_right);
            this.textSecondRIG = (TextView) view.findViewById(R.id.text_second_right);
            this.imgCopyLEF = (ImageView) view.findViewById(R.id.img_copy);
            this.imgCopyRIG = (ImageView) view.findViewById(R.id.img_copy_right);
            this.textFirstLan = (TextView) view.findViewById(R.id.text_first_lan);
            this.textSecondLan = (TextView) view.findViewById(R.id.text_second_lan);
            this.imgSpekLEF = (ImageView) view.findViewById(R.id.img_speak);
            this.imgSpekRIG = (ImageView) view.findViewById(R.id.img_speak_right);
            this.constLEF = (ConstraintLayout) view.findViewById(R.id.constraint_left);
            this.constRIG = (ConstraintLayout) view.findViewById(R.id.constraint_right);
        }
    }

}
