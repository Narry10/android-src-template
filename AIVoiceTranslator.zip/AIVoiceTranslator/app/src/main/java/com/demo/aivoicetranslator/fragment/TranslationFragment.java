package com.demo.aivoicetranslator.fragment;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.demo.aivoicetranslator.adapter.AdapterTransalation;
import com.demo.aivoicetranslator.databinding.FragmentTranslationBinding;
import com.demo.aivoicetranslator.extra.MySp;
import com.demo.aivoicetranslator.model.ModelHistory;
import java.util.ArrayList;
import java.util.Locale;

public class TranslationFragment extends Fragment implements TextToSpeech.OnInitListener {
    public static RecyclerView recyclerView;
    FragmentTranslationBinding binding;
    ArrayList<ModelHistory> list = new ArrayList<>();
    MySp mySp;
    TextToSpeech tts;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.binding = FragmentTranslationBinding.inflate(getLayoutInflater());
        MySp mySp2 = new MySp(getContext());
        this.mySp = mySp2;
        this.list.addAll(mySp2.getHistory());
        this.tts = new TextToSpeech(getContext(), this);
        recyclerView = this.binding.recyclerView;
        this.binding.recyclerView.setAdapter(new AdapterTransalation(this.list, new AdapterTransalation.setOnclickListner() {
            @Override
            public void onFav(int i, boolean z) {
                ModelHistory modelHistory = TranslationFragment.this.list.get(i);
                modelHistory.isFav = z;
                TranslationFragment.this.list.remove(i);
                TranslationFragment.this.list.add(i, modelHistory);
                TranslationFragment.this.mySp.setHistory(TranslationFragment.this.list);
                TranslationFragment.this.binding.recyclerView.getAdapter().notifyDataSetChanged();
            }

            @Override
            public void onSpeak(int i) {
                TranslationFragment translationFragment = TranslationFragment.this;
                translationFragment.speakOut(translationFragment.list.get(i).textSecond);
            }

            @Override
            public void onDelete(int i) {
                TranslationFragment.this.list.remove(i);
                TranslationFragment.this.mySp.setHistory(TranslationFragment.this.list);
                TranslationFragment.this.binding.recyclerView.getAdapter().notifyDataSetChanged();
                TranslationFragment.this.setList();
            }
        }));
        this.binding.recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), 1, false));
        setList();
        return this.binding.getRoot();
    }

    
    public void setList() {
        if (this.list.isEmpty()) {
            this.binding.imgNoData.setVisibility(0);
            this.binding.textNoData.setVisibility(0);
            return;
        }
        this.binding.imgNoData.setVisibility(8);
        this.binding.textNoData.setVisibility(8);
    }

    public void delete() {
        this.list.clear();
    }

    
    public void speakOut(String str) {
        this.tts.speak(str, 0, (Bundle) null, (String) null);
    }

    @Override
    public void onInit(int i) {
        if (i == 0) {
            int language = this.tts.setLanguage(Locale.US);
            if (language == -1 || language == -2) {
                Log.e("TTS", "This Language is not supported");
                return;
            }
            return;
        }
        Log.e("TTS", "Initilization Failed!");
    }

}
