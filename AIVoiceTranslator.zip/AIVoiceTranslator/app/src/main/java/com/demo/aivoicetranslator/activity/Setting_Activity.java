package com.demo.aivoicetranslator.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.demo.aivoicetranslator.ads.MyApplication;
import com.demo.aivoicetranslator.databinding.ActivitySettingBinding;

public class Setting_Activity extends BaseActivity {
    ActivitySettingBinding binding;
    
    public long mLastClickTime = 0;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivitySettingBinding inflate = ActivitySettingBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());
        //getWindow().setFlags(1024, 1024);

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        this.binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Setting_Activity.this.onBackPressed();
            }
        });
        HelperResizer.getheightandwidth(this);
        HelperResizer.setSize(this.binding.constraintTopbar, 1080, 169, true);
        HelperResizer.setSize(this.binding.imgBack, 53, 53, true);
        HelperResizer.setSize(this.binding.lang, 1000, 148, true);
        HelperResizer.setSize(this.binding.rate, 1000, 148, true);
        HelperResizer.setSize(this.binding.share, 1000, 148, true);
        HelperResizer.setSize(this.binding.Privacy, 1000, 148, true);
        HelperResizer.setSize(this.binding.langIcon, 69, 69, true);
        HelperResizer.setSize(this.binding.rateIcon, 69, 69, true);
        HelperResizer.setSize(this.binding.shareIcon, 69, 69, true);
        HelperResizer.setSize(this.binding.PrivacyIcon, 69, 69, true);
        this.binding.lang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        this.binding.rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SystemClock.elapsedRealtime() - Setting_Activity.this.mLastClickTime >= 1000) {
                    long unused = Setting_Activity.this.mLastClickTime = SystemClock.elapsedRealtime();
                    Setting_Activity.this.binding.rate.setAlpha(0.5f);
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Setting_Activity.this.binding.rate.setAlpha(1.0f);
                        }
                    }, 100);
                    Setting_Activity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + Setting_Activity.this.getPackageName())));
                }
            }
        });
        this.binding.share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SystemClock.elapsedRealtime() - Setting_Activity.this.mLastClickTime >= 1000) {
                    long unused = Setting_Activity.this.mLastClickTime = SystemClock.elapsedRealtime();
                    Setting_Activity.this.binding.share.setAlpha(0.5f);
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Setting_Activity.this.binding.share.setAlpha(1.0f);
                        }
                    }, 100);
                    Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType("text/plain");
                    intent.putExtra("android.intent.extra.TEXT", "https://play.google.com/store/apps/details?id=" + Setting_Activity.this.getPackageName());
                    Setting_Activity.this.startActivity(Intent.createChooser(intent, "Share via"));
                }
            }
        });
        this.binding.Privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentPrivacy = new Intent(Intent.ACTION_VIEW, Uri.parse(MyApplication.PrivacyPolicy));
                intentPrivacy.setPackage("com.android.chrome");
                startActivity(intentPrivacy);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}
