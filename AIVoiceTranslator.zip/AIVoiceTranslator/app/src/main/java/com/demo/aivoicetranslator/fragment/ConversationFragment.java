package com.demo.aivoicetranslator.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.demo.aivoicetranslator.activity.ConversationActivity;
import com.demo.aivoicetranslator.adapter.AdapterHistoryConvation;
import com.demo.aivoicetranslator.databinding.FragmentConversationBinding;
import com.demo.aivoicetranslator.extra.MySp;
import com.demo.aivoicetranslator.model.ModelVoiceConvesation;
import java.util.ArrayList;
import java.util.Iterator;

public class ConversationFragment extends Fragment {
    public static RecyclerView recyclerView;
    FragmentConversationBinding binding;
    ArrayList<ModelVoiceConvesation> list = new ArrayList<>();
    MySp mySp;

    @Override
    public void onResume() {
        super.onResume();
        this.list.clear();
        Iterator<ModelVoiceConvesation> it = this.mySp.getConv().iterator();
        while (it.hasNext()) {
            ModelVoiceConvesation next = it.next();
            Log.d("TAG", "onCreateView: " + next.id);
            if (this.list.isEmpty()) {
                this.list.add(next);
            } else if (!isId(next.id)) {
                this.list.add(next);
            }
        }
        this.binding.recyclerView.getAdapter().notifyDataSetChanged();
        if (this.list.isEmpty()) {
            this.binding.imgNoData.setVisibility(0);
            this.binding.textNoData.setVisibility(0);
            return;
        }
        this.binding.imgNoData.setVisibility(8);
        this.binding.textNoData.setVisibility(8);
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.binding = FragmentConversationBinding.inflate(getLayoutInflater());
        this.mySp = new MySp(getContext());
        recyclerView = this.binding.recyclerView;
        this.binding.recyclerView.setAdapter(new AdapterHistoryConvation(this.list, new AdapterHistoryConvation.setOnClickLitsner() {
            @Override
            public void onItemClick(int i) {
                ConversationFragment.this.startActivity(new Intent(ConversationFragment.this.getContext(), ConversationActivity.class).putExtra("id", ConversationFragment.this.list.get(i).id));
            }
        }));
        this.binding.recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), 1, false));
        return this.binding.getRoot();
    }

    private boolean isId(int i) {
        Iterator<ModelVoiceConvesation> it = this.list.iterator();
        while (it.hasNext()) {
            if (it.next().id == i) {
                return true;
            }
        }
        return false;
    }

    public void delete() {
        this.list.clear();
    }
}
