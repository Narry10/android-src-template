package com.demo.aivoicetranslator.activity;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.adapter.AdapterLanguage;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.demo.aivoicetranslator.databinding.ActivityLanguageChoseBinding;
import com.demo.aivoicetranslator.extra.MySp;
import com.demo.aivoicetranslator.model.ModelLanguage;
import com.mannan.translateapi.Language;
import java.util.ArrayList;
import java.util.Iterator;

public class LanguageChoseActivity extends BaseActivity {
    
    public static int pos11;
    String TAG = "SUNY";
    ActivityLanguageChoseBinding binding;
    Context context;
    ArrayList<ModelLanguage> firstList = new ArrayList<>();
    ArrayList<ModelLanguage> list = new ArrayList<>();
    MySp mySp;
    ArrayList<ModelLanguage> secondList = new ArrayList<>();

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityLanguageChoseBinding inflate = ActivityLanguageChoseBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        this.context = this;
        this.mySp = new MySp(this.context);
        this.binding.textFirstLan.setText(getText(R.string.text_from) + this.mySp.getFirstLan());
        this.binding.textSecondLan.setText(getText(R.string.text_to) + this.mySp.getSecondLan());
        this.binding.langDoneImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (LanguageChoseActivity.this.binding.textFirstLan.isSelected()) {
                    LanguageChoseActivity.this.mySp.setFirstLan(LanguageChoseActivity.this.list.get(LanguageChoseActivity.pos11).name);
                    LanguageChoseActivity.this.mySp.setFirstLanCode(LanguageChoseActivity.this.list.get(LanguageChoseActivity.pos11).code);
                    LanguageChoseActivity.this.mySp.setFirstImgLan(LanguageChoseActivity.this.list.get(LanguageChoseActivity.pos11).image);
                    LanguageChoseActivity.this.mySp.setFirstPos(LanguageChoseActivity.pos11);
                    LanguageChoseActivity.this.binding.textFirstLan.setText(LanguageChoseActivity.this.getString(R.string.text_from) + LanguageChoseActivity.this.list.get(LanguageChoseActivity.pos11).name);
                    LanguageChoseActivity.this.onBackPressed();
                    return;
                }
                LanguageChoseActivity.this.mySp.setSecondLan(LanguageChoseActivity.this.list.get(LanguageChoseActivity.pos11).name);
                LanguageChoseActivity.this.mySp.setSecondLanCode(LanguageChoseActivity.this.list.get(LanguageChoseActivity.pos11).code);
                LanguageChoseActivity.this.mySp.setSecondImgLan(LanguageChoseActivity.this.list.get(LanguageChoseActivity.pos11).image);
                LanguageChoseActivity.this.mySp.setSecondPos(LanguageChoseActivity.pos11);
                LanguageChoseActivity.this.binding.textSecondLan.setText(LanguageChoseActivity.this.getString(R.string.text_to) + LanguageChoseActivity.this.list.get(LanguageChoseActivity.pos11).name);
                LanguageChoseActivity.this.onBackPressed();
            }
        });
        boolean booleanExtra = getIntent().getBooleanExtra("select", false);
        addList();
        setLang(booleanExtra);
        this.binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LanguageChoseActivity.this.onBackPressed();
            }
        });
        this.binding.textFirstLan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LanguageChoseActivity.this.setLang(false);
                LanguageChoseActivity.this.binding.recyclerView.getAdapter().notifyDataSetChanged();
            }
        });
        this.binding.textSecondLan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LanguageChoseActivity.this.setLang(true);
                LanguageChoseActivity.this.binding.recyclerView.getAdapter().notifyDataSetChanged();
            }
        });
        this.binding.recyclerView.setAdapter(new AdapterLanguage(this.list, new AdapterLanguage.setOnClickListner() {
            @Override
            public void onClick(int i) {
                int unused = LanguageChoseActivity.pos11 = i;
            }
        }));
        this.binding.recyclerView.setLayoutManager(new LinearLayoutManager(this.context, 1, false));
        this.binding.imgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LanguageChoseActivity.this.binding.edtSerch.setText("");
            }
        });
        this.binding.edtSerch.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                LanguageChoseActivity.this.list.clear();
                if (LanguageChoseActivity.this.binding.textSecondLan.isSelected()) {
                    LanguageChoseActivity languageChoseActivity = LanguageChoseActivity.this;
                    ArrayList access$200 = languageChoseActivity.filterList(languageChoseActivity.secondList, charSequence);
                    if (access$200.isEmpty()) {
                        LanguageChoseActivity.this.list.addAll(LanguageChoseActivity.this.secondList);
                    } else {
                        LanguageChoseActivity.this.list.addAll(access$200);
                    }
                } else {
                    LanguageChoseActivity languageChoseActivity2 = LanguageChoseActivity.this;
                    ArrayList access$2002 = languageChoseActivity2.filterList(languageChoseActivity2.firstList, charSequence);
                    if (access$2002.isEmpty()) {
                        LanguageChoseActivity.this.list.addAll(LanguageChoseActivity.this.firstList);
                    } else {
                        LanguageChoseActivity.this.list.addAll(access$2002);
                    }
                }
                LanguageChoseActivity.this.binding.recyclerView.getAdapter().notifyDataSetChanged();
            }
        });
    }

    
    public ArrayList<ModelLanguage> filterList(ArrayList<ModelLanguage> arrayList, CharSequence charSequence) {
        ArrayList<ModelLanguage> arrayList2 = new ArrayList<>();
        arrayList2.clear();
        Iterator<ModelLanguage> it = arrayList.iterator();
        while (it.hasNext()) {
            ModelLanguage next = it.next();
            if (next.name.toLowerCase().contains(charSequence.toString().toLowerCase())) {
                arrayList2.add(next);
            }
        }
        return arrayList2;
    }

    private void addList() {
        this.firstList.clear();
        this.firstList.add(new ModelLanguage("Afrikaans", Language.AFRIKAANS, R.drawable.afrikaans, false));
        this.firstList.add(new ModelLanguage("Amharic", "am", R.drawable.amharic, false));
        this.firstList.add(new ModelLanguage("Arabic", Language.ARABIC, R.drawable.arabic, false));
        this.firstList.add(new ModelLanguage("Armenian", Language.ARMENIAN, R.drawable.armemian, false));
        this.firstList.add(new ModelLanguage("Azerbaycan", Language.AZERBAIJANI, R.drawable.azerbaijan, false));
        this.firstList.add(new ModelLanguage("Basque", Language.BASQUE, R.drawable.basque, false));
        this.firstList.add(new ModelLanguage("Bengali", Language.BENGALI, R.drawable.bengali, false));
        this.firstList.add(new ModelLanguage("Bulgarian", Language.BULGARIAN, R.drawable.bulgarian, false));
        this.firstList.add(new ModelLanguage("Burmese", "my", R.drawable.myanmar, false));
        this.firstList.add(new ModelLanguage("Catalan", Language.CATALAN, R.drawable.catalan, false));
        this.firstList.add(new ModelLanguage("Czech", Language.CZECH, R.drawable.czech, false));
        this.firstList.add(new ModelLanguage("Cantonese", "yue", R.drawable.cantonese, false));
        this.firstList.add(new ModelLanguage("Chinese", "zh", R.drawable.chinese, false));
        this.firstList.add(new ModelLanguage("Danish", Language.DANISH, R.drawable.danish, false));
        this.firstList.add(new ModelLanguage("Dutch", Language.DUTCH, R.drawable.dutch, false));
        this.firstList.add(new ModelLanguage("English", Language.ENGLISH, R.drawable.english, false));
        this.firstList.add(new ModelLanguage("Filipino", "fil", R.drawable.filipino, false));
        this.firstList.add(new ModelLanguage("French", Language.FRENCH, R.drawable.french, false));
        this.firstList.add(new ModelLanguage("Finnish", Language.FINNISH, R.drawable.finnish, false));
        this.firstList.add(new ModelLanguage("Galician", Language.GALICIAN, R.drawable.spanish, false));
        this.firstList.add(new ModelLanguage("Gujarati", Language.GUJARATI, R.drawable.hindi, false));
        this.firstList.add(new ModelLanguage("German", Language.GERMAN, R.drawable.german, false));
        this.firstList.add(new ModelLanguage("Greek", Language.GREEK, R.drawable.greek, false));
        this.firstList.add(new ModelLanguage("Hebrew", "he", R.drawable.hebrew, false));
        this.firstList.add(new ModelLanguage("Hindi", Language.HINDI, R.drawable.hindi, false));
        this.firstList.add(new ModelLanguage("Hungarian", Language.HUNGARIAN, R.drawable.hungarian, false));
        this.firstList.add(new ModelLanguage("Indonesian", "id", R.drawable.indonesian, false));
        this.firstList.add(new ModelLanguage("Icelandic", Language.ICELANDIC, R.drawable.icelandic, false));
        this.firstList.add(new ModelLanguage("Italian", Language.ITALIAN, R.drawable.italian, false));
        this.firstList.add(new ModelLanguage("Javanese", "jv", R.drawable.javanese, false));
        this.firstList.add(new ModelLanguage("Japanese", Language.JAPANESE, R.drawable.japanese, false));
        this.firstList.add(new ModelLanguage("Kannada", Language.KANNADA, R.drawable.hindi, false));
        this.firstList.add(new ModelLanguage("Khmer", "km", R.drawable.khmer, false));
        this.firstList.add(new ModelLanguage("Korean", Language.KOREAN, R.drawable.korean, false));
        this.firstList.add(new ModelLanguage("Latvian", Language.LATVIAN, R.drawable.latvian, false));
        this.firstList.add(new ModelLanguage("Lao", "lo", R.drawable.lao, false));
        this.firstList.add(new ModelLanguage("Lithuanian", Language.LITHUANIAN, R.drawable.lithuanian, false));
        this.firstList.add(new ModelLanguage("Macedonian", Language.MACEDONIAN, R.drawable.macedonian, false));
        this.firstList.add(new ModelLanguage("Malay", Language.MALAY, R.drawable.malay, false));
        this.firstList.add(new ModelLanguage("Malayalam", "ml", R.drawable.hindi, false));
        this.firstList.add(new ModelLanguage("Maltese", Language.MALTESE, R.drawable.maltese, false));
        this.firstList.add(new ModelLanguage("Marathi", "mr", R.drawable.hindi, false));
        this.firstList.add(new ModelLanguage("Nepali", "ne", R.drawable.nepali, false));
        this.firstList.add(new ModelLanguage("Norwegian", Language.NORWEGIAN, R.drawable.norwegian, false));
        this.firstList.add(new ModelLanguage("Oriya", "or", R.drawable.hindi, false));
        this.firstList.add(new ModelLanguage("Persian", "fl", R.drawable.persian, false));
        this.firstList.add(new ModelLanguage("Polish", Language.POLISH, R.drawable.polish, false));
        this.firstList.add(new ModelLanguage("Portuguese", Language.PORTUGUESE, R.drawable.prtuguese, false));
        this.firstList.add(new ModelLanguage("Punjabi", "pa", R.drawable.hindi, false));
        this.firstList.add(new ModelLanguage("Romanian", Language.ROMANIAN, R.drawable.romanian, false));
        this.firstList.add(new ModelLanguage("Russion", Language.RUSSIAN, R.drawable.russion, false));
        this.firstList.add(new ModelLanguage("Shihala", "si", R.drawable.shihala, false));
        this.firstList.add(new ModelLanguage("Slovak", Language.SLOVAK, R.drawable.slovak, false));
        this.firstList.add(new ModelLanguage("Slovenian", Language.SLOVENIAN, R.drawable.slovenian, false));
        this.firstList.add(new ModelLanguage("Spanish", Language.SPANISH, R.drawable.spanish, false));
        this.firstList.add(new ModelLanguage("Sundanese", "su", R.drawable.sundanese, false));
        this.firstList.add(new ModelLanguage("Swahili", Language.SWAHILI, R.drawable.swahili, false));
        this.firstList.add(new ModelLanguage("Swedish", Language.SWEDISH, R.drawable.swedish, false));
        this.firstList.add(new ModelLanguage("Serbian", Language.SERBIAN, R.drawable.serbian, false));
        this.firstList.add(new ModelLanguage("Tamil", Language.TAMIL, R.drawable.hindi, false));
        this.firstList.add(new ModelLanguage("Telugu", Language.TELUGU, R.drawable.hindi, false));
        this.firstList.add(new ModelLanguage("Thai", Language.THAI, R.drawable.thai, false));
        this.firstList.add(new ModelLanguage("Turkish", Language.TURKISH, R.drawable.turkish, false));
        this.firstList.add(new ModelLanguage("Urdu", Language.URDU, R.drawable.urdu, false));
        this.firstList.add(new ModelLanguage("Ukrainian", Language.UKRAINIAN, R.drawable.ukrainian, false));
        this.firstList.add(new ModelLanguage("Vietnamese", Language.VIETNAMESE, R.drawable.vietnamese, false));
        this.firstList.add(new ModelLanguage("Zulu", "zu", R.drawable.zulu, false));


        this.secondList.clear();
        this.secondList.add(new ModelLanguage("Afrikaans", Language.AFRIKAANS, R.drawable.afrikaans, false));
        this.secondList.add(new ModelLanguage("Amharic", "am", R.drawable.amharic, false));
        this.secondList.add(new ModelLanguage("Arabic", Language.ARABIC, R.drawable.arabic, false));
        this.secondList.add(new ModelLanguage("Armenian", Language.ARMENIAN, R.drawable.armemian, false));
        this.secondList.add(new ModelLanguage("Azerbaycan", Language.AZERBAIJANI, R.drawable.azerbaijan, false));
        this.secondList.add(new ModelLanguage("Basque", Language.BASQUE, R.drawable.basque, false));
        this.secondList.add(new ModelLanguage("Bengali", Language.BENGALI, R.drawable.bengali, false));
        this.secondList.add(new ModelLanguage("Bulgarian", Language.BULGARIAN, R.drawable.bulgarian, false));
        this.secondList.add(new ModelLanguage("Burmese", "my", R.drawable.myanmar, false));
        this.secondList.add(new ModelLanguage("Catalan", Language.CATALAN, R.drawable.catalan, false));
        this.secondList.add(new ModelLanguage("Czech", Language.CZECH, R.drawable.czech, false));
        this.secondList.add(new ModelLanguage("Cantonese", "yue", R.drawable.cantonese, false));
        this.secondList.add(new ModelLanguage("Chinese", "zh", R.drawable.chinese, false));
        this.secondList.add(new ModelLanguage("Danish", Language.DANISH, R.drawable.danish, false));
        this.secondList.add(new ModelLanguage("Dutch", Language.DUTCH, R.drawable.dutch, false));
        this.secondList.add(new ModelLanguage("English", Language.ENGLISH, R.drawable.english, false));
        this.secondList.add(new ModelLanguage("Filipino", "fil", R.drawable.filipino, false));
        this.secondList.add(new ModelLanguage("French", Language.FRENCH, R.drawable.french, false));
        this.secondList.add(new ModelLanguage("Finnish", Language.FINNISH, R.drawable.finnish, false));
        this.secondList.add(new ModelLanguage("Galician", Language.GALICIAN, R.drawable.spanish, false));
        this.secondList.add(new ModelLanguage("Gujarati", Language.GUJARATI, R.drawable.hindi, false));
        this.secondList.add(new ModelLanguage("German", Language.GERMAN, R.drawable.german, false));
        this.secondList.add(new ModelLanguage("Greek", Language.GREEK, R.drawable.greek, false));
        this.secondList.add(new ModelLanguage("Hebrew", "he", R.drawable.hebrew, false));
        this.secondList.add(new ModelLanguage("Hindi", Language.HINDI, R.drawable.hindi, false));
        this.secondList.add(new ModelLanguage("Hungarian", Language.HUNGARIAN, R.drawable.hungarian, false));
        this.secondList.add(new ModelLanguage("Indonesian", "id", R.drawable.indonesian, false));
        this.secondList.add(new ModelLanguage("Icelandic", Language.ICELANDIC, R.drawable.icelandic, false));
        this.secondList.add(new ModelLanguage("Italian", Language.ITALIAN, R.drawable.italian, false));
        this.secondList.add(new ModelLanguage("Javanese", "jv", R.drawable.javanese, false));
        this.secondList.add(new ModelLanguage("Japanese", Language.JAPANESE, R.drawable.japanese, false));
        this.secondList.add(new ModelLanguage("Kannada", Language.KANNADA, R.drawable.hindi, false));
        this.secondList.add(new ModelLanguage("Khmer", "km", R.drawable.khmer, false));
        this.secondList.add(new ModelLanguage("Korean", Language.KOREAN, R.drawable.korean, false));
        this.secondList.add(new ModelLanguage("Latvian", Language.LATVIAN, R.drawable.latvian, false));
        this.secondList.add(new ModelLanguage("Lao", "lo", R.drawable.lao, false));
        this.secondList.add(new ModelLanguage("Lithuanian", Language.LITHUANIAN, R.drawable.lithuanian, false));
        this.secondList.add(new ModelLanguage("Macedonian", Language.MACEDONIAN, R.drawable.macedonian, false));
        this.secondList.add(new ModelLanguage("Malay", Language.MALAY, R.drawable.malay, false));
        this.secondList.add(new ModelLanguage("Malayalam", "ml", R.drawable.hindi, false));
        this.secondList.add(new ModelLanguage("Maltese", Language.MALTESE, R.drawable.maltese, false));
        this.secondList.add(new ModelLanguage("Marathi", "mr", R.drawable.hindi, false));
        this.secondList.add(new ModelLanguage("Nepali", "ne", R.drawable.nepali, false));
        this.secondList.add(new ModelLanguage("Norwegian", Language.NORWEGIAN, R.drawable.norwegian, false));
        this.secondList.add(new ModelLanguage("Oriya", "or", R.drawable.hindi, false));
        this.secondList.add(new ModelLanguage("Persian", "fl", R.drawable.persian, false));
        this.secondList.add(new ModelLanguage("Polish", Language.POLISH, R.drawable.polish, false));
        this.secondList.add(new ModelLanguage("Portuguese", Language.PORTUGUESE, R.drawable.prtuguese, false));
        this.secondList.add(new ModelLanguage("Punjabi", "pa", R.drawable.hindi, false));
        this.secondList.add(new ModelLanguage("Romanian", Language.ROMANIAN, R.drawable.romanian, false));
        this.secondList.add(new ModelLanguage("Russion", Language.RUSSIAN, R.drawable.russion, false));
        this.secondList.add(new ModelLanguage("Shihala", "si", R.drawable.shihala, false));
        this.secondList.add(new ModelLanguage("Slovak", Language.SLOVAK, R.drawable.slovak, false));
        this.secondList.add(new ModelLanguage("Slovenian", Language.SLOVENIAN, R.drawable.slovenian, false));
        this.secondList.add(new ModelLanguage("Spanish", Language.SPANISH, R.drawable.spanish, false));
        this.secondList.add(new ModelLanguage("Sundanese", "su", R.drawable.sundanese, false));
        this.secondList.add(new ModelLanguage("Swahili", Language.SWAHILI, R.drawable.swahili, false));
        this.secondList.add(new ModelLanguage("Swedish", Language.SWEDISH, R.drawable.swedish, false));
        this.secondList.add(new ModelLanguage("Serbian", Language.SERBIAN, R.drawable.serbian, false));
        this.secondList.add(new ModelLanguage("Tamil", Language.TAMIL, R.drawable.hindi, false));
        this.secondList.add(new ModelLanguage("Telugu", Language.TELUGU, R.drawable.hindi, false));
        this.secondList.add(new ModelLanguage("Thai", Language.THAI, R.drawable.thai, false));
        this.secondList.add(new ModelLanguage("Turkish", Language.TURKISH, R.drawable.turkish, false));
        this.secondList.add(new ModelLanguage("Urdu", Language.URDU, R.drawable.urdu, false));
        this.secondList.add(new ModelLanguage("Ukrainian", Language.UKRAINIAN, R.drawable.ukrainian, false));
        this.secondList.add(new ModelLanguage("Vietnamese", Language.VIETNAMESE, R.drawable.vietnamese, false));
        this.secondList.add(new ModelLanguage("Zulu", "zu", R.drawable.zulu, false));
        ModelLanguage modelLanguage = this.firstList.get(0);
        ModelLanguage modelLanguage2 = this.secondList.get(0);
        Iterator<ModelLanguage> it = this.firstList.iterator();
        while (it.hasNext()) {
            ModelLanguage next = it.next();
            if (next.code.equals(this.mySp.getFirstLanCode())) {
                modelLanguage = next;
            }
        }
        Iterator<ModelLanguage> it2 = this.secondList.iterator();
        while (it2.hasNext()) {
            ModelLanguage next2 = it2.next();
            if (next2.code.equals(this.mySp.getSecondLanCode())) {
                modelLanguage2 = next2;
            }
        }
        int indexOf = this.firstList.indexOf(modelLanguage);
        int indexOf2 = this.secondList.indexOf(modelLanguage2);
        Log.d(this.TAG, "addList: " + indexOf);
        Log.d(this.TAG, "addList: " + indexOf2);
        modelLanguage.isSelect = true;
        modelLanguage2.isSelect = true;
        this.firstList.remove(indexOf);
        this.secondList.remove(indexOf2);
        this.firstList.add(indexOf, modelLanguage);
        this.secondList.add(indexOf2, modelLanguage2);
    }

    
    public void setLang(boolean z) {
        if (!z) {
            this.binding.textFirstLan.setSelected(true);
            this.binding.textSecondLan.setSelected(false);
            this.list.clear();
            this.list.addAll(this.firstList);
            return;
        }
        this.binding.textFirstLan.setSelected(false);
        this.binding.textSecondLan.setSelected(true);
        this.list.clear();
        this.list.addAll(this.secondList);
    }

}
