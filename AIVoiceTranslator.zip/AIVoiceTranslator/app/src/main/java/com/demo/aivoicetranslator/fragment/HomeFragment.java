package com.demo.aivoicetranslator.fragment;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.bumptech.glide.load.Key;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.activity.PhrasesActivity;
import com.demo.aivoicetranslator.adapter.AdapterPhrases;
import com.demo.aivoicetranslator.databinding.FragmentHomeBinding;
import com.demo.aivoicetranslator.model.Phrases;
import com.demo.aivoicetranslator.model.Sections;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

public class HomeFragment extends Fragment implements TextToSpeech.OnInitListener {
    FragmentHomeBinding binding;
    long lastClickTime = 0;
    ArrayList<Phrases> mList = new ArrayList<>();
    int pos;
    public TextToSpeech tts;

    public HomeFragment(int i) {
        this.pos = i;
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.binding = FragmentHomeBinding.inflate(getLayoutInflater());
        this.tts = new TextToSpeech(getContext(), this);
        setViewPage(getContext());
        this.binding.layout.recyclerViewPhrases.setAdapter(new AdapterPhrases(this.mList, new AdapterPhrases.setOnClickListner() {
            @Override
            public void onCopy(String str) {
                ((ClipboardManager) HomeFragment.this.getContext().getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText(HomeFragment.this.getString(R.string.app_name), str));
                Toast.makeText(HomeFragment.this.getContext(), "Copied to Clipboard", 0).show();
            }

            @Override
            public void onShare(String str) {
                if (SystemClock.elapsedRealtime() - HomeFragment.this.lastClickTime >= 1000) {
                    HomeFragment.this.lastClickTime = SystemClock.elapsedRealtime();
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", str);
                    intent.setType("text/plain");
                    HomeFragment.this.getContext().startActivity(intent);
                }
            }

            @Override
            public void onSpeak(String str) {
                HomeFragment.this.speakOut(str);
            }
        }));
        this.binding.layout.recyclerViewPhrases.setLayoutManager(new LinearLayoutManager(getContext(), 1, false));
        return this.binding.getRoot();
    }

    public void setViewPage(Context context) {
        try {
            String isToString = isToString(context.getAssets().open("phrases.json"));
            Sections sections = PhrasesActivity.mList.get(this.pos);
            this.mList.clear();
            Iterator it = ((ArrayList) new Gson().fromJson(isToString, new TypeToken<ArrayList<Phrases>>() {
            }.getType())).iterator();
            while (it.hasNext()) {
                Phrases phrases = (Phrases) it.next();
                if (phrases.section_id == sections.section_id) {
                    this.mList.add(phrases);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public String isToString(InputStream inputStream) {
        char[] cArr = new char[1024];
        StringBuilder sb = new StringBuilder();
        try {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Key.STRING_CHARSET_NAME);
            while (true) {
                try {
                    int read = inputStreamReader.read(cArr, 0, 1024);
                    if (read < 0) {
                        return sb.toString();
                    }
                    sb.append(cArr, 0, read);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (UnsupportedEncodingException e2) {
            throw new RuntimeException(e2);
        }
    }

    public void speakOut(String str) {
        this.tts.speak(str, 0, (Bundle) null, (String) null);
    }

    @Override
    public void onInit(int i) {
        if (i == 0) {
            int language = this.tts.setLanguage(Locale.US);
            if (language == -1 || language == -2) {
                Log.e("TTS", "This Language is not supported");
                return;
            }
            return;
        }
        Log.e("TTS", "Initilization Failed!");
    }
}
