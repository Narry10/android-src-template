package com.demo.aivoicetranslator.model;

public class ModelHistory {
    public int id;
    public int imgFirst;
    public int imgSecond;
    public boolean isFav;
    public String textFirst;
    public String textSecond;

    public ModelHistory(int i, int i2, int i3, String str, String str2, boolean z) {
        this.id = i;
        this.imgFirst = i2;
        this.imgSecond = i3;
        this.textFirst = str;
        this.textSecond = str2;
        this.isFav = z;
    }
}
