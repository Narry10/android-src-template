package com.demo.aivoicetranslator.activity;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.adapter.AdapterFavourite;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.demo.aivoicetranslator.databinding.ActivityFavouriteBinding;
import com.demo.aivoicetranslator.extra.MySp;
import com.demo.aivoicetranslator.model.ModelHistory;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

public class FavouriteActivity extends BaseActivity implements TextToSpeech.OnInitListener {
    ActivityFavouriteBinding binding;
    Context context;
    ArrayList<ModelHistory> list = new ArrayList<>();
    MySp mySp;
    TextToSpeech tts;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityFavouriteBinding inflate = ActivityFavouriteBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        this.context = this;
        this.mySp = new MySp(this.context);
        this.tts = new TextToSpeech(this.context, this);
        this.binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FavouriteActivity.this.onBackPressed();
            }
        });
        this.binding.recyclerView.setAdapter(new AdapterFavourite(this.list, new AdapterFavourite.setOnClickListner() {
            @Override
            public void onSpeak(int i) {
                FavouriteActivity favouriteActivity = FavouriteActivity.this;
                favouriteActivity.speakOut(favouriteActivity.list.get(i).textSecond);
            }

            @Override
            public void onFav(int i) {
                ModelHistory modelHistory = FavouriteActivity.this.list.get(i);
                ArrayList<ModelHistory> history = FavouriteActivity.this.mySp.getHistory();
                ModelHistory modelHistory2 = history.get(0);
                Iterator<ModelHistory> it = history.iterator();
                int i2 = -1;
                while (it.hasNext()) {
                    ModelHistory next = it.next();
                    if (next.id == modelHistory.id) {
                        int indexOf = history.indexOf(next);
                        Log.d("TAG", "onFav: " + indexOf);
                        next.isFav = false;
                        i2 = indexOf;
                        modelHistory2 = next;
                    }
                }
                history.remove(i2);
                history.add(i2, modelHistory2);
                FavouriteActivity.this.mySp.setHistory(history);
                FavouriteActivity.this.addList();
            }
        }));
        this.binding.recyclerView.setLayoutManager(new LinearLayoutManager(this.context, 1, false));
        addList();
    }

    
    public void addList() {
        this.list.clear();
        Iterator<ModelHistory> it = this.mySp.getHistory().iterator();
        while (it.hasNext()) {
            ModelHistory next = it.next();
            if (next.isFav) {
                this.list.add(next);
            }
        }
        this.binding.recyclerView.getAdapter().notifyDataSetChanged();
        if (this.list.isEmpty()) {
            this.binding.imgNoData.setVisibility(0);
            this.binding.textNoData.setVisibility(0);
            return;
        }
        this.binding.imgNoData.setVisibility(8);
        this.binding.textNoData.setVisibility(8);
    }

    
    public void speakOut(String str) {
        this.tts.speak(str, 0, (Bundle) null, (String) null);
    }

    @Override
    public void onInit(int i) {
        if (i == 0) {
            int language = this.tts.setLanguage(Locale.US);
            if (language == -1 || language == -2) {
                Log.e("TTS", "This Language is not supported");
                return;
            }
            return;
        }
        Log.e("TTS", "Initilization Failed!");
    }
}
