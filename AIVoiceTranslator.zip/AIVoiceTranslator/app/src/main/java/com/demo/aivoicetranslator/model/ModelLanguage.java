package com.demo.aivoicetranslator.model;

public class ModelLanguage {
    public String code;
    public int image;
    public boolean isSelect;
    public String name;

    public ModelLanguage(String str, String str2, int i, boolean z) {
        this.name = str;
        this.code = str2;
        this.image = i;
        this.isSelect = z;
    }
}
