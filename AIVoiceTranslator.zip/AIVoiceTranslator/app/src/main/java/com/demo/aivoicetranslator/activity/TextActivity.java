package com.demo.aivoicetranslator.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.constraintlayout.helper.widget.MotionEffect;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.demo.aivoicetranslator.databinding.ActivityTextBinding;
import com.demo.aivoicetranslator.extra.MySp;
import com.demo.aivoicetranslator.model.ModelHistory;
import com.mannan.translateapi.TranslateAPI;
import java.util.ArrayList;
import java.util.Locale;

public class TextActivity extends BaseActivity implements TextToSpeech.OnInitListener {
    int REQUEST_CODE_SPEECH_INPUT = 102;
    ActivityTextBinding binding;
    Context context;
    ArrayList<ModelHistory> mListHist = new ArrayList<>();
    MySp mySp;
    TextToSpeech tts;

    @Override
    public void onResume() {
        super.onResume();
        this.binding.textFirstLan.setText(this.mySp.getFirstLan());
        this.binding.textSecondLan.setText(this.mySp.getSecondLan());
        if (this.mySp.getFirstImgLan() == 0) {
            this.mySp.setFirstImgLan(R.drawable.english);
            this.mySp.setSecondImgLan(R.drawable.hindi);
        }
        Glide.with(this.context).load(Integer.valueOf(this.mySp.getFirstImgLan())).into(this.binding.imgFirst);
        Glide.with(this.context).load(Integer.valueOf(this.mySp.getSecondImgLan())).into(this.binding.imgSecond);
    }

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityTextBinding inflate = ActivityTextBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        this.context = this;
        MySp mySp2 = new MySp(this.context);
        this.mySp = mySp2;
        this.mListHist.addAll(mySp2.getHistory());
        this.binding.imgFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextActivity.this.binding.imgFirst.setAlpha(0.5f);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        TextActivity.this.binding.imgFirst.setAlpha(1.0f);
                    }
                }, 100);
                TextActivity.this.startActivity(new Intent(TextActivity.this.context, LanguageChoseActivity.class).putExtra("select", false));
            }
        });
        this.binding.imgSecond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextActivity.this.binding.imgSecond.setAlpha(0.5f);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        TextActivity.this.binding.imgSecond.setAlpha(1.0f);
                    }
                }, 100);
                TextActivity.this.startActivity(new Intent(TextActivity.this.context, LanguageChoseActivity.class).putExtra("select", true));
            }
        });
        HelperResizer.getheightandwidth(this);
        HelperResizer.setSize(this.binding.textTranslate, 359, 123, true);
        this.binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextActivity.this.onBackPressed();
            }
        });
        this.tts = new TextToSpeech(this.context, this);
        this.binding.constraintTextSecond.setVisibility(8);
        if (getIntent().getBooleanExtra("voice", false)) {
            startRecognize();
        }
        String stringExtra = getIntent().getStringExtra("text");
        if (!stringExtra.isEmpty()) {
            this.binding.edtInput.setText(stringExtra);
        }
        this.binding.imgSweep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String obj = TextActivity.this.binding.textFirstLan.getText().toString();
                String obj2 = TextActivity.this.binding.textSecondLan.getText().toString();
                String str = obj + obj2;
                String substring = str.substring(0, str.length() - obj2.length());
                String substring2 = str.substring(substring.length());
                TextActivity.this.binding.textFirstLan.setText(substring2);
                TextActivity.this.binding.textSecondLan.setText(substring);
                TextActivity.this.mySp.setFirstLan(substring2);
                TextActivity.this.mySp.setSecondLan(substring);
                int firstImgLan = TextActivity.this.mySp.getFirstImgLan();
                int secondImgLan = TextActivity.this.mySp.getSecondImgLan();
                String firstLanCode = TextActivity.this.mySp.getFirstLanCode();
                TextActivity.this.mySp.setFirstLanCode(TextActivity.this.mySp.getSecondLanCode());
                TextActivity.this.mySp.setSecondLanCode(firstLanCode);
                TextActivity.this.mySp.setFirstImgLan(secondImgLan);
                TextActivity.this.mySp.setSecondImgLan(firstImgLan);
                Glide.with(TextActivity.this.context).load(Integer.valueOf(TextActivity.this.mySp.getFirstImgLan())).into(TextActivity.this.binding.imgFirst);
                Glide.with(TextActivity.this.context).load(Integer.valueOf(TextActivity.this.mySp.getSecondImgLan())).into(TextActivity.this.binding.imgSecond);
            }
        });
        this.binding.imgVoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextActivity.this.startRecognize();
            }
        });
        this.binding.textFirstLan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextActivity.this.binding.textFirstLan.setAlpha(0.5f);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        TextActivity.this.binding.textFirstLan.setAlpha(1.0f);
                    }
                }, 100);
                TextActivity.this.startActivity(new Intent(TextActivity.this.context, LanguageChoseActivity.class).putExtra("select", false));
            }
        });
        this.binding.textSecondLan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextActivity.this.binding.textSecondLan.setAlpha(0.5f);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        TextActivity.this.binding.textSecondLan.setAlpha(1.0f);
                    }
                }, 100);
                TextActivity.this.startActivity(new Intent(TextActivity.this.context, LanguageChoseActivity.class).putExtra("select", true));
            }
        });
        this.binding.textTranslate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextActivity.this.binding.edtInput.getText().toString().isEmpty()) {
                    Toast.makeText(TextActivity.this.context, TextActivity.this.getString(R.string.please_enter_word), 0).show();
                } else {
                    new TranslateAPI(TextActivity.this.mySp.getFirstLanCode(), TextActivity.this.mySp.getSecondLanCode(), TextActivity.this.binding.edtInput.getText().toString()).setTranslateListener(new TranslateAPI.TranslateListener() {
                        @Override
                        public void onSuccess(String str) {
                            Log.d(MotionEffect.TAG, "onSuccess: " + str);
                            TextActivity.this.binding.edtInputSecond.setText(str);
                            TextActivity.this.binding.constraintTextSecond.setVisibility(0);
                            if (TextActivity.this.mListHist.isEmpty()) {
                                TextActivity.this.mListHist.add(new ModelHistory(1, TextActivity.this.mySp.getFirstImgLan(), TextActivity.this.mySp.getSecondImgLan(), TextActivity.this.binding.edtInput.getText().toString(), str, false));
                            } else {
                                TextActivity.this.mListHist.add(new ModelHistory(TextActivity.this.mListHist.get(TextActivity.this.mListHist.size() - 1).id + 1, TextActivity.this.mySp.getFirstImgLan(), TextActivity.this.mySp.getSecondImgLan(), TextActivity.this.binding.edtInput.getText().toString(), str, false));
                            }
                            TextActivity.this.mySp.setHistory(TextActivity.this.mListHist);
                        }

                        @Override
                        public void onFailure(String str) {
                            Log.d(MotionEffect.TAG, "onFailure: " + str);
                        }
                    });
                }
            }
        });
        this.binding.imgVoiceSecond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextActivity.this.binding.edtInputSecond.getText().toString().isEmpty()) {
                    Toast.makeText(TextActivity.this.context, "Please Text", 0).show();
                    return;
                }
                TextActivity textActivity = TextActivity.this;
                textActivity.speakOut(textActivity.binding.edtInputSecond.getText().toString());
            }
        });
    }

    
    public void speakOut(String str) {
        this.tts.speak(str, 0, (Bundle) null, (String) null);
    }

    public void startRecognize() {
        Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        intent.putExtra("android.speech.extra.LANGUAGE", this.mySp.getFirstLanCode());
        intent.putExtra("android.speech.extra.PROMPT", "Speak to text");
        try {
            startActivityForResult(intent, this.REQUEST_CODE_SPEECH_INPUT);
        } catch (Exception e) {
            Toast.makeText(this.context, " " + e.getMessage(), 0).show();
        }
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == this.REQUEST_CODE_SPEECH_INPUT && i2 == -1 && intent != null) {
            this.binding.edtInput.setText(intent.getStringArrayListExtra("android.speech.extra.RESULTS").get(0));
        }
    }

    @Override
    public void onInit(int i) {
        if (i == 0) {
            int language = this.tts.setLanguage(Locale.US);
            if (language == -1 || language == -2) {
                Log.e("TTS", "This Language is not supported");
                return;
            }
            return;
        }
        Log.e("TTS", "Initilization Failed!");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}
