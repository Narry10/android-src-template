package com.demo.aivoicetranslator.adapter;

import android.content.Context;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import com.demo.aivoicetranslator.fragment.HomeFragment;

public class PageAdapter extends FragmentPagerAdapter {
    private Context myContext;
    int totalTabs;

    public PageAdapter(Context context, FragmentManager fragmentManager, int i, int i2) {
        super(fragmentManager, i);
        this.myContext = context;
        this.totalTabs = i2;
    }

    @Override
    public Fragment getItem(int i) {
        switch (i) {
            case 0:
                return new HomeFragment(i);
            case 1:
                return new HomeFragment(i);
            case 2:
                return new HomeFragment(i);
            case 3:
                return new HomeFragment(i);
            case 4:
                return new HomeFragment(i);
            case 5:
                return new HomeFragment(i);
            case 6:
                return new HomeFragment(i);
            case 7:
                return new HomeFragment(i);
            case 8:
                return new HomeFragment(i);
            case 9:
                return new HomeFragment(i);
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return this.totalTabs;
    }
}
