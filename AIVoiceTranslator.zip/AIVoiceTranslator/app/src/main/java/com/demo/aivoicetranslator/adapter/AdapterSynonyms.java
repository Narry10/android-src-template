package com.demo.aivoicetranslator.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.demo.aivoicetranslator.R;
import java.util.ArrayList;

public class AdapterSynonyms extends RecyclerView.Adapter<AdapterSynonyms.ViewHolder> {
    ArrayList<String> list;

    public AdapterSynonyms(ArrayList<String> arrayList) {
        this.list = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.synonyms_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.textTitle.setText(this.list.get(i));
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textTitle;

        public ViewHolder(View view) {
            super(view);
            this.textTitle = (TextView) view.findViewById(R.id.text_value);
        }
    }
}
