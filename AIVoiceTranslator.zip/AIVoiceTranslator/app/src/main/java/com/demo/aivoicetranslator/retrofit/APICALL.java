package com.demo.aivoicetranslator.retrofit;

import com.demo.aivoicetranslator.model.Dictionary;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Url;

public interface APICALL {
    @GET
    Call<ArrayList<Dictionary>> fetching(@Url String str);
}
