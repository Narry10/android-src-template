package com.demo.aivoicetranslator.activity;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.viewpager.widget.ViewPager;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.adapter.HistoryPageAdapter;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.demo.aivoicetranslator.databinding.ActivityHistoryBinding;
import com.demo.aivoicetranslator.extra.MySp;
import java.util.ArrayList;

public class HistoryActivity extends BaseActivity {
    ActivityHistoryBinding binding;
    Context context;
    MySp mySp;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityHistoryBinding inflate = ActivityHistoryBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        this.context = this;
        this.mySp = new MySp(this.context);
        this.binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HistoryActivity.this.onBackPressed();
            }
        });
        setButton(0);
        this.binding.textTranslate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HistoryActivity.this.binding.viewPager.setCurrentItem(0);
            }
        });
        this.binding.textConversation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HistoryActivity.this.binding.viewPager.setCurrentItem(1);
            }
        });
        this.binding.viewPager.setAdapter(new HistoryPageAdapter(this.context, getSupportFragmentManager(), 0, 2));
        this.binding.viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int i) {
            }

            @Override
            public void onPageScrolled(int i, float f, int i2) {
            }

            @Override
            public void onPageSelected(int i) {
                HistoryActivity.this.setButton(i);
            }
        });
        this.binding.textDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HistoryActivity.this.openDeleteDialog();
            }
        });
    }

    
    public void openDeleteDialog() {
        final Dialog dialog = new Dialog(this.context);
        View inflate = LayoutInflater.from(this.context).inflate(R.layout.delete_dialog_layout, (ViewGroup) null);
        dialog.setCancelable(false);
        dialog.setContentView(inflate);
        ((TextView) inflate.findViewById(R.id.text_sub)).setText(getString(R.string.text_sub_delete_hist));
        ((TextView) inflate.findViewById(R.id.text_no)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        ((TextView) inflate.findViewById(R.id.text_yes)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                HistoryActivity.this.mySp.setHistory(arrayList);
                HistoryActivity.this.mySp.setConv(arrayList2);
                dialog.dismiss();
                HistoryActivity.this.onBackPressed();
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
    }

    
    public void setButton(int i) {
        if (i == 0) {
            this.binding.textTranslate.setSelected(true);
            this.binding.textConversation.setSelected(false);
            return;
        }
        this.binding.textTranslate.setSelected(false);
        this.binding.textConversation.setSelected(true);
    }
}
