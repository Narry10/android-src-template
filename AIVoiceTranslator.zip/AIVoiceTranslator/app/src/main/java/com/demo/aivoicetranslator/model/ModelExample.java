package com.demo.aivoicetranslator.model;

public class ModelExample {
    public String title;
    public String value;

    public ModelExample(String str, String str2) {
        this.title = str;
        this.value = str2;
    }
}
