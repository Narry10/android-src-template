package com.demo.aivoicetranslator.activity;

import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.constraintlayout.helper.widget.MotionEffect;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.adapter.AdapterVoiceConversation;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.demo.aivoicetranslator.databinding.ActivityConversationBinding;
import com.demo.aivoicetranslator.extra.MySp;
import com.demo.aivoicetranslator.model.ModelVoiceConvesation;
import com.mannan.translateapi.TranslateAPI;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

public class ConversationActivity extends BaseActivity implements TextToSpeech.OnInitListener {
    int REQUEST_CODE_SPEECH_INPUT = 102;
    ActivityConversationBinding binding;
    Context context;
    int id;
    boolean isMy = false;
    ArrayList<ModelVoiceConvesation> list; // = new ArrayList<>();
    MySp mySp;
    TextToSpeech tts;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityConversationBinding inflate = ActivityConversationBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);


        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        list = new ArrayList<>();
        this.context = this;
        this.mySp = new MySp(this.context);
        this.tts = new TextToSpeech(this.context, this);
        this.binding.textFirstLan.setText(this.mySp.getFirstLan());
        this.binding.textSecondLan.setText(this.mySp.getSecondLan());
        this.id = getIntent().getIntExtra("id", -1);
        Log.d(MotionEffect.TAG, "onCreate: " + this.id);
        if (this.id == -1) {
            ArrayList<ModelVoiceConvesation> conv = this.mySp.getConv();
            if (!conv.isEmpty()) {
                this.id = conv.get(conv.size() - 1).id;
            }
            this.id++;
        } else {
            Iterator<ModelVoiceConvesation> it = this.mySp.getConv().iterator();
            while (it.hasNext()) {
                ModelVoiceConvesation next = it.next();
                if (next.id == this.id) {
                    this.list.add(next);
                }
            }
        }
        this.binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ConversationActivity.this.onBackPressed();
            }
        });
        this.binding.imgFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ConversationActivity.this.isMy = false;
                ConversationActivity.this.startRecognize();
            }
        });
        this.binding.imgSecond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ConversationActivity.this.isMy = true;
                ConversationActivity.this.startRecognize();
            }
        });
        this.binding.recyclerView.setAdapter(new AdapterVoiceConversation(this.list, new AdapterVoiceConversation.setOnClickLisner() {
            @Override
            public void onSpeak(int i) {
                ConversationActivity conversationActivity = ConversationActivity.this;
                conversationActivity.speakOut(conversationActivity.list.get(i).textSecond);
            }

            @Override
            public void onCopy(int i) {
                ((ClipboardManager) ConversationActivity.this.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText(ConversationActivity.this.getString(R.string.app_name), ConversationActivity.this.list.get(i).textSecond));
            }
        }));
        this.binding.recyclerView.setLayoutManager(new LinearLayoutManager(this.context, RecyclerView.VERTICAL, false));
        this.binding.textDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ConversationActivity.this.openDeleteDialog();
            }
        });
        setList();
    }

    
    public void setList() {
        if (this.list.isEmpty()) {
            this.binding.imgNoData.setVisibility(0);
            this.binding.textNoData.setVisibility(0);
            return;
        }
        this.binding.imgNoData.setVisibility(8);
        this.binding.textNoData.setVisibility(8);
    }

    
    public void openDeleteDialog() {
        final Dialog dialog = new Dialog(this.context);
        View inflate = LayoutInflater.from(this.context).inflate(R.layout.delete_dialog_layout, (ViewGroup) null);
        dialog.setContentView(inflate);
        dialog.setCancelable(false);
        ((TextView) inflate.findViewById(R.id.text_sub)).setText(getString(R.string.text_sub_delete_one));
        ((TextView) inflate.findViewById(R.id.text_no)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        ((TextView) inflate.findViewById(R.id.text_yes)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ConversationActivity.this.list.clear();
                ArrayList arrayList = new ArrayList();
                Iterator<ModelVoiceConvesation> it = ConversationActivity.this.mySp.getConv().iterator();
                while (it.hasNext()) {
                    ModelVoiceConvesation next = it.next();
                    if (next.id != ConversationActivity.this.id) {
                        Log.d(MotionEffect.TAG, "onClick: " + next.id);
                        Log.d(MotionEffect.TAG, "onClick: my" + ConversationActivity.this.id);
                        arrayList.add(next);
                    }
                }
                ConversationActivity.this.mySp.setConv(arrayList);
                ConversationActivity.this.binding.recyclerView.getAdapter().notifyDataSetChanged();
                ConversationActivity.this.setList();
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
    }

    public void startRecognize() {
        Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        if (this.isMy) {
            intent.putExtra("android.speech.extra.LANGUAGE", this.mySp.getSecondLanCode());
        } else {
            intent.putExtra("android.speech.extra.LANGUAGE", this.mySp.getFirstLanCode());
        }
        intent.putExtra("android.speech.extra.PROMPT", "Speak to text");
        try {
            startActivityForResult(intent, this.REQUEST_CODE_SPEECH_INPUT);
        } catch (Exception e) {
            Toast.makeText(this.context, " " + e.getMessage(), 0).show();
        }
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == this.REQUEST_CODE_SPEECH_INPUT && i2 == -1 && intent != null) {
            final ArrayList<String> stringArrayListExtra = intent.getStringArrayListExtra("android.speech.extra.RESULTS");
            final ArrayList arrayList = new ArrayList();
            arrayList.clear();
            arrayList.addAll(this.mySp.getConv());
            if (this.isMy) {
                new TranslateAPI(this.mySp.getSecondLanCode(), this.mySp.getFirstLanCode(), stringArrayListExtra.get(0)).setTranslateListener(new TranslateAPI.TranslateListener() {
                    @Override
                    public void onSuccess(String str) {
                        Log.d(MotionEffect.TAG, "onSuccess: " + str);
                        if (ConversationActivity.this.isMy) {
                            String str2 = str;
                            ConversationActivity.this.list.add(new ModelVoiceConvesation(ConversationActivity.this.id, ConversationActivity.this.mySp.getFirstImgLan(), ConversationActivity.this.mySp.getSecondImgLan(), (String) stringArrayListExtra.get(0), str2, ConversationActivity.this.mySp.getSecondLan(), true));
                            arrayList.add(new ModelVoiceConvesation(ConversationActivity.this.id, ConversationActivity.this.mySp.getFirstImgLan(), ConversationActivity.this.mySp.getSecondImgLan(), (String) stringArrayListExtra.get(0), str2, ConversationActivity.this.mySp.getSecondLan(), true));
                        } else {
                            String str3 = str;
                            ConversationActivity.this.list.add(new ModelVoiceConvesation(ConversationActivity.this.id, ConversationActivity.this.mySp.getFirstImgLan(), ConversationActivity.this.mySp.getSecondImgLan(), (String) stringArrayListExtra.get(0), str3, ConversationActivity.this.mySp.getFirstLan(), false));
                            arrayList.add(new ModelVoiceConvesation(ConversationActivity.this.id, ConversationActivity.this.mySp.getFirstImgLan(), ConversationActivity.this.mySp.getSecondImgLan(), (String) stringArrayListExtra.get(0), str3, ConversationActivity.this.mySp.getFirstLan(), false));
                        }
                        ConversationActivity.this.mySp.setConv(arrayList);
                        ConversationActivity.this.setList();
                        ConversationActivity.this.binding.recyclerView.getAdapter().notifyDataSetChanged();
                    }

                    @Override
                    public void onFailure(String str) {
                        Log.d(MotionEffect.TAG, "onFailure: " + str);
                    }
                });
            } else {
                new TranslateAPI(this.mySp.getFirstLanCode(), this.mySp.getSecondLanCode(), stringArrayListExtra.get(0)).setTranslateListener(new TranslateAPI.TranslateListener() {
                    @Override
                    public void onSuccess(String str) {
                        Log.d(MotionEffect.TAG, "onSuccess: " + str);
                        if (ConversationActivity.this.isMy) {
                            String str2 = str;
                            ConversationActivity.this.list.add(new ModelVoiceConvesation(ConversationActivity.this.id, ConversationActivity.this.mySp.getFirstImgLan(), ConversationActivity.this.mySp.getSecondImgLan(), (String) stringArrayListExtra.get(0), str2, ConversationActivity.this.mySp.getSecondLan(), true));
                            arrayList.add(new ModelVoiceConvesation(ConversationActivity.this.id, ConversationActivity.this.mySp.getFirstImgLan(), ConversationActivity.this.mySp.getSecondImgLan(), (String) stringArrayListExtra.get(0), str2, ConversationActivity.this.mySp.getSecondLan(), true));
                        } else {
                            String str3 = str;
                            ConversationActivity.this.list.add(new ModelVoiceConvesation(ConversationActivity.this.id, ConversationActivity.this.mySp.getFirstImgLan(), ConversationActivity.this.mySp.getSecondImgLan(), (String) stringArrayListExtra.get(0), str3, ConversationActivity.this.mySp.getFirstLan(), false));
                            arrayList.add(new ModelVoiceConvesation(ConversationActivity.this.id, ConversationActivity.this.mySp.getFirstImgLan(), ConversationActivity.this.mySp.getSecondImgLan(), (String) stringArrayListExtra.get(0), str3, ConversationActivity.this.mySp.getFirstLan(), false));
                        }
                        ConversationActivity.this.mySp.setConv(arrayList);
                        ConversationActivity.this.setList();
                        ConversationActivity.this.binding.recyclerView.getAdapter().notifyDataSetChanged();
                    }

                    @Override
                    public void onFailure(String str) {
                        Log.d(MotionEffect.TAG, "onFailure: " + str);
                    }
                });
            }
        }
    }

    
    public void speakOut(String str) {
        this.tts.speak(str, 0, (Bundle) null, (String) null);
    }

    @Override
    public void onInit(int i) {
        if (i == 0) {
            int language = this.tts.setLanguage(Locale.US);
            if (language == -1 || language == -2) {
                Log.e("TTS", "This Language is not supported");
                return;
            }
            return;
        }
        Log.e("TTS", "Initilization Failed!");
    }
}
