package com.demo.aivoicetranslator.adapter;

import android.content.Context;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import com.demo.aivoicetranslator.fragment.ConversationFragment;
import com.demo.aivoicetranslator.fragment.TranslationFragment;

public class HistoryPageAdapter extends FragmentPagerAdapter {
    private Context myContext;
    int totalTabs;

    public HistoryPageAdapter(Context context, FragmentManager fragmentManager, int i, int i2) {
        super(fragmentManager, i);
        this.myContext = context;
        this.totalTabs = i2;
    }

    @Override
    public Fragment getItem(int i) {
        if (i == 0) {
            return new TranslationFragment();
        }
        if (i != 1) {
            return null;
        }
        return new ConversationFragment();
    }

    @Override
    public int getCount() {
        return this.totalTabs;
    }
}
