package com.demo.aivoicetranslator.model;

public class ModelFav {
    public int imgFirst;
    public int imgSecond;
    public String textFirst;
    public String textSecond;

    public ModelFav(int i, String str, int i2, String str2) {
        this.imgFirst = i;
        this.textFirst = str;
        this.imgSecond = i2;
        this.textSecond = str2;
    }
}
