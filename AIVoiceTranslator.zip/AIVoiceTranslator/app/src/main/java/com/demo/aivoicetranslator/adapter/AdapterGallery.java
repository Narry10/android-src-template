package com.demo.aivoicetranslator.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.demo.aivoicetranslator.R;
import java.util.ArrayList;

public class AdapterGallery extends RecyclerView.Adapter<AdapterGallery.ViewHolder> {
    ArrayList<String> list;
    setOnClickListener mListener;

    public interface setOnClickListener {
        void onItemClick(int i);
    }

    public AdapterGallery(ArrayList<String> arrayList, setOnClickListener setonclicklistener) {
        this.list = arrayList;
        this.mListener = setonclicklistener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.gallery_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        ((RequestBuilder) Glide.with(viewHolder.itemView.getContext()).load(this.list.get(i)).centerCrop()).into(viewHolder.imgPhoto);
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterGallery.this.mListener.onItemClick(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgPhoto;

        public ViewHolder(View view) {
            super(view);
            this.imgPhoto = (ImageView) view.findViewById(R.id.img_photo);
        }
    }
}
