package com.demo.aivoicetranslator.permission;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionUtils {
    public static final int REQUEST_MEDIA_PERMISSION = 9898988;

    public static boolean isMediaPermissionGranted(Context context) {
        if (Build.VERSION.SDK_INT >= 33) {
            boolean z = ContextCompat.checkSelfPermission(context, "android.permission.CAMERA") == 0;
            boolean z2 = ContextCompat.checkSelfPermission(context, "android.permission.RECORD_AUDIO") == 0;
            boolean z3 = ContextCompat.checkSelfPermission(context, "android.permission.READ_MEDIA_IMAGES") == 0;
            if (!z2 || !z || !z3) {
                return false;
            }
            return true;
        }
        boolean z4 = ContextCompat.checkSelfPermission(context, "android.permission.CAMERA") == 0;
        boolean z5 = ContextCompat.checkSelfPermission(context, "android.permission.RECORD_AUDIO") == 0;
        boolean z6 = ContextCompat.checkSelfPermission(context, "android.permission.WRITE_EXTERNAL_STORAGE") == 0;
        boolean z7 = ContextCompat.checkSelfPermission(context, "android.permission.READ_EXTERNAL_STORAGE") == 0;
        if (!z6 || !z7 || !z4 || !z5) {
            return false;
        }
        return true;
    }

    public static void requestMediaPermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(activity, new String[]{"android.permission.READ_MEDIA_IMAGES", "android.permission.CAMERA", "android.permission.RECORD_AUDIO"}, REQUEST_MEDIA_PERMISSION);
        } else {
            ActivityCompat.requestPermissions(activity, new String[]{"android.permission.CAMERA", "android.permission.RECORD_AUDIO", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"}, REQUEST_MEDIA_PERMISSION);
        }
    }

}
