package com.demo.aivoicetranslator.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.model.ModelHistory;
import java.util.ArrayList;

public class AdapterTransalation extends RecyclerView.Adapter<AdapterTransalation.ViewHolder> {
    ArrayList<ModelHistory> list;
    setOnclickListner mListner;

    public interface setOnclickListner {
        void onDelete(int i);

        void onFav(int i, boolean z);

        void onSpeak(int i);
    }

    public AdapterTransalation(ArrayList<ModelHistory> arrayList, setOnclickListner setonclicklistner) {
        this.list = arrayList;
        this.mListner = setonclicklistner;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.translation_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        ModelHistory modelHistory = this.list.get(i);
        Glide.with(viewHolder.itemView.getContext()).load(Integer.valueOf(modelHistory.imgFirst)).into(viewHolder.imgFirst);
        Glide.with(viewHolder.itemView.getContext()).load(Integer.valueOf(modelHistory.imgSecond)).into(viewHolder.imgSecond);
        viewHolder.textFirstLan.setText(modelHistory.textFirst);
        viewHolder.textSecondLan.setText(modelHistory.textSecond);
        viewHolder.imgSave.setSelected(modelHistory.isFav);
        viewHolder.imgSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.isSelected()) {
                    view.setSelected(false);
                } else {
                    view.setSelected(true);
                }
                AdapterTransalation.this.mListner.onFav(i, view.isSelected());
            }
        });
        viewHolder.imgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterTransalation.this.mListner.onDelete(i);
            }
        });
        viewHolder.imgSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterTransalation.this.mListner.onSpeak(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgDelete;
        ImageView imgFirst;
        ImageView imgSave;
        ImageView imgSecond;
        ImageView imgSpeak;
        TextView textFirstLan;
        TextView textSecondLan;

        public ViewHolder(View view) {
            super(view);
            this.textFirstLan = (TextView) view.findViewById(R.id.text_first);
            this.textSecondLan = (TextView) view.findViewById(R.id.text_second);
            this.imgFirst = (ImageView) view.findViewById(R.id.img_first);
            this.imgSecond = (ImageView) view.findViewById(R.id.img_second);
            this.imgDelete = (ImageView) view.findViewById(R.id.img_delete);
            this.imgSave = (ImageView) view.findViewById(R.id.img_fav);
            this.imgSpeak = (ImageView) view.findViewById(R.id.img_speak);
        }
    }
}
