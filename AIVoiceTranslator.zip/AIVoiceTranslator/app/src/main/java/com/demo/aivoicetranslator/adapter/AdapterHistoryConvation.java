package com.demo.aivoicetranslator.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.model.ModelVoiceConvesation;
import java.util.ArrayList;

public class AdapterHistoryConvation extends RecyclerView.Adapter<AdapterHistoryConvation.ViewHolder> {
    ArrayList<ModelVoiceConvesation> list;
    setOnClickLitsner mListner;

    public interface setOnClickLitsner {
        void onItemClick(int i);
    }

    public AdapterHistoryConvation(ArrayList<ModelVoiceConvesation> arrayList, setOnClickLitsner setonclicklitsner) {
        this.list = arrayList;
        this.mListner = setonclicklitsner;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.history_conversation_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        ModelVoiceConvesation modelVoiceConvesation = this.list.get(i);
        viewHolder.textFirstLan.setText(modelVoiceConvesation.textFirst);
        viewHolder.textSecondLan.setText(modelVoiceConvesation.textSecond);
        Glide.with(viewHolder.itemView.getContext()).load(Integer.valueOf(modelVoiceConvesation.imgFirst)).into(viewHolder.imgFirst);
        Glide.with(viewHolder.itemView.getContext()).load(Integer.valueOf(modelVoiceConvesation.imgSecond)).into(viewHolder.imgSecond);
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterHistoryConvation.this.mListner.onItemClick(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgFirst;
        ImageView imgSecond;
        TextView textFirstLan;
        TextView textSecondLan;

        public ViewHolder(View view) {
            super(view);
            this.textFirstLan = (TextView) view.findViewById(R.id.text_first);
            this.textSecondLan = (TextView) view.findViewById(R.id.text_second);
            this.imgFirst = (ImageView) view.findViewById(R.id.img_first);
            this.imgSecond = (ImageView) view.findViewById(R.id.img_second);
        }
    }
}
