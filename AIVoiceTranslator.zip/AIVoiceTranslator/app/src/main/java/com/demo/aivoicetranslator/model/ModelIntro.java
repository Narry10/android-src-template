package com.demo.aivoicetranslator.model;

public class ModelIntro {
    int image;
    int message;
    int step;
    int title;

    public ModelIntro(int i, int i2, int i3, int i4) {
        this.image = i;
        this.title = i2;
        this.message = i3;
        this.step = i4;
    }

    public int getStep() {
        return this.step;
    }

    public void setStep(int i) {
        this.step = i;
    }

    public int getImage() {
        return this.image;
    }

    public void setImage(int i) {
        this.image = i;
    }

    public int getTitle() {
        return this.title;
    }

    public void setTitle(int i) {
        this.title = i;
    }

    public int getMessage() {
        return this.message;
    }

    public void setMessage(int i) {
        this.message = i;
    }
}
