package com.demo.aivoicetranslator.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.activity.PhrasesActivity;
import com.demo.aivoicetranslator.extra.MySp;
import com.demo.aivoicetranslator.model.Sections;
import com.mannan.translateapi.Language;
import java.util.ArrayList;

public class AdapterSection extends RecyclerView.Adapter<AdapterSection.ViewHolder> {
    ArrayList<Sections> list;
    setOnClickListner mListner;
    MySp mySp;

    public interface setOnClickListner {
        void onItemClick(int i);
    }

    public AdapterSection(ArrayList<Sections> arrayList, setOnClickListner setonclicklistner) {
        this.list = arrayList;
        this.mListner = setonclicklistner;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.section_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        Sections sections = this.list.get(i);
        this.mySp = new MySp(viewHolder.itemView.getContext());
        char c = 1;
        if (PhrasesActivity.select == i) {
            viewHolder.itemView.setSelected(true);
        } else {
            viewHolder.itemView.setSelected(false);
        }
        String firstLanCodePhr = this.mySp.getFirstLanCodePhr();
        firstLanCodePhr.hashCode();
        switch (firstLanCodePhr.hashCode()) {
            case 3201:
                if (firstLanCodePhr.equals(Language.GERMAN)) {
                    c = 0;
                    break;
                }
            case 3355:
                break;
            case 3371:
                if (firstLanCodePhr.equals(Language.ITALIAN)) {
                    c = 2;
                    break;
                }
            case 3383:
                if (firstLanCodePhr.equals(Language.JAPANESE)) {
                    c = 3;
                    break;
                }
            case 3518:
                if (firstLanCodePhr.equals(Language.DUTCH)) {
                    c = 4;
                    break;
                }
            case 3580:
                if (firstLanCodePhr.equals(Language.POLISH)) {
                    c = 5;
                    break;
                }
            case 3645:
                if (firstLanCodePhr.equals(Language.ROMANIAN)) {
                    c = 6;
                    break;
                }
            case 3651:
                if (firstLanCodePhr.equals(Language.RUSSIAN)) {
                    c = 7;
                    break;
                }
            case 3683:
                if (firstLanCodePhr.equals(Language.SWEDISH)) {
                    c = 8;
                    break;
                }
            case 3700:
                if (firstLanCodePhr.equals(Language.THAI)) {
                    c = 9;
                    break;
                }
            case 3710:
                if (firstLanCodePhr.equals(Language.TURKISH)) {
                    c = 10;
                    break;
                }
            case 93071090:
                if (firstLanCodePhr.equals("ar_AE")) {
                    c = 11;
                    break;
                }
            case 93071216:
                if (firstLanCodePhr.equals("ar_EG")) {
                    c = 12;
                    break;
                }
            case 93071644:
                if (firstLanCodePhr.equals("ar_SA")) {
                    c = 13;
                    break;
                }
            case 96646026:
                if (firstLanCodePhr.equals("en_AU")) {
                    c = 14;
                    break;
                }
            case 96646636:
                if (firstLanCodePhr.equals("en_UK")) {
                    c = 15;
                    break;
                }
            case 96646644:
                if (firstLanCodePhr.equals("en_US")) {
                    c = 16;
                    break;
                }
            case 96795103:
                if (firstLanCodePhr.equals("es_ES")) {
                    c = 17;
                    break;
                }
            case 96795356:
                if (firstLanCodePhr.equals("es_MX")) {
                    c = 18;
                    break;
                }
            case 96795599:
                if (firstLanCodePhr.equals("es_US")) {
                    c = 19;
                    break;
                }
            case 97688753:
                if (firstLanCodePhr.equals("fr_CA")) {
                    c = 20;
                    break;
                }
            case 97688863:
                if (firstLanCodePhr.equals("fr_FR")) {
                    c = 21;
                    break;
                }
            case 106983531:
                if (firstLanCodePhr.equals("pt_BR")) {
                    c = 22;
                    break;
                }
            case 106983967:
                if (firstLanCodePhr.equals("pt_PT")) {
                    c = 23;
                    break;
                }
            case 115861276:
                if (firstLanCodePhr.equals("zh_CN")) {
                    c = 24;
                    break;
                }
            case 115861812:
                if (firstLanCodePhr.equals("zh_TW")) {
                    c = 25;
                    break;
                }
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                viewHolder.textSection.setText(sections.de);
                break;
            case 1:
                viewHolder.textSection.setText(sections.id);
                break;
            case 2:
                viewHolder.textSection.setText(sections.it);
                break;
            case 3:
                viewHolder.textSection.setText(sections.ja);
                break;
            case 4:
                viewHolder.textSection.setText(sections.nl);
                break;
            case 5:
                viewHolder.textSection.setText(sections.pl);
                break;
            case 6:
                viewHolder.textSection.setText(sections.ro);
                break;
            case 7:
                viewHolder.textSection.setText(sections.ru);
                break;
            case 8:
                viewHolder.textSection.setText(sections.sv);
                break;
            case 9:
                viewHolder.textSection.setText(sections.th);
                break;
            case 10:
                viewHolder.textSection.setText(sections.tr);
                break;
            case 11:
                viewHolder.textSection.setText(sections.ar_AE);
                break;
            case 12:
                viewHolder.textSection.setText(sections.ar_EG);
                break;
            case 13:
                viewHolder.textSection.setText(sections.ar_SA);
                break;
            case 14:
                viewHolder.textSection.setText(sections.en_AU);
                break;
            case 15:
                viewHolder.textSection.setText(sections.en_UK);
                break;
            case 16:
                viewHolder.textSection.setText(sections.en_US);
                break;
            case 17:
                viewHolder.textSection.setText(sections.es_ES);
                break;
            case 18:
                viewHolder.textSection.setText(sections.es_MX);
                break;
            case 19:
                viewHolder.textSection.setText(sections.es_US);
                break;
            case 20:
                viewHolder.textSection.setText(sections.fr_CA);
                break;
            case 21:
                viewHolder.textSection.setText(sections.fr_FR);
                break;
            case 22:
                viewHolder.textSection.setText(sections.pt_BR);
                break;
            case 23:
                viewHolder.textSection.setText(sections.pt_PT);
                break;
            case 24:
                viewHolder.textSection.setText(sections.zh_CN);
                break;
            case 25:
                viewHolder.textSection.setText(sections.zh_TW);
                break;
            default:
                viewHolder.textSection.setText(sections.en_US);
                break;
        }
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterSection.this.mListner.onItemClick(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textSection;

        public ViewHolder(View view) {
            super(view);
            this.textSection = (TextView) view.findViewById(R.id.text_section);
        }
    }
}
