package com.demo.aivoicetranslator.extra;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.demo.aivoicetranslator.model.ModelHistory;
import com.demo.aivoicetranslator.model.ModelVoiceConvesation;
import com.mannan.translateapi.Language;
import java.util.ArrayList;

public class MySp {
    String keyCovers = "keyCovers";
    String keyFirstImgLan = "keyFirstImgLan";
    String keyFirstImgLanPhr = "keyFirstImgLanPhr";
    String keyFirstLan = "keyFirstLan";
    String keyFirstLanCode = "keyFirstLanCode";
    String keyFirstLanCodePhr = "keyFirstLanCodePhr";
    String keyFirstLanPhr = "keyFirstLanPhr";
    String keyFirstPos = "keyFirstPos";
    String keyFirstPosPhr = "keyFirstPosPhr";
    String keyHistory = "keyHistory";
    String keyMySp = "keyMySp";
    String keySecondImgLan = "keySecondImgLan";
    String keySecondImgLanPhr = "keySecondImgLanPhr";
    String keySecondLan = "keySecondLan";
    String keySecondLanCode = "keySecondLanCode";
    String keySecondLanCodePhr = "keySecondLanCodePhr";
    String keySecondLanPhr = "keySecondLanPhr";
    String keySecondPos = "keySecondPos";
    String keySecondPosPhr = "keySecondPosPhr";
    String keyTranslate = "keyTranslate";
    SharedPreferences sp;

    public MySp(Context context) {
        this.sp = context.getSharedPreferences("keyMySp", 0);
    }

    public void setFirstLanCode(String str) {
        this.sp.edit().putString(this.keyFirstLanCode, str).apply();
    }

    public String getFirstLanCode() {
        return this.sp.getString(this.keyFirstLanCode, Language.ENGLISH);
    }

    public void setSecondLanCode(String str) {
        this.sp.edit().putString(this.keySecondLanCode, str).apply();
    }

    public String getSecondLanCode() {
        return this.sp.getString(this.keySecondLanCode, Language.HINDI);
    }

    public void setFirstLan(String str) {
        this.sp.edit().putString(this.keyFirstLan, str).apply();
    }

    public String getFirstLan() {
        return this.sp.getString(this.keyFirstLan, "English");
    }

    public void setFirstImgLan(int i) {
        this.sp.edit().putInt(this.keyFirstImgLan, i).apply();
    }

    public int getFirstImgLan() {
        return this.sp.getInt(this.keyFirstImgLan, 0);
    }

    public void setFirstImgLanPhr(int i) {
        this.sp.edit().putInt(this.keyFirstImgLanPhr, i).apply();
    }

    public int getFirstImgLanPhr() {
        return this.sp.getInt(this.keyFirstImgLanPhr, 0);
    }

    public void setSecondLan(String str) {
        this.sp.edit().putString(this.keySecondLan, str).apply();
    }

    public String getSecondLan() {
        return this.sp.getString(this.keySecondLan, "Hindi");
    }

    public void setSecondImgLan(int i) {
        this.sp.edit().putInt(this.keySecondImgLan, i).apply();
    }

    public int getSecondImgLan() {
        return this.sp.getInt(this.keySecondImgLan, 0);
    }

    public void setSecondImgLanPhr(int i) {
        this.sp.edit().putInt(this.keySecondImgLanPhr, i).apply();
    }

    public int getSecondImgLanPhr() {
        return this.sp.getInt(this.keySecondImgLanPhr, 0);
    }

    public void setFirstPos(int i) {
        this.sp.edit().putInt(this.keyFirstPos, i).apply();
    }

    public int getFirstPos() {
        return this.sp.getInt(this.keyFirstPos, 15);
    }

    public void setSecondPos(int i) {
        this.sp.edit().putInt(this.keySecondPos, i).apply();
    }

    public int getSecondPos() {
        return this.sp.getInt(this.keySecondPos, 15);
    }

    public void setFirstLanCodePhr(String str) {
        this.sp.edit().putString(this.keyFirstLanCodePhr, str).apply();
    }

    public String getFirstLanCodePhr() {
        return this.sp.getString(this.keyFirstLanCodePhr, Language.ENGLISH);
    }

    public void setSecondLanCodePhr(String str) {
        this.sp.edit().putString(this.keySecondLanCodePhr, str).apply();
    }

    public String getSecondLanCodePhr() {
        return this.sp.getString(this.keySecondLanCodePhr, Language.HINDI);
    }

    public void setFirstLanPhr(String str) {
        this.sp.edit().putString(this.keyFirstLanPhr, str).apply();
    }

    public String getFirstLanPhr() {
        return this.sp.getString(this.keyFirstLanPhr, "English");
    }

    public void setSecondLanPhr(String str) {
        this.sp.edit().putString(this.keySecondLanPhr, str).apply();
    }

    public String getSecondLanPhr() {
        return this.sp.getString(this.keySecondLanPhr, "Hindi");
    }

    public void setFirstPosPhr(int i) {
        this.sp.edit().putInt(this.keyFirstPosPhr, i).apply();
    }

    public int getFirstPosPhr() {
        return this.sp.getInt(this.keyFirstPosPhr, 6);
    }

    public void setSecondPosPhr(int i) {
        this.sp.edit().putInt(this.keySecondPosPhr, i).apply();
    }

    public int getSecondPosPhr() {
        return this.sp.getInt(this.keySecondPosPhr, 6);
    }

    public ArrayList<ModelVoiceConvesation> getConv() {
        Gson gson = new Gson();
        String string = this.sp.getString(this.keyCovers, "");
        Log.d("TAG", "getKeyQRData: " + string);
        ArrayList<ModelVoiceConvesation> arrayList = (ArrayList) gson.fromJson(string, new TypeToken<ArrayList<ModelVoiceConvesation>>() {
        }.getType());
        return arrayList == null ? new ArrayList<>() : arrayList;
    }

    public void setConv(ArrayList<ModelVoiceConvesation> arrayList) {
        this.sp.edit().putString(this.keyCovers, new Gson().toJson((Object) arrayList)).apply();
    }

    public ArrayList<ModelHistory> getHistory() {
        Gson gson = new Gson();
        String string = this.sp.getString(this.keyHistory, "");
        Log.d("TAG", "getKeyQRData: " + string);
        ArrayList<ModelHistory> arrayList = (ArrayList) gson.fromJson(string, new TypeToken<ArrayList<ModelHistory>>() {
        }.getType());
        return arrayList == null ? new ArrayList<>() : arrayList;
    }

    public void setHistory(ArrayList<ModelHistory> arrayList) {
        this.sp.edit().putString(this.keyHistory, new Gson().toJson((Object) arrayList)).apply();
    }

}
