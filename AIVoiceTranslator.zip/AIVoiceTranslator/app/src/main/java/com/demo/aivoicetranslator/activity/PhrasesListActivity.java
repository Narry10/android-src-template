package com.demo.aivoicetranslator.activity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.constraintlayout.helper.widget.MotionEffect;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.Key;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.adapter.AdapterPhrasesList;
import com.demo.aivoicetranslator.databinding.ActivityPhrasesListBinding;
import com.demo.aivoicetranslator.extra.MySp;
import com.demo.aivoicetranslator.model.PhrasesList;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;

public class PhrasesListActivity extends BaseActivity {
    public static int[] flag = {R.drawable.while_travelling, R.drawable.medical, R.drawable.at_the_hotel, R.drawable.at_the_restaurant, R.drawable.at_the_bar, R.drawable.at_the_store, R.drawable.at_work, R.drawable.time_date_number, R.drawable.education, R.drawable.essentials, R.drawable.entertainment, R.drawable.around_town, R.drawable.common_problem};
    ActivityPhrasesListBinding binding;
    Context context;
    MySp mySp;

    @Override
    public void onResume() {
        super.onResume();
        this.binding.textFirstLan.setText(this.mySp.getFirstLanPhr());
        this.binding.textSecondLan.setText(this.mySp.getSecondLanPhr());
        if (this.mySp.getFirstImgLanPhr() == 0) {
            this.mySp.setFirstImgLanPhr(R.drawable.english);
            this.mySp.setSecondImgLanPhr(R.drawable.hindi);
        }
        Glide.with(this.context).load(Integer.valueOf(this.mySp.getFirstImgLanPhr())).into(this.binding.imgFirst);
        Glide.with(this.context).load(Integer.valueOf(this.mySp.getSecondImgLanPhr())).into(this.binding.imgSecond);
        this.binding.recyclerView.getAdapter().notifyDataSetChanged();
    }

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityPhrasesListBinding inflate = ActivityPhrasesListBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        this.context = this;
        this.mySp = new MySp(this.context);
        this.binding.imgFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PhrasesListActivity.this.binding.imgFirst.setAlpha(0.5f);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        PhrasesListActivity.this.binding.imgFirst.setAlpha(1.0f);
                    }
                }, 100);
                PhrasesListActivity.this.startActivity(new Intent(PhrasesListActivity.this.context, LanguagePhrasesActivity.class).putExtra("select", false));
            }
        });
        this.binding.imgSecond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PhrasesListActivity.this.binding.imgSecond.setAlpha(0.5f);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        PhrasesListActivity.this.binding.imgSecond.setAlpha(1.0f);
                    }
                }, 100);
                PhrasesListActivity.this.startActivity(new Intent(PhrasesListActivity.this.context, LanguagePhrasesActivity.class).putExtra("select", true));
            }
        });
        this.binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PhrasesListActivity.this.onBackPressed();
            }
        });
        this.binding.textFirstLan.setText(this.mySp.getFirstLanPhr());
        this.binding.textSecondLan.setText(this.mySp.getSecondLanPhr());
        this.binding.imgSweep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String obj = PhrasesListActivity.this.binding.textFirstLan.getText().toString();
                String obj2 = PhrasesListActivity.this.binding.textSecondLan.getText().toString();
                String str = obj + obj2;
                String substring = str.substring(0, str.length() - obj2.length());
                String substring2 = str.substring(substring.length());
                PhrasesListActivity.this.binding.textFirstLan.setText(substring2);
                PhrasesListActivity.this.binding.textSecondLan.setText(substring);
                PhrasesListActivity.this.mySp.setFirstLan(substring2);
                PhrasesListActivity.this.mySp.setSecondLan(substring);
                int firstImgLan = PhrasesListActivity.this.mySp.getFirstImgLan();
                int secondImgLan = PhrasesListActivity.this.mySp.getSecondImgLan();
                String firstLanCode = PhrasesListActivity.this.mySp.getFirstLanCode();
                PhrasesListActivity.this.mySp.setFirstLanCode(PhrasesListActivity.this.mySp.getSecondLanCode());
                PhrasesListActivity.this.mySp.setSecondLanCode(firstLanCode);
                PhrasesListActivity.this.mySp.setFirstImgLan(secondImgLan);
                PhrasesListActivity.this.mySp.setSecondImgLan(firstImgLan);
                Glide.with(PhrasesListActivity.this.context).load(Integer.valueOf(PhrasesListActivity.this.mySp.getFirstImgLan())).into(PhrasesListActivity.this.binding.imgFirst);
                Glide.with(PhrasesListActivity.this.context).load(Integer.valueOf(PhrasesListActivity.this.mySp.getSecondImgLan())).into(PhrasesListActivity.this.binding.imgSecond);
            }
        });
        this.binding.textFirstLan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PhrasesListActivity.this.binding.textFirstLan.setAlpha(0.5f);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        PhrasesListActivity.this.binding.textFirstLan.setAlpha(1.0f);
                    }
                }, 100);
                PhrasesListActivity.this.startActivity(new Intent(PhrasesListActivity.this.context, LanguagePhrasesActivity.class).putExtra("select", false));
            }
        });
        this.binding.textSecondLan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PhrasesListActivity.this.binding.textSecondLan.setAlpha(0.5f);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        PhrasesListActivity.this.binding.textSecondLan.setAlpha(1.0f);
                    }
                }, 100);
                PhrasesListActivity.this.startActivity(new Intent(PhrasesListActivity.this.context, LanguagePhrasesActivity.class).putExtra("select", true));
            }
        });
        try {
            final ArrayList arrayList = (ArrayList) new Gson().fromJson(isToString(getAssets().open("categories.json")), new TypeToken<ArrayList<PhrasesList>>() {
            }.getType());
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                Log.d(MotionEffect.TAG, "onCreate: " + ((PhrasesList) it.next()).featured);
            }
            Log.d(MotionEffect.TAG, "onCreate: " + ((PhrasesList) arrayList.get(0)).featured);
            this.binding.recyclerView.setAdapter(new AdapterPhrasesList(arrayList, new AdapterPhrasesList.setOnClickListner() {
                @Override
                public void onItemClick(int i) {
                    PhrasesListActivity.this.startActivity(new Intent(PhrasesListActivity.this.context, PhrasesActivity.class).putExtra("id", ((PhrasesList) arrayList.get(i)).category_id));
                }
            }));
            this.binding.recyclerView.setLayoutManager(new LinearLayoutManager(this.context, 1, false));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public String isToString(InputStream inputStream) {
        char[] cArr = new char[1024];
        StringBuilder sb = new StringBuilder();
        try {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Key.STRING_CHARSET_NAME);
            while (true) {
                try {
                    int read = inputStreamReader.read(cArr, 0, 1024);
                    if (read < 0) {
                        return sb.toString();
                    }
                    sb.append(cArr, 0, read);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (UnsupportedEncodingException e2) {
            throw new RuntimeException(e2);
        }
    }

    public boolean isNetworkAvailable() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}
