package com.demo.aivoicetranslator.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.extra.MySp;
import com.demo.aivoicetranslator.model.Phrases;
import com.mannan.translateapi.Language;
import java.util.ArrayList;

public class AdapterPhrases extends RecyclerView.Adapter<AdapterPhrases.ViewHolder> {
    ArrayList<Phrases> list;
    setOnClickListner mListner;
    MySp mySp;

    public interface setOnClickListner {
        void onCopy(String str);

        void onShare(String str);

        void onSpeak(String str);
    }

    public AdapterPhrases(ArrayList<Phrases> arrayList, setOnClickListner setonclicklistner) {
        this.list = arrayList;
        this.mListner = setonclicklistner;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        char c;
        char c2;
        final ViewHolder viewHolder2 = viewHolder;
        Phrases phrases = this.list.get(i);
        MySp mySp2 = new MySp(viewHolder2.itemView.getContext());
        this.mySp = mySp2;
        String firstLanCodePhr = mySp2.getFirstLanCodePhr();
        firstLanCodePhr.hashCode();
        switch (firstLanCodePhr.hashCode()) {
            case 3201:
                if (firstLanCodePhr.equals(Language.GERMAN)) {
                    c = 0;
                    break;
                }
            case 3355:
                if (firstLanCodePhr.equals("id")) {
                    c = 1;
                    break;
                }
            case 3371:
                if (firstLanCodePhr.equals(Language.ITALIAN)) {
                    c = 2;
                    break;
                }
            case 3383:
                if (firstLanCodePhr.equals(Language.JAPANESE)) {
                    c = 3;
                    break;
                }
            case 3518:
                if (firstLanCodePhr.equals(Language.DUTCH)) {
                    c = 4;
                    break;
                }
            case 3580:
                if (firstLanCodePhr.equals(Language.POLISH)) {
                    c = 5;
                    break;
                }
            case 3645:
                if (firstLanCodePhr.equals(Language.ROMANIAN)) {
                    c = 6;
                    break;
                }
            case 3651:
                if (firstLanCodePhr.equals(Language.RUSSIAN)) {
                    c = 7;
                    break;
                }
            case 3683:
                if (firstLanCodePhr.equals(Language.SWEDISH)) {
                    c = 8;
                    break;
                }
            case 3700:
                if (firstLanCodePhr.equals(Language.THAI)) {
                    c = 9;
                    break;
                }
            case 3710:
                if (firstLanCodePhr.equals(Language.TURKISH)) {
                    c = 10;
                    break;
                }
            case 93071090:
                if (firstLanCodePhr.equals("ar_AE")) {
                    c = 11;
                    break;
                }
            case 93071216:
                if (firstLanCodePhr.equals("ar_EG")) {
                    c = 12;
                    break;
                }
            case 93071644:
                if (firstLanCodePhr.equals("ar_SA")) {
                    c = 13;
                    break;
                }
            case 96646026:
                if (firstLanCodePhr.equals("en_AU")) {
                    c = 14;
                    break;
                }
            case 96646636:
                if (firstLanCodePhr.equals("en_UK")) {
                    c = 15;
                    break;
                }
            case 96646644:
                if (firstLanCodePhr.equals("en_US")) {
                    c = 16;
                    break;
                }
            case 96795103:
                if (firstLanCodePhr.equals("es_ES")) {
                    c = 17;
                    break;
                }
            case 96795356:
                if (firstLanCodePhr.equals("es_MX")) {
                    c = 18;
                    break;
                }
            case 96795599:
                if (firstLanCodePhr.equals("es_US")) {
                    c = 19;
                    break;
                }
            case 97688753:
                if (firstLanCodePhr.equals("fr_CA")) {
                    c = 20;
                    break;
                }
            case 97688863:
                if (firstLanCodePhr.equals("fr_FR")) {
                    c = 21;
                    break;
                }
            case 106983531:
                if (firstLanCodePhr.equals("pt_BR")) {
                    c = 22;
                    break;
                }
            case 106983967:
                if (firstLanCodePhr.equals("pt_PT")) {
                    c = 23;
                    break;
                }
            case 115861276:
                if (firstLanCodePhr.equals("zh_CN")) {
                    c = 24;
                    break;
                }
            case 115861812:
                if (firstLanCodePhr.equals("zh_TW")) {
                    c = 25;
                    break;
                }
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                viewHolder2.textSection.setText(phrases.de);
                break;
            case 1:
                viewHolder2.textSection.setText(phrases.id);
                break;
            case 2:
                viewHolder2.textSection.setText(phrases.it);
                break;
            case 3:
                viewHolder2.textSection.setText(phrases.ja);
                break;
            case 4:
                viewHolder2.textSection.setText(phrases.nl);
                break;
            case 5:
                viewHolder2.textSection.setText(phrases.pl);
                break;
            case 6:
                viewHolder2.textSection.setText(phrases.ro);
                break;
            case 7:
                viewHolder2.textSection.setText(phrases.ru);
                break;
            case 8:
                viewHolder2.textSection.setText(phrases.sv);
                break;
            case 9:
                viewHolder2.textSection.setText(phrases.th);
                break;
            case 10:
                viewHolder2.textSection.setText(phrases.tr);
                break;
            case 11:
                viewHolder2.textSection.setText(phrases.ar_AE);
                break;
            case 12:
                viewHolder2.textSection.setText(phrases.ar_EG);
                break;
            case 13:
                viewHolder2.textSection.setText(phrases.ar_SA);
                break;
            case 14:
                viewHolder2.textSection.setText(phrases.en_AU);
                break;
            case 15:
                viewHolder2.textSection.setText(phrases.en_UK);
                break;
            case 16:
                viewHolder2.textSection.setText(phrases.en_US);
                break;
            case 17:
                viewHolder2.textSection.setText(phrases.es_ES);
                break;
            case 18:
                viewHolder2.textSection.setText(phrases.es_MX);
                break;
            case 19:
                viewHolder2.textSection.setText(phrases.es_US);
                break;
            case 20:
                viewHolder2.textSection.setText(phrases.fr_CA);
                break;
            case 21:
                viewHolder2.textSection.setText(phrases.fr_FR);
                break;
            case 22:
                viewHolder2.textSection.setText(phrases.pt_BR);
                break;
            case 23:
                viewHolder2.textSection.setText(phrases.pt_PT);
                break;
            case 24:
                viewHolder2.textSection.setText(phrases.zh_CN);
                break;
            case 25:
                viewHolder2.textSection.setText(phrases.zh_TW);
                break;
            default:
                viewHolder2.textSection.setText(phrases.en_US);
                break;
        }
        String secondLanCodePhr = this.mySp.getSecondLanCodePhr();
        secondLanCodePhr.hashCode();
        switch (secondLanCodePhr.hashCode()) {
            case 3201:
                if (secondLanCodePhr.equals(Language.GERMAN)) {
                    c2 = 0;
                    break;
                }
            case 3355:
                if (secondLanCodePhr.equals("id")) {
                    c2 = 1;
                    break;
                }
            case 3371:
                if (secondLanCodePhr.equals(Language.ITALIAN)) {
                    c2 = 2;
                    break;
                }
            case 3383:
                if (secondLanCodePhr.equals(Language.JAPANESE)) {
                    c2 = 3;
                    break;
                }
            case 3518:
                if (secondLanCodePhr.equals(Language.DUTCH)) {
                    c2 = 4;
                    break;
                }
            case 3580:
                if (secondLanCodePhr.equals(Language.POLISH)) {
                    c2 = 5;
                    break;
                }
            case 3645:
                if (secondLanCodePhr.equals(Language.ROMANIAN)) {
                    c2 = 6;
                    break;
                }
            case 3651:
                if (secondLanCodePhr.equals(Language.RUSSIAN)) {
                    c2 = 7;
                    break;
                }
            case 3683:
                if (secondLanCodePhr.equals(Language.SWEDISH)) {
                    c2 = 8;
                    break;
                }
            case 3700:
                if (secondLanCodePhr.equals(Language.THAI)) {
                    c2 = 9;
                    break;
                }
            case 3710:
                if (secondLanCodePhr.equals(Language.TURKISH)) {
                    c2 = 10;
                    break;
                }
            case 93071090:
                if (secondLanCodePhr.equals("ar_AE")) {
                    c2 = 11;
                    break;
                }
            case 93071216:
                if (secondLanCodePhr.equals("ar_EG")) {
                    c2 = 12;
                    break;
                }
            case 93071644:
                if (secondLanCodePhr.equals("ar_SA")) {
                    c2 = 13;
                    break;
                }
            case 96646026:
                if (secondLanCodePhr.equals("en_AU")) {
                    c2 = 14;
                    break;
                }
            case 96646636:
                if (secondLanCodePhr.equals("en_UK")) {
                    c2 = 15;
                    break;
                }
            case 96646644:
                if (secondLanCodePhr.equals("en_US")) {
                    c2 = 16;
                    break;
                }
            case 96795103:
                if (secondLanCodePhr.equals("es_ES")) {
                    c2 = 17;
                    break;
                }
            case 96795356:
                if (secondLanCodePhr.equals("es_MX")) {
                    c2 = 18;
                    break;
                }
            case 96795599:
                if (secondLanCodePhr.equals("es_US")) {
                    c2 = 19;
                    break;
                }
            case 97688753:
                if (secondLanCodePhr.equals("fr_CA")) {
                    c2 = 20;
                    break;
                }
            case 97688863:
                if (secondLanCodePhr.equals("fr_FR")) {
                    c2 = 21;
                    break;
                }
            case 106983531:
                if (secondLanCodePhr.equals("pt_BR")) {
                    c2 = 22;
                    break;
                }
            case 106983967:
                if (secondLanCodePhr.equals("pt_PT")) {
                    c2 = 23;
                    break;
                }
            case 115861276:
                if (secondLanCodePhr.equals("zh_CN")) {
                    c2 = 24;
                    break;
                }
            case 115861812:
                if (secondLanCodePhr.equals("zh_TW")) {
                    c2 = 25;
                    break;
                }
            default:
                c2 = 65535;
                break;
        }
        switch (c2) {
            case 0:
                viewHolder2.textPhrase.setText(phrases.de);
                break;
            case 1:
                viewHolder2.textPhrase.setText(phrases.id);
                break;
            case 2:
                viewHolder2.textPhrase.setText(phrases.it);
                break;
            case 3:
                viewHolder2.textPhrase.setText(phrases.ja);
                break;
            case 4:
                viewHolder2.textPhrase.setText(phrases.nl);
                break;
            case 5:
                viewHolder2.textPhrase.setText(phrases.pl);
                break;
            case 6:
                viewHolder2.textPhrase.setText(phrases.ro);
                break;
            case 7:
                viewHolder2.textPhrase.setText(phrases.ru);
                break;
            case 8:
                viewHolder2.textPhrase.setText(phrases.sv);
                break;
            case 9:
                viewHolder2.textPhrase.setText(phrases.th);
                break;
            case 10:
                viewHolder2.textPhrase.setText(phrases.tr);
                break;
            case 11:
                viewHolder2.textPhrase.setText(phrases.ar_AE);
                break;
            case 12:
                viewHolder2.textPhrase.setText(phrases.ar_EG);
                break;
            case 13:
                viewHolder2.textPhrase.setText(phrases.ar_SA);
                break;
            case 14:
                viewHolder2.textPhrase.setText(phrases.en_AU);
                break;
            case 15:
                viewHolder2.textPhrase.setText(phrases.en_UK);
                break;
            case 16:
                viewHolder2.textPhrase.setText(phrases.en_US);
                break;
            case 17:
                viewHolder2.textPhrase.setText(phrases.es_ES);
                break;
            case 18:
                viewHolder2.textPhrase.setText(phrases.es_MX);
                break;
            case 19:
                viewHolder2.textPhrase.setText(phrases.es_US);
                break;
            case 20:
                viewHolder2.textPhrase.setText(phrases.fr_CA);
                break;
            case 21:
                viewHolder2.textPhrase.setText(phrases.fr_FR);
                break;
            case 22:
                viewHolder2.textPhrase.setText(phrases.pt_BR);
                break;
            case 23:
                viewHolder2.textPhrase.setText(phrases.pt_PT);
                break;
            case 24:
                viewHolder2.textPhrase.setText(phrases.zh_CN);
                break;
            case 25:
                viewHolder2.textPhrase.setText(phrases.zh_TW);
                break;
            default:
                viewHolder2.textPhrase.setText(phrases.en_US);
                break;
        }
        viewHolder2.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.isSelected()) {
                    view.setSelected(false);
                    viewHolder2.textPhrase.setVisibility(8);
                    viewHolder2.imgShare.setVisibility(8);
                    viewHolder2.imgSpeak.setVisibility(8);
                    viewHolder2.imgCopy.setVisibility(8);
                    return;
                }
                view.setSelected(true);
                viewHolder2.textPhrase.setVisibility(0);
                viewHolder2.imgShare.setVisibility(0);
                viewHolder2.imgSpeak.setVisibility(0);
                viewHolder2.imgCopy.setVisibility(0);
            }
        });
        viewHolder2.imgCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterPhrases.this.mListner.onCopy(viewHolder2.textPhrase.getText().toString());
            }
        });
        viewHolder2.imgSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterPhrases.this.mListner.onSpeak(viewHolder2.textPhrase.getText().toString());
            }
        });
        viewHolder2.imgShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterPhrases.this.mListner.onShare(viewHolder2.textPhrase.getText().toString());
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgCopy;
        ImageView imgShare;
        ImageView imgSpeak;
        TextView textPhrase;
        TextView textSection;

        public ViewHolder(View view) {
            super(view);
            this.textSection = (TextView) view.findViewById(R.id.text_phrases_first);
            this.textPhrase = (TextView) view.findViewById(R.id.text_phrases_second);
            this.imgCopy = (ImageView) view.findViewById(R.id.copy);
            this.imgShare = (ImageView) view.findViewById(R.id.share);
            this.imgSpeak = (ImageView) view.findViewById(R.id.speek);
        }
    }
}
