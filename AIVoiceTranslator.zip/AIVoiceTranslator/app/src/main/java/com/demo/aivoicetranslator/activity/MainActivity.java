package com.demo.aivoicetranslator.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.demo.aivoicetranslator.permission.PermissionUtils;
import com.demo.aivoicetranslator.databinding.ActivityMainBinding;
import com.demo.aivoicetranslator.extra.MySp;

public class MainActivity extends BaseActivity {
    public static int cActivity = 0;
    public static int main_Activity_Flag = 0;
    public static String main_Activity_Online_Flag = "1";
    ActivityMainBinding binding;
    Context context;
    long lastClickTime = 0;
    private long mLastClickTime1;
    MySp mySp;

    @Override
    public void onResume() {
        super.onResume();
        this.binding.textFirstLan.setText(this.mySp.getFirstLan());
        this.binding.textSecondLan.setText(this.mySp.getSecondLan());
        if (this.mySp.getFirstImgLan() == 0) {
            this.mySp.setFirstImgLan(R.drawable.english);
            this.mySp.setSecondImgLan(R.drawable.hindi);
        }
        Glide.with(this.context).load(Integer.valueOf(this.mySp.getFirstImgLan())).into(this.binding.imgFirst);
        Glide.with(this.context).load(Integer.valueOf(this.mySp.getSecondImgLan())).into(this.binding.imgSecond);
        Log.e("TAG123456", "onClick: second image " + this.mySp.getSecondImgLan());

    }

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.drawer), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityMainBinding inflate = ActivityMainBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        this.context = this;
        this.mySp = new MySp(this.context);
        this.binding.imgSecond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.binding.imgSecond.setAlpha(0.5f);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.this.binding.imgSecond.setAlpha(1.0f);
                    }
                }, 100);
                MainActivity.this.startActivity(new Intent(MainActivity.this.context, LanguageChoseActivity.class).putExtra("select", true));
            }
        });
        this.binding.imgFirst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.binding.imgFirst.setAlpha(0.5f);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.this.binding.imgFirst.setAlpha(1.0f);
                    }
                }, 100);
                MainActivity.this.startActivity(new Intent(MainActivity.this.context, LanguageChoseActivity.class).putExtra("select", false));
            }
        });
        HelperResizer.getheightandwidth(this);
        HelperResizer.setSize(this.binding.constraintTopbar, 1080, 169, true);
        HelperResizer.setSize(this.binding.imgMenu, 61, 61, true);
        HelperResizer.setSize(this.binding.imgPremium, 61, 61, true);
        HelperResizer.setSize(this.binding.imgHistory, 61, 61, true);
        HelperResizer.setSize(this.binding.imgFavorits, 61, 61, true);
        this.binding.imgPremium.setAnimation((int) R.raw.premium);
        this.binding.imgMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.startActivity(new Intent(MainActivity.this, Setting_Activity.class));
            }
        });
        this.binding.imgSweep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String obj = MainActivity.this.binding.textFirstLan.getText().toString();
                String obj2 = MainActivity.this.binding.textSecondLan.getText().toString();
                String str = obj + obj2;
                String substring = str.substring(0, str.length() - obj2.length());
                String substring2 = str.substring(substring.length());
                MainActivity.this.binding.textFirstLan.setText(substring2);
                MainActivity.this.binding.textSecondLan.setText(substring);
                MainActivity.this.mySp.setFirstLan(substring2);
                MainActivity.this.mySp.setSecondLan(substring);
                int firstImgLan = MainActivity.this.mySp.getFirstImgLan();
                int secondImgLan = MainActivity.this.mySp.getSecondImgLan();
                String firstLanCode = MainActivity.this.mySp.getFirstLanCode();
                MainActivity.this.mySp.setFirstLanCode(MainActivity.this.mySp.getSecondLanCode());
                MainActivity.this.mySp.setSecondLanCode(firstLanCode);
                MainActivity.this.mySp.setFirstImgLan(secondImgLan);
                MainActivity.this.mySp.setSecondImgLan(firstImgLan);
                Glide.with(MainActivity.this.context).load(Integer.valueOf(MainActivity.this.mySp.getFirstImgLan())).into(MainActivity.this.binding.imgFirst);
                Glide.with(MainActivity.this.context).load(Integer.valueOf(MainActivity.this.mySp.getSecondImgLan())).into(MainActivity.this.binding.imgSecond);
                Log.e("TAG123456", "onClick: second image " + MainActivity.this.mySp.getSecondImgLan());
                Log.e("TAG123456", "onClick: " + MainActivity.this.mySp.getSecondImgLan());
            }
        });
        this.binding.imgVoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.startActivity(new Intent(MainActivity.this.context, TextActivity.class).putExtra("text", "").putExtra("voice", true));
            }
        });
        this.binding.textFirstLan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.binding.textFirstLan.setAlpha(0.5f);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.this.binding.textFirstLan.setAlpha(1.0f);
                    }
                }, 100);
                MainActivity.this.startActivity(new Intent(MainActivity.this.context, LanguageChoseActivity.class).putExtra("select", false));
            }
        });
        this.binding.textSecondLan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.binding.textSecondLan.setAlpha(0.5f);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.this.binding.textSecondLan.setAlpha(1.0f);
                    }
                }, 100);
                MainActivity.this.startActivity(new Intent(MainActivity.this.context, LanguageChoseActivity.class).putExtra("select", true));
            }
        });
        this.binding.constraintText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.startActivity(new Intent(MainActivity.this.context, TextActivity.class).putExtra("text", ""));
            }
        });
        this.binding.imgCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.cActivity = 1;
                if (PermissionUtils.isMediaPermissionGranted(MainActivity.this.getApplicationContext())) {
                    MainActivity.this.startActivity(new Intent(MainActivity.this.context, CameraActivity.class));
                    return;
                }
                PermissionUtils.requestMediaPermission(MainActivity.this);
            }
        });
        this.binding.voiceConversation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.cActivity = 2;
                if (PermissionUtils.isMediaPermissionGranted(MainActivity.this.getApplicationContext())) {
                    MainActivity.this.startActivity(new Intent(MainActivity.this.context, ConversationActivity.class));
                    return;
                }
                PermissionUtils.requestMediaPermission(MainActivity.this);
            }
        });
        this.binding.ocrTranslator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.cActivity = 3;
                if (PermissionUtils.isMediaPermissionGranted(MainActivity.this.getApplicationContext())) {
                    MainActivity.this.startActivity(new Intent(MainActivity.this.context, CameraActivity.class));
                    return;
                }
                PermissionUtils.requestMediaPermission(MainActivity.this);
            }
        });
        this.binding.phrases.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.cActivity = 4;
                if (PermissionUtils.isMediaPermissionGranted(MainActivity.this.getApplicationContext())) {
                    MainActivity.this.startActivity(new Intent(MainActivity.this.context, PhrasesListActivity.class));
                    return;
                }
                PermissionUtils.requestMediaPermission(MainActivity.this);
            }
        });
        this.binding.imgPremium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        this.binding.dictionary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.cActivity = 5;
                if (PermissionUtils.isMediaPermissionGranted(MainActivity.this.getApplicationContext())) {
                    MainActivity.this.startActivity(new Intent(MainActivity.this.context, DictionaryActivity.class));
                    return;
                }
                PermissionUtils.requestMediaPermission(MainActivity.this);
            }
        });
        this.binding.imgHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.startActivity(new Intent(MainActivity.this.context, HistoryActivity.class));
            }
        });
        this.binding.imgFavorits.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.startActivity(new Intent(MainActivity.this.context, FavouriteActivity.class));
            }
        });
    }

    public boolean isNetworkAvailable() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 9898988) {
            if (PermissionUtils.isMediaPermissionGranted(this)) {
                int i2 = cActivity;
                if (i2 == 1) {
                    startActivity(new Intent(this.context, CameraActivity.class));
                } else if (i2 == 2) {
                    startActivity(new Intent(this.context, ConversationActivity.class));
                } else if (i2 == 3) {
                    startActivity(new Intent(this.context, CameraActivity.class));
                } else if (i2 == 4) {
                    startActivity(new Intent(this.context, PhrasesListActivity.class));
                } else if (i2 == 5) {
                    startActivity(new Intent(this.context, DictionaryActivity.class));
                }
            }
            Log.e("TAGKRUNAL", "onActivityResult: actviity  " + cActivity);
        }
    }

    @Override
    public void onBackPressed() {
        ExitDialog();
    }

    private void ExitDialog() {

        final Dialog dialog = new Dialog(MainActivity.this, R.style.DialogTheme);
        dialog.setContentView(R.layout.popup_exit_dialog);
        dialog.setCancelable(false);

        RelativeLayout no = (RelativeLayout) dialog.findViewById(R.id.no);
        RelativeLayout rate = (RelativeLayout) dialog.findViewById(R.id.rate);
        RelativeLayout yes = (RelativeLayout) dialog.findViewById(R.id.yes);

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String rateapp = getPackageName();
                Intent intent1 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + rateapp));
                startActivity(intent1);
            }
        });

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
                System.exit(0);
                //Intent intent = new Intent(AppMainHomeActivity.this, AppThankYouActivity.class);
                //intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                //AdsCommon.InterstitialAd(AppMainHomeActivity.this, intent);
            }
        });

        dialog.show();
    }

}
