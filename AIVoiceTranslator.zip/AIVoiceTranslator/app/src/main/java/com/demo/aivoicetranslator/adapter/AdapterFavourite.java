package com.demo.aivoicetranslator.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.model.ModelHistory;
import java.util.ArrayList;

public class AdapterFavourite extends RecyclerView.Adapter<AdapterFavourite.ViewHolder> {
    ArrayList<ModelHistory> list;
    setOnClickListner mListner;

    public interface setOnClickListner {
        void onFav(int i);

        void onSpeak(int i);
    }

    public AdapterFavourite(ArrayList<ModelHistory> arrayList, setOnClickListner setonclicklistner) {
        this.list = arrayList;
        this.mListner = setonclicklistner;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.favourite_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        ModelHistory modelHistory = this.list.get(i);
        viewHolder.textFirst.setText(modelHistory.textFirst);
        viewHolder.textSecond.setText(modelHistory.textSecond);
        viewHolder.imgFav.setSelected(modelHistory.isFav);
        Glide.with(viewHolder.itemView.getContext()).load(Integer.valueOf(modelHistory.imgFirst)).into(viewHolder.imgFirst);
        Glide.with(viewHolder.itemView.getContext()).load(Integer.valueOf(modelHistory.imgSecond)).into(viewHolder.imgSecond);
        viewHolder.imgFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterFavourite.this.mListner.onFav(i);
            }
        });
        viewHolder.imgSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdapterFavourite.this.mListner.onSpeak(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgFav;
        ImageView imgFirst;
        ImageView imgSecond;
        ImageView imgSpeak;
        TextView textFirst;
        TextView textSecond;

        public ViewHolder(View view) {
            super(view);
            this.textFirst = (TextView) view.findViewById(R.id.text_first);
            this.textSecond = (TextView) view.findViewById(R.id.text_second);
            this.imgFirst = (ImageView) view.findViewById(R.id.img_first);
            this.imgSecond = (ImageView) view.findViewById(R.id.img_second);
            this.imgFav = (ImageView) view.findViewById(R.id.img_fav);
            this.imgSpeak = (ImageView) view.findViewById(R.id.img_speak);
        }
    }
}
