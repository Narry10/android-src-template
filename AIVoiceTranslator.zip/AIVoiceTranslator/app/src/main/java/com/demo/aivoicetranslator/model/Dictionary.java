package com.demo.aivoicetranslator.model;

import java.util.ArrayList;

public class Dictionary {
    public License license;
    public ArrayList<Meaning> meanings;
    public String phonetic;
    public ArrayList<Phonetic> phonetics;
    public ArrayList<String> sourceUrls;
    public String word;

    public class Definition {
        public ArrayList<String> antonyms;
        public String definition;
        public String example;
        public ArrayList<String> synonyms;

        public Definition() {
        }
    }

    public class License {
        public String name;
        public String url;

        public License() {
        }
    }

    public class Meaning {
        public ArrayList<String> antonyms;
        public ArrayList<Definition> definitions;
        public String partOfSpeech;
        public ArrayList<String> synonyms;

        public Meaning() {
        }
    }

    public class Phonetic {
        public String audio;
        public String sourceUrl;
        public String text;

        public Phonetic() {
        }
    }
}
