package com.demo.aivoicetranslator.activity;

import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.adapter.AdapterExample;
import com.demo.aivoicetranslator.adapter.AdapterSynonyms;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.demo.aivoicetranslator.databinding.ActivityDictionaryBinding;
import com.demo.aivoicetranslator.model.Dictionary;
import com.demo.aivoicetranslator.model.ModelExample;
import com.demo.aivoicetranslator.retrofit.RetrofitHelper;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DictionaryActivity extends BaseActivity implements TextToSpeech.OnInitListener {
    ArrayList<String> antonyms = new ArrayList<>();
    ActivityDictionaryBinding binding;
    Context context;
    ArrayList<ModelExample> definitions = new ArrayList<>();
    ArrayList<ModelExample> examples = new ArrayList<>();
    long lastClickTime = 0;
    ArrayList<String> synonyms = new ArrayList<>();
    TextToSpeech tts;
    Dialog dialog;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityDictionaryBinding inflate = ActivityDictionaryBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);


        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        SearchDialog();


        this.context = this;
        this.tts = new TextToSpeech(this.context, this);
        this.binding.constraintMain.setVisibility(View.GONE);
        this.binding.scrollable.setVisibility(View.GONE);
        this.binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DictionaryActivity.this.onBackPressed();
            }
        });
        this.binding.imgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DictionaryActivity.this.binding.edtSerch.setText("");
            }
        });
        this.binding.edtSerch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i != 3) {
                    return false;
                }
                DictionaryActivity.this.SearchData();
                return true;
            }
        });
        this.binding.imgSerch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DictionaryActivity.this.SearchData();
            }
        });
        this.binding.imgSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DictionaryActivity dictionaryActivity = DictionaryActivity.this;
                dictionaryActivity.speakOut(dictionaryActivity.binding.textWord.getText().toString());
            }
        });
        this.binding.imgCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((ClipboardManager) DictionaryActivity.this.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText(DictionaryActivity.this.getString(R.string.app_name), DictionaryActivity.this.binding.textWord.getText().toString()));
                Toast.makeText(DictionaryActivity.this.context, "Copy to Clipboard", 0).show();
            }
        });
        this.binding.imgShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SystemClock.elapsedRealtime() - DictionaryActivity.this.lastClickTime >= 1000) {
                    DictionaryActivity.this.lastClickTime = SystemClock.elapsedRealtime();
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", DictionaryActivity.this.binding.textWord.getText().toString());
                    intent.setType("text/plain");
                    DictionaryActivity.this.context.startActivity(intent);
                }
            }
        });
    }

    
    public void SearchData() {
        ShowDialog();
        if (this.binding.edtSerch.getText().toString().isEmpty()) {
            Toast.makeText(this.context, getString(R.string.please_enter_word), 0).show();
        } else {
            new RetrofitHelper().searchWord().fetching(this.binding.edtSerch.getText().toString()).enqueue(new Callback<ArrayList<Dictionary>>() {
                @Override
                public void onResponse(Call<ArrayList<Dictionary>> call, Response<ArrayList<Dictionary>> response) {
                    if (response.isSuccessful()) {
                        DictionaryActivity.this.binding.textWord.setText(DictionaryActivity.this.binding.edtSerch.getText().toString());
                        Log.d("TAG", "onResponse: " + ((Dictionary) response.body().get(0)).word);
                        DictionaryActivity.this.binding.scrollable.setVisibility(View.VISIBLE);
                        DictionaryActivity.this.setRecycler();
                        DictionaryActivity.this.setData((Dictionary) response.body().get(0));
                        DictionaryActivity.this.binding.constraintMain.setVisibility(View.VISIBLE);
                        DictionaryActivity.this.binding.imgNoData.setVisibility(View.GONE);
                        DictionaryActivity.this.binding.textNoData.setVisibility(View.GONE);
                        HideDialog();
                        return;
                    }
                    Toast.makeText(DictionaryActivity.this.context, "Sorry we couldn't find definitions for the word you were looking for.", 0).show();
                    DictionaryActivity.this.binding.scrollable.setVisibility(View.GONE);
                    HideDialog();
                }

                @Override
                public void onFailure(Call<ArrayList<Dictionary>> call, Throwable th) {
                    DictionaryActivity.this.binding.scrollable.setVisibility(View.GONE);
                    Log.d("TAG", "onFailure: " + th.getLocalizedMessage());
                    HideDialog();
                }
            });
        }
    }

    
    public void setRecycler() {
        AdapterExample adapterExample = new AdapterExample(this.definitions);
        AdapterExample adapterExample2 = new AdapterExample(this.examples);
        AdapterSynonyms adapterSynonyms = new AdapterSynonyms(this.synonyms);
        AdapterSynonyms adapterSynonyms2 = new AdapterSynonyms(this.antonyms);
        this.binding.recyclerViewDifinitions.setAdapter(adapterExample);
        this.binding.recyclerViewDifinitions.setLayoutManager(new LinearLayoutManager(this.context, RecyclerView.VERTICAL, false));
        this.binding.recyclerViewExamples.setAdapter(adapterExample2);
        this.binding.recyclerViewExamples.setLayoutManager(new LinearLayoutManager(this.context, RecyclerView.VERTICAL, false));
        this.binding.recyclerViewSynonyms.setAdapter(adapterSynonyms);
        this.binding.recyclerViewSynonyms.setLayoutManager(new LinearLayoutManager(this.context, RecyclerView.VERTICAL, false));
        this.binding.recyclerViewAntonyms.setAdapter(adapterSynonyms2);
        this.binding.recyclerViewAntonyms.setLayoutManager(new LinearLayoutManager(this.context, RecyclerView.VERTICAL, false));
    }

    
    public void setData(Dictionary dictionary) {
        this.definitions.clear();
        this.examples.clear();
        this.synonyms.clear();
        this.antonyms.clear();
        Iterator<Dictionary.Meaning> it = dictionary.meanings.iterator();
        while (it.hasNext()) {
            Dictionary.Meaning next = it.next();
            Iterator<Dictionary.Definition> it2 = next.definitions.iterator();
            while (it2.hasNext()) {
                Dictionary.Definition next2 = it2.next();
                if (!next2.definition.isEmpty()) {
                    this.definitions.add(new ModelExample(next.partOfSpeech, next2.definition));
                }
                if (next2.example != null && !next2.example.isEmpty()) {
                    this.examples.add(new ModelExample(next.partOfSpeech, next2.example));
                }
                Iterator<String> it3 = next2.synonyms.iterator();
                while (it3.hasNext()) {
                    this.synonyms.add(it3.next());
                }
                Iterator<String> it4 = next2.antonyms.iterator();
                while (it4.hasNext()) {
                    this.antonyms.add(it4.next());
                }
            }
        }
        Log.d("TAG", "setData: definitions " + this.definitions.size());
        Log.d("TAG", "setData: examples " + this.examples.size());
        Log.d("TAG", "setData: synonyms " + this.synonyms.size());
        Log.d("TAG", "setData: antonyms " + this.antonyms.size());
        if (this.synonyms.isEmpty()) {
            this.binding.textTitleSynonyms.setVisibility(View.GONE);
            this.binding.recyclerViewSynonyms.setVisibility(View.GONE);
        } else {
            this.binding.textTitleSynonyms.setVisibility(View.VISIBLE);
            this.binding.recyclerViewSynonyms.setVisibility(View.VISIBLE);
        }
        if (this.antonyms.isEmpty()) {
            this.binding.textTitleAntonyms.setVisibility(View.GONE);
            this.binding.recyclerViewAntonyms.setVisibility(View.GONE);
        } else {
            this.binding.textTitleAntonyms.setVisibility(View.VISIBLE);
            this.binding.recyclerViewAntonyms.setVisibility(View.VISIBLE);
        }
        this.binding.recyclerViewDifinitions.getAdapter().notifyDataSetChanged();
        this.binding.recyclerViewExamples.getAdapter().notifyDataSetChanged();
        this.binding.recyclerViewSynonyms.getAdapter().notifyDataSetChanged();
        this.binding.recyclerViewAntonyms.getAdapter().notifyDataSetChanged();
    }

    
    public void speakOut(String str) {
        this.tts.speak(str, 0, (Bundle) null, (String) null);
    }

    @Override
    public void onInit(int i) {
        if (i == 0) {
            int language = this.tts.setLanguage(Locale.US);
            if (language == -1 || language == -2) {
                Log.e("TTS", "This Language is not supported");
                return;
            }
            return;
        }
        Log.e("TTS", "Initilization Failed!");
    }

    private void SearchDialog() {
        dialog = new Dialog(DictionaryActivity.this, R.style.DialogTheme);
        dialog.setContentView(R.layout.popup_search);
        dialog.setCancelable(false);
    }

    private void ShowDialog() {
        dialog.show();
    }

    private void HideDialog() {
        dialog.dismiss();
    }

}
