package com.demo.aivoicetranslator.activity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.constraintlayout.helper.widget.MotionEffect;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;

import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.adapter.AdapterGallery;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.demo.aivoicetranslator.databinding.ActivityGalleryBinding;
import com.demo.aivoicetranslator.model.ModelPhotoAlbum;
import java.io.File;
import java.util.ArrayList;

public class GalleryActivity extends BaseActivity {
    public static ArrayList<ModelPhotoAlbum> list;
    public static int pos;
    ActivityGalleryBinding binding;
    Context context;
    ArrayList<String> mList = new ArrayList<>();

    @Override
    public void onResume() {
        super.onResume();
        Log.d(MotionEffect.TAG, "onResume: Ok");
        if (!list.isEmpty()) {
            File[] listFiles = new File(list.get(pos).imagePath).getParentFile().listFiles();
            this.binding.textTitle.setText(list.get(pos).folderName);
            getFiles(listFiles);
        }
    }

    private void getFiles(File[] fileArr) {
        this.mList.clear();
        for (File file : fileArr) {
            if (file.getPath().toLowerCase().endsWith(".jpg") || file.getPath().toLowerCase().endsWith(".png") || file.getPath().toLowerCase().endsWith(".jpeg")) {
                Log.d(MotionEffect.TAG, "getFiles: " + file.getPath());
                this.mList.add(file.getPath());
            }
        }
        this.binding.recyclerView.setAdapter(new AdapterGallery(this.mList, new AdapterGallery.setOnClickListener() {
            @Override
            public void onItemClick(int i) {
                CropActivity.myBit = BitmapFactory.decodeFile(GalleryActivity.this.mList.get(i), new BitmapFactory.Options());
                CameraActivity.myBitmap = BitmapFactory.decodeFile(GalleryActivity.this.mList.get(i), new BitmapFactory.Options());
                //GalleryActivity.this.startActivity(new Intent(GalleryActivity.this.context, CropActivity.class));
                GalleryActivity.this.startActivity(new Intent(GalleryActivity.this.context, OCRActivity.class));
            }
        }));
        this.binding.recyclerView.setLayoutManager(new GridLayoutManager(this.context, 3, 1, false));
    }

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }
    
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityGalleryBinding inflate = ActivityGalleryBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);



        this.context = this;
        this.binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GalleryActivity.this.onBackPressed();
            }
        });
        this.binding.imgDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GalleryActivity.this.startActivity(new Intent(GalleryActivity.this.context, GalleryListActivity.class));
            }
        });
        list = getImageDirectories(this.context);
    }

    public ArrayList<ModelPhotoAlbum> getImageDirectories(Context context2) {
        ArrayList<ModelPhotoAlbum> arrayList = new ArrayList<>();
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        String[] strArr = {"_data"};
        Cursor query = context2.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, strArr, "mime_type LIKE 'image/%'  AND mime_type != 'image/gif'  AND mime_type != 'image/giff' ", (String[]) null, (String) null);
        if (query == null || !query.moveToFirst()) {
            return arrayList;
        }
        do {
            String string = query.getString(query.getColumnIndex(strArr[0]));
            if (!arrayList2.contains(new File(string).getParentFile().getName())) {
                arrayList3.clear();
                arrayList2.add(new File(string).getParentFile().getName());
                arrayList3.add(string);
                if (new File(string).exists()) {
                    arrayList.add(new ModelPhotoAlbum(new File(string).getParentFile().getName(), string));
                    Log.d("TAG", "getImageDirectories: " + new File(string).getParentFile().getName());
                    Log.d("TAG", "getImageDirectories: " + string);
                }
            }
        } while (query.moveToNext());
        return arrayList;
    }


    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
    }
}
