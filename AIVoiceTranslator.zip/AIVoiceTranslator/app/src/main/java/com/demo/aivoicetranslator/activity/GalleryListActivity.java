package com.demo.aivoicetranslator.activity;

import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.adapter.AdapterGalleryList;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.demo.aivoicetranslator.databinding.ActivityGalleryListBinding;
import com.demo.aivoicetranslator.model.ModelPhotoAlbum;
import java.io.File;
import java.util.ArrayList;

public class GalleryListActivity extends BaseActivity {
    ActivityGalleryListBinding binding;
    Context context;
    ArrayList<ModelPhotoAlbum> list;

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityGalleryListBinding inflate = ActivityGalleryListBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        this.context = this;
        this.list = GalleryActivity.list;
        this.binding.imgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GalleryListActivity.this.onBackPressed();
            }
        });
        this.binding.recyclerView.setAdapter(new AdapterGalleryList(this.list, new AdapterGalleryList.setOnClickListener() {
            @Override
            public void onItemClick(int i) {
                GalleryActivity.pos = i;
                GalleryListActivity.this.onBackPressed();
            }
        }));
        this.binding.recyclerView.setLayoutManager(new LinearLayoutManager(this.context, 1, false));
    }

    public static ArrayList<ModelPhotoAlbum> getImageDirectories(Context context2) {
        ArrayList<ModelPhotoAlbum> arrayList = new ArrayList<>();
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        String[] strArr = {"_data"};
        Cursor query = context2.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, strArr, "mime_type LIKE 'image/%'  AND mime_type != 'image/gif'  AND mime_type != 'image/giff' ", (String[]) null, (String) null);
        if (query == null || !query.moveToFirst()) {
            return arrayList;
        }
        do {
            String string = query.getString(query.getColumnIndex(strArr[0]));
            if (!arrayList2.contains(new File(string).getParentFile().getName())) {
                arrayList3.clear();
                arrayList2.add(new File(string).getParentFile().getName());
                arrayList3.add(string);
                if (new File(string).exists()) {
                    arrayList.add(new ModelPhotoAlbum(new File(string).getParentFile().getName(), string));
                    Log.d("TAG", "getImageDirectories: " + new File(string).getParentFile().getName());
                    Log.d("TAG", "getImageDirectories: " + string);
                }
            }
        } while (query.moveToNext());
        return arrayList;
    }
}
