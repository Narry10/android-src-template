package com.demo.aivoicetranslator.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.model.ModelExample;
import java.util.ArrayList;

public class AdapterExample extends RecyclerView.Adapter<AdapterExample.ViewHolder> {
    ArrayList<ModelExample> list;

    public AdapterExample(ArrayList<ModelExample> arrayList) {
        this.list = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.example_layout, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        ModelExample modelExample = this.list.get(i);
        viewHolder.textTitle.setText(modelExample.title);
        viewHolder.textValue.setText(modelExample.value);
    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textTitle;
        TextView textValue;

        public ViewHolder(View view) {
            super(view);
            this.textTitle = (TextView) view.findViewById(R.id.text_title);
            this.textValue = (TextView) view.findViewById(R.id.text_value);
        }
    }
}
