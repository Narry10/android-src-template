package com.demo.aivoicetranslator.activity;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.demo.aivoicetranslator.R;
import com.demo.aivoicetranslator.adapter.AdapterLanguage;
import com.demo.aivoicetranslator.ads.AdsCommon;
import com.demo.aivoicetranslator.databinding.ActivityLanguagePhrasesBinding;
import com.demo.aivoicetranslator.extra.MySp;
import com.demo.aivoicetranslator.model.ModelLanguage;
import com.mannan.translateapi.Language;
import java.util.ArrayList;
import java.util.Iterator;

public class LanguagePhrasesActivity extends BaseActivity {
    
    public static int pos22;
    ActivityLanguagePhrasesBinding binding;
    Context context;
    ArrayList<ModelLanguage> firstList = new ArrayList<>();
    ArrayList<ModelLanguage> list = new ArrayList<>();
    MySp mySp;
    ArrayList<ModelLanguage> secondList = new ArrayList<>();

    private void applyDisplayCutouts() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_home), (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                            | WindowInsetsCompat.Type.displayCutout());

            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //getWindow().setFlags(1024, 1024);
        EdgeToEdge.enable(this);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        ActivityLanguagePhrasesBinding inflate = ActivityLanguagePhrasesBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());

        applyDisplayCutouts();

        AdsCommon.InterstitialAdsOnly(this);

        //Reguler Banner Ads
        RelativeLayout admob_banner = (RelativeLayout) binding.regulerBannerAd.AdmobBannerFrame;
        LinearLayout adContainer = (LinearLayout) binding.regulerBannerAd.bannerContainer;
        FrameLayout qureka = (FrameLayout) binding.regulerBannerAd.qureka;
        AdsCommon.RegulerBanner(this, admob_banner, adContainer, qureka);


        this.context = this;
        this.binding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LanguagePhrasesActivity.this.onBackPressed();
            }
        });
        this.mySp = new MySp(this.context);
        this.binding.textFirstLan.setText(getText(R.string.text_from) + this.mySp.getFirstLanPhr());
        this.binding.textSecondLan.setText(getText(R.string.text_to) + this.mySp.getSecondLanPhr());
        this.binding.langDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (LanguagePhrasesActivity.this.binding.textFirstLan.isSelected()) {
                    LanguagePhrasesActivity.this.mySp.setFirstLanPhr(LanguagePhrasesActivity.this.list.get(LanguagePhrasesActivity.pos22).name);
                    LanguagePhrasesActivity.this.mySp.setFirstLanCodePhr(LanguagePhrasesActivity.this.list.get(LanguagePhrasesActivity.pos22).code);
                    LanguagePhrasesActivity.this.mySp.setFirstImgLanPhr(LanguagePhrasesActivity.this.list.get(LanguagePhrasesActivity.pos22).image);
                    LanguagePhrasesActivity.this.mySp.setFirstPosPhr(LanguagePhrasesActivity.pos22);
                    LanguagePhrasesActivity.this.binding.textFirstLan.setText(LanguagePhrasesActivity.this.getText(R.string.text_from) + LanguagePhrasesActivity.this.list.get(LanguagePhrasesActivity.pos22).name);
                    LanguagePhrasesActivity.this.onBackPressed();
                    return;
                }
                LanguagePhrasesActivity.this.mySp.setSecondLanPhr(LanguagePhrasesActivity.this.list.get(LanguagePhrasesActivity.pos22).name);
                LanguagePhrasesActivity.this.mySp.setSecondLanCodePhr(LanguagePhrasesActivity.this.list.get(LanguagePhrasesActivity.pos22).code);
                LanguagePhrasesActivity.this.mySp.setSecondImgLanPhr(LanguagePhrasesActivity.this.list.get(LanguagePhrasesActivity.pos22).image);
                LanguagePhrasesActivity.this.mySp.setSecondPosPhr(LanguagePhrasesActivity.pos22);
                LanguagePhrasesActivity.this.binding.textSecondLan.setText(LanguagePhrasesActivity.this.getText(R.string.text_to) + LanguagePhrasesActivity.this.list.get(LanguagePhrasesActivity.pos22).name);
                LanguagePhrasesActivity.this.onBackPressed();
            }
        });
        boolean booleanExtra = getIntent().getBooleanExtra("select", false);
        addList();
        setLang(booleanExtra);
        this.binding.textFirstLan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LanguagePhrasesActivity.this.setLang(false);
                LanguagePhrasesActivity.this.binding.recyclerView.getAdapter().notifyDataSetChanged();
            }
        });
        this.binding.textSecondLan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LanguagePhrasesActivity.this.setLang(true);
                LanguagePhrasesActivity.this.binding.recyclerView.getAdapter().notifyDataSetChanged();
            }
        });
        this.binding.recyclerView.setAdapter(new AdapterLanguage(this.list, new AdapterLanguage.setOnClickListner() {
            @Override
            public void onClick(int i) {
                int unused = LanguagePhrasesActivity.pos22 = i;
            }
        }));
        this.binding.recyclerView.setLayoutManager(new LinearLayoutManager(this.context, 1, false));
        this.binding.imgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LanguagePhrasesActivity.this.binding.edtSerch.setText("");
            }
        });
        this.binding.edtSerch.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                LanguagePhrasesActivity.this.list.clear();
                if (LanguagePhrasesActivity.this.binding.textSecondLan.isSelected()) {
                    LanguagePhrasesActivity languagePhrasesActivity = LanguagePhrasesActivity.this;
                    ArrayList access$200 = languagePhrasesActivity.filterList(languagePhrasesActivity.secondList, charSequence);
                    if (access$200.isEmpty()) {
                        LanguagePhrasesActivity.this.list.addAll(LanguagePhrasesActivity.this.secondList);
                    } else {
                        LanguagePhrasesActivity.this.list.addAll(access$200);
                    }
                } else {
                    LanguagePhrasesActivity languagePhrasesActivity2 = LanguagePhrasesActivity.this;
                    ArrayList access$2002 = languagePhrasesActivity2.filterList(languagePhrasesActivity2.firstList, charSequence);
                    if (access$2002.isEmpty()) {
                        LanguagePhrasesActivity.this.list.addAll(LanguagePhrasesActivity.this.firstList);
                    } else {
                        LanguagePhrasesActivity.this.list.addAll(access$2002);
                    }
                }
                LanguagePhrasesActivity.this.binding.recyclerView.getAdapter().notifyDataSetChanged();
            }
        });
    }

    
    public ArrayList<ModelLanguage> filterList(ArrayList<ModelLanguage> arrayList, CharSequence charSequence) {
        ArrayList<ModelLanguage> arrayList2 = new ArrayList<>();
        arrayList2.clear();
        Iterator<ModelLanguage> it = arrayList.iterator();
        while (it.hasNext()) {
            ModelLanguage next = it.next();
            if (next.name.toLowerCase().contains(charSequence.toString().toLowerCase())) {
                arrayList2.add(next);
            }
        }
        return arrayList2;
    }

    private void addList() {
        this.firstList.clear();
        this.firstList.add(new ModelLanguage("Arabic", "ar_SA", R.drawable.arabic, false));
        this.firstList.add(new ModelLanguage("Arabic (Egypt)", "ar_EG", R.drawable.arabic_egypt, false));
        this.firstList.add(new ModelLanguage("Arabic (UAE)", "ar_AE", R.drawable.arabic_uae, false));
        this.firstList.add(new ModelLanguage("Chinese (Simplified)", "zh_CN", R.drawable.chinese, false));
        this.firstList.add(new ModelLanguage("Chinese (Traditional)", "zh_TW", R.drawable.chinese_traditional, false));
        this.firstList.add(new ModelLanguage("Dutch", Language.DUTCH, R.drawable.dutch, false));
        ArrayList<ModelLanguage> arrayList = this.firstList;
        String str = Language.DUTCH;
        arrayList.add(new ModelLanguage("English (UK)", "en_UK", R.drawable.english, false));
        this.firstList.add(new ModelLanguage("English (US)", "en_US", R.drawable.usa, false));
        this.firstList.add(new ModelLanguage("English (AU)", "en_AU", R.drawable.english_australia, false));
        this.firstList.add(new ModelLanguage("French", "fr_FR", R.drawable.french, false));
        this.firstList.add(new ModelLanguage("French (Canada)", "fr_CA", R.drawable.french_canada, false));
        this.firstList.add(new ModelLanguage("German", Language.GERMAN, R.drawable.german, false));
        this.firstList.add(new ModelLanguage("Indonesian", "id", R.drawable.indonesian, false));
        this.firstList.add(new ModelLanguage("Italian", Language.ITALIAN, R.drawable.italian, false));
        this.firstList.add(new ModelLanguage("Japanese", Language.JAPANESE, R.drawable.japanese, false));
        this.firstList.add(new ModelLanguage("Polish", Language.POLISH, R.drawable.polish, false));
        this.firstList.add(new ModelLanguage("Prtuguese", "pt_PT", R.drawable.prtuguese, false));
        this.firstList.add(new ModelLanguage("Prtuguese (Brazil)", "pt_BR", R.drawable.prtuguese_brazil, false));
        this.firstList.add(new ModelLanguage("Romanian", Language.ROMANIAN, R.drawable.romanian, false));
        this.firstList.add(new ModelLanguage("Russion", Language.RUSSIAN, R.drawable.russion, false));
        this.firstList.add(new ModelLanguage("Spanish", "es_ES", R.drawable.spanish, false));
        this.firstList.add(new ModelLanguage("Spanish (US)", "es_US", R.drawable.spanish_us, false));
        this.firstList.add(new ModelLanguage("Spanish (Mexico)", "es_MX", R.drawable.spanish_mexico, false));
        this.firstList.add(new ModelLanguage("Swedish", Language.SWEDISH, R.drawable.swedish, false));
        this.firstList.add(new ModelLanguage("Thai", Language.THAI, R.drawable.thai, false));
        this.firstList.add(new ModelLanguage("Turkish", Language.TURKISH, R.drawable.turkish, false));
        this.secondList.clear();
        this.secondList.add(new ModelLanguage("Arabic", "ar_SA", R.drawable.arabic, false));
        this.secondList.add(new ModelLanguage("Arabic (Egypt)", "ar_EG", R.drawable.arabic_egypt, false));
        this.secondList.add(new ModelLanguage("Arabic (UAE)", "ar_AE", R.drawable.arabic_uae, false));
        this.secondList.add(new ModelLanguage("Chinese (Simplified)", "zh_CN", R.drawable.chinese, false));
        this.secondList.add(new ModelLanguage("Chinese (Traditional)", "zh_TW", R.drawable.chinese_traditional, false));
        this.secondList.add(new ModelLanguage("Dutch", str, R.drawable.dutch, false));
        this.secondList.add(new ModelLanguage("English (UK)", "en_UK", R.drawable.english, false));
        this.secondList.add(new ModelLanguage("English (US)", "en_US", R.drawable.usa, false));
        this.secondList.add(new ModelLanguage("English (AU)", "en_AU", R.drawable.english_australia, false));
        this.secondList.add(new ModelLanguage("French", "fr_FR", R.drawable.french, false));
        this.secondList.add(new ModelLanguage("French (Canada)", "fr_CA", R.drawable.french_canada, false));
        this.secondList.add(new ModelLanguage("German", Language.GERMAN, R.drawable.german, false));
        this.secondList.add(new ModelLanguage("Indonesian", "id", R.drawable.indonesian, false));
        this.secondList.add(new ModelLanguage("Italian", Language.ITALIAN, R.drawable.italian, false));
        this.secondList.add(new ModelLanguage("Japanese", Language.JAPANESE, R.drawable.japanese, false));
        this.secondList.add(new ModelLanguage("Polish", Language.POLISH, R.drawable.polish, false));
        this.secondList.add(new ModelLanguage("Prtuguese", "pt_PT", R.drawable.prtuguese, false));
        this.secondList.add(new ModelLanguage("Prtuguese (Brazil)", "pt_BR", R.drawable.prtuguese_brazil, false));
        this.secondList.add(new ModelLanguage("Romanian", Language.ROMANIAN, R.drawable.romanian, false));
        this.secondList.add(new ModelLanguage("Russion", Language.RUSSIAN, R.drawable.russion, false));
        this.secondList.add(new ModelLanguage("Spanish", "es_ES", R.drawable.spanish, false));
        this.secondList.add(new ModelLanguage("Spanish (US)", "es_US", R.drawable.spanish_us, false));
        this.secondList.add(new ModelLanguage("Spanish (Mexico)", "es_MX", R.drawable.spanish_mexico, false));
        this.secondList.add(new ModelLanguage("Swedish", Language.SWEDISH, R.drawable.swedish, false));
        this.secondList.add(new ModelLanguage("Thai", Language.THAI, R.drawable.thai, false));
        this.secondList.add(new ModelLanguage("Turkish", Language.TURKISH, R.drawable.turkish, false));
        int firstPosPhr = this.mySp.getFirstPosPhr();
        int secondPosPhr = this.mySp.getSecondPosPhr();
        ModelLanguage modelLanguage = this.firstList.get(firstPosPhr);
        modelLanguage.isSelect = true;
        ModelLanguage modelLanguage2 = this.secondList.get(secondPosPhr);
        modelLanguage2.isSelect = true;
        this.firstList.remove(firstPosPhr);
        this.firstList.add(firstPosPhr, modelLanguage);
        this.secondList.remove(secondPosPhr);
        this.secondList.add(secondPosPhr, modelLanguage2);
    }

    
    public void setLang(boolean z) {
        if (!z) {
            this.binding.textFirstLan.setSelected(true);
            this.binding.textSecondLan.setSelected(false);
            this.list.clear();
            this.list.addAll(this.firstList);
            return;
        }
        this.binding.textFirstLan.setSelected(false);
        this.binding.textSecondLan.setSelected(true);
        this.list.clear();
        this.list.addAll(this.secondList);
    }
}
