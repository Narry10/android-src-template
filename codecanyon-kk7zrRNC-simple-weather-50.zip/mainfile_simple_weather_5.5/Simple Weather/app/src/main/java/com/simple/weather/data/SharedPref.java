package com.simple.weather.data;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPref {

    private Context ctx;
    private SharedPreferences custom_preferences;

    public SharedPref(Context context) {
        this.ctx = context;
        custom_preferences = context.getSharedPreferences("MAIN_PREF", Context.MODE_PRIVATE);
    }


    // Preference for first launch
    public void setIntersCounter(int counter) {
        custom_preferences.edit().putInt("INTERS_COUNT", counter).apply();
    }

    public int getIntersCounter() {
        return custom_preferences.getInt("INTERS_COUNT", 0);
    }

    public void clearIntersCounter() {
        custom_preferences.edit().putInt("INTERS_COUNT", 0).apply();
    }

}
