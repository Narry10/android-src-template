package com.simple.weather.model;

import java.util.ArrayList;
import java.util.List;

public class ForecastResponse {

    public String cod = null;
    public Integer cnt = null;
    public List<Forecast> list = new ArrayList<>();

    public static class Forecast {

        public long dt;
        public Main main;
        public List<Weather> weather;
        public Clouds clouds;
        public Wind wind;
        public int visibility;
        public Double pop;
        public Rain rain;
        public Sys sys;
        public String dt_txt;
    }

    public static class Main {
        public Double temp;
        public Double feels_like;
        public Double temp_min;
        public Double temp_max;
        public Double pressure;
        public Double sea_level;
        public Double grnd_level;
        public Double humidity;
        public Double temp_kf;
    }

    public static class Weather {
        public int id;
        public String main;
        public String description;
        public String icon;
    }

    public static class Clouds {
        public int all;
    }

    public static class Wind {
        public Double speed;
        public Double deg;
        public Double gust;
    }

    public static class Rain {
        public Double _3h;
    }

    public static class Sys {
        public String pod;
    }
}
